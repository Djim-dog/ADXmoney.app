# ADXmoney v7 — Níveis + Visual Premium

## Estado: completo e validado (2026-10-22)

### Incluído neste ZIP

#### 1. Sistema de níveis (frontend + backend)
- Níveis: Bronze / Silver / Gold / Platinum
- Ranking da comunidade
- Certificado de membro
- Benefícios por nível
- Código de afiliado personalizado (Gold+)
- Saque prioritário (Gold+)
- Badge de nível no header
- Cartão de nível na aba Afiliados

#### 2. Backend validado
- `database/006_user_levels.sql` — **já aplicado no Supabase**
- Guardado apenas para histórico e novos ambientes
- Não reexecutar se já correu com sucesso

#### 3. Visual premium
- Tipografia: Plus Jakarta Sans
- Shell com gradiente suave e glass header/nav
- Tokens de sombra e cor de marca
- Badges de nível coloridos
- Login refinado
- Cards e botões com acabamento premium
- Classes utilitárias: `.card-premium`, `.gradient-adx`, `.badge-level`, `.btn-adx`

### Critérios de nível
| Nível     | Indicações | Ganhos afiliado |
|-----------|------------|-----------------|
| Bronze    | 0–4        | < 5.000 Kz      |
| Silver    | 5–14       | ≥ 5.000 Kz      |
| Gold      | 15–49      | ≥ 15.000 Kz     |
| Platinum  | 50+        | ≥ 50.000 Kz     |

### Nada pendente
- [x] Migração SQL validada no Supabase
- [x] Frontend de níveis integrado
- [x] Visual premium aplicado
- [x] SQL intermédio removido (só 006 consolidado)
- [x] Changelog atualizado

### Deploy
1. Fazer deploy deste ZIP no hosting (Vercel / etc.)
2. Hard refresh no telemóvel
3. Confirmar badge de nível no header e cartão em Afiliados
