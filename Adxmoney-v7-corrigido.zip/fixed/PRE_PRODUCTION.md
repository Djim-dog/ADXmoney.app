# Checklist pré-produção ADXmoney

## 1. SQL no Supabase (ordem)
- [ ] 009_campaign_requests_admin_update.sql
- [ ] 010_debit_wallet.sql
- [ ] 011_wallet_deposits.sql
- [ ] 012_campaign_request_fixes.sql
- [ ] 013_audit_hardening.sql

## 2. Edge Functions (deploy)
```bash
supabase functions deploy admin-delete-user
supabase functions deploy admin-create-user
supabase functions deploy public-register
supabase functions deploy ai-coach
supabase functions deploy ai-generate-content
supabase functions deploy ai-support
```
Secrets: SUPABASE_SERVICE_ROLE_KEY, SUPABASE_ANON_KEY, chaves IA se aplicável.

## 3. Storage
- Bucket `subscription-proofs` (privado)
- Policies: user upload no próprio path; admin leitura / signed URL
- Paths: `{userId}/...` e `deposits/{userId}/...`

## 4. Testes manuais mínimos
1. Registo → first login → app Home
2. Carregar conta → admin aprova → saldo + notificação in-app
3. Solicitar campanha com saldo → PENDING no admin
4. Aprovar campanha → lançar
5. Saque → admin processa
6. Admin criar user / eliminar user (não a si próprio)
7. Logout → login sem vídeo; fechar app sem sessão → vídeo intro

## 5. Segurança aplicada no código
- admin-delete-user: JWT + role admin, anti auto-delete, confirm admin
- admin-create-user: JWT + role admin
- Campanha: RPC atómica submit_paid_campaign_request
