-- 008: resolver convite também por custom_affiliate_code (Gold+)
-- Correr no SQL Editor do Supabase (uma vez)

CREATE OR REPLACE FUNCTION public.complete_account_setup(
  p_user_id UUID,
  p_name TEXT,
  p_phone TEXT,
  p_primary_link TEXT DEFAULT NULL,
  p_invite_code TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_caller UUID := auth.uid();
  v_first_login BOOLEAN;
  v_affiliate RECORD;
  v_clean_code TEXT;
  v_user_wallet_id UUID;
  v_affiliate_wallet_id UUID;
  v_bonus_applied BOOLEAN := FALSE;
  v_referral_code TEXT;
BEGIN
  IF v_caller IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;

  -- Só o próprio utilizador (ou admin) pode completar o setup
  IF v_caller != p_user_id AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'Permissão negada.';
  END IF;

  SELECT first_login INTO v_first_login
  FROM public.profiles WHERE id = p_user_id;

  IF v_first_login IS NOT TRUE THEN
    RETURN jsonb_build_object('success', false, 'message', 'O setup desta conta já foi concluído.');
  END IF;

  -- Garantir carteira
  INSERT INTO public.wallets (user_id, balance, reserved_balance)
  VALUES (p_user_id, 0.00, 0.00)
  ON CONFLICT (user_id) DO NOTHING;

  SELECT id INTO v_user_wallet_id FROM public.wallets WHERE user_id = p_user_id;

  -- Gerar referral_code único se ainda não existir
  SELECT referral_code INTO v_referral_code FROM public.profiles WHERE id = p_user_id;
  IF v_referral_code IS NULL OR length(trim(v_referral_code)) = 0 THEN
    v_referral_code := 'ADX' || upper(substr(replace(p_user_id::text, '-', ''), 1, 8));
  END IF;

  -- Processar código de convite
  IF p_invite_code IS NOT NULL AND length(trim(p_invite_code)) > 0 THEN
    v_clean_code := upper(trim(p_invite_code));

    -- Procurar em affiliate_profiles ou em profiles.referral_code
    SELECT ap.* INTO v_affiliate
    FROM public.affiliate_profiles ap
    WHERE upper(ap.affiliate_code) = v_clean_code AND ap.is_active = true;

    IF v_affiliate.id IS NULL THEN
      -- Fallback: profiles.referral_code OU custom_affiliate_code (Gold+)
      SELECT p.id AS user_id,
             COALESCE(p.custom_affiliate_code, p.referral_code) AS affiliate_code,
             true AS is_active
      INTO v_affiliate
      FROM public.profiles p
      WHERE p.id != p_user_id
        AND p.is_active = true
        AND (
          upper(COALESCE(p.referral_code, '')) = v_clean_code
          OR upper(COALESCE(p.custom_affiliate_code, '')) = v_clean_code
        )
      LIMIT 1;
    END IF;

    IF v_affiliate.user_id IS NOT NULL AND v_affiliate.user_id != p_user_id THEN
      IF NOT EXISTS (SELECT 1 FROM public.affiliate_referrals WHERE referred_user_id = p_user_id) THEN
        INSERT INTO public.affiliate_referrals (
          affiliate_user_id, referred_user_id, affiliate_code,
          bonus_user, commission_affiliate, status
        ) VALUES (
          v_affiliate.user_id, p_user_id, v_clean_code,
          250.00, 500.00, 'COMPLETED'
        );

        -- Bónus utilizador +250 Kz
        UPDATE public.wallets
        SET balance = balance + 250.00, updated_at = NOW()
        WHERE id = v_user_wallet_id;

        INSERT INTO public.wallet_transactions (
          wallet_id, user_id, type, amount, description, reference_id, status
        ) VALUES (
          v_user_wallet_id, p_user_id, 'SIGNUP_BONUS', 250.00,
          'Bónus de primeiro acesso via convite', v_clean_code, 'COMPLETED'
        );

        -- Comissão afiliado +500 Kz
        INSERT INTO public.wallets (user_id, balance, reserved_balance)
        VALUES (v_affiliate.user_id, 0.00, 0.00)
        ON CONFLICT (user_id) DO NOTHING;

        SELECT id INTO v_affiliate_wallet_id
        FROM public.wallets WHERE user_id = v_affiliate.user_id;

        UPDATE public.wallets
        SET balance = balance + 500.00, updated_at = NOW()
        WHERE id = v_affiliate_wallet_id;

        INSERT INTO public.wallet_transactions (
          wallet_id, user_id, type, amount, description, reference_id, status
        ) VALUES (
          v_affiliate_wallet_id, v_affiliate.user_id, 'AFFILIATE_COMMISSION', 500.00,
          'Comissão de novo utilizador indicado: ' || COALESCE(p_name, 'Novo Utilizador'),
          p_user_id::text, 'COMPLETED'
        );

        -- Atualizar stats do afiliado se existir perfil de afiliado
        UPDATE public.affiliate_profiles
        SET total_referrals = total_referrals + 1,
            total_earned = total_earned + 500.00,
            updated_at = NOW()
        WHERE user_id = v_affiliate.user_id;

        UPDATE public.profiles
        SET invited_by = v_affiliate.user_id,
            referred_completed = true
        WHERE id = p_user_id;

        v_bonus_applied := TRUE;
      END IF;
    END IF;
  END IF;

  -- Atualizar perfil
  UPDATE public.profiles
  SET name = COALESCE(NULLIF(trim(p_name), ''), name),
      phone = COALESCE(NULLIF(trim(p_phone), ''), phone),
      primary_link = NULLIF(trim(p_primary_link), ''),
      referral_code = v_referral_code,
      first_login = false,
      updated_at = NOW()
  WHERE id = p_user_id;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (
    p_user_id,
    'ACCOUNT_SETUP_COMPLETED',
    'Configuração inicial concluída',
    CASE WHEN v_bonus_applied
      THEN 'Com bónus de afiliado de 250 Kz aplicado.'
      ELSE 'Concluído sem código de convite.'
    END
  );

  RETURN jsonb_build_object(
    'success', true,
    'message', CASE WHEN v_bonus_applied
      THEN 'Conta configurada com sucesso! Recebeu 250 Kz de bónus.'
      ELSE 'Conta configurada com sucesso!'
    END,
    'bonus_applied', v_bonus_applied
  );
END;
$$;

-- --------------------------------------------------------------------
-- 8. RPC submit_subscription_payment
-- --------------------------------------------------------------------

GRANT EXECUTE ON FUNCTION public.complete_account_setup(UUID, TEXT, TEXT, TEXT, TEXT) TO authenticated;
