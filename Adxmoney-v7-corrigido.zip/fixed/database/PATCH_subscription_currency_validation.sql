-- ADXmoney: corrigir validação fixa de USD na submissão da assinatura.
-- Esta função regista o valor/moeda escolhidos e mantém aprovação manual pelo administrador.
-- Não altera pagamentos antigos nem ativa assinaturas automaticamente.
CREATE OR REPLACE FUNCTION public.submit_subscription_payment(
  p_amount NUMERIC,
  p_currency TEXT,
  p_method TEXT,
  p_proof_url TEXT DEFAULT NULL,
  p_payment_date TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_user_id UUID := auth.uid();
  v_payment_id UUID;
  v_currency TEXT := upper(trim(coalesce(p_currency, '')));
  v_method TEXT := upper(trim(coalesce(p_method, '')));
BEGIN
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;
  IF p_amount IS NULL OR p_amount <= 0 THEN
    RAISE EXCEPTION 'Valor inválido.';
  END IF;
  IF v_currency NOT IN ('AOA', 'USD', 'EUR', 'BRL') THEN
    RAISE EXCEPTION 'Moeda não suportada.';
  END IF;
  IF v_method NOT IN ('EXPRESS', 'UNITEL', 'REMITLY') THEN
    RAISE EXCEPTION 'Método de pagamento inválido.';
  END IF;
  IF p_proof_url IS NULL OR trim(p_proof_url) = '' OR split_part(p_proof_url, '/', 1) <> v_user_id::text THEN
    RAISE EXCEPTION 'Comprovativo inválido para este utilizador.';
  END IF;

  INSERT INTO public.subscription_payments (
    user_id, amount, currency, method, proof_url, status
  ) VALUES (
    v_user_id, round(p_amount, 2), v_currency, v_method, p_proof_url, 'PENDING'
  ) RETURNING id INTO v_payment_id;

  UPDATE public.profiles
  SET subscription_status = 'pending', updated_at = NOW()
  WHERE id = v_user_id;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (v_user_id, 'SUBSCRIPTION_SUBMITTED', 'Pedido de assinatura enviado', v_method || ' / ' || v_currency);

  RETURN jsonb_build_object('success', true, 'payment_id', v_payment_id);
END;
$$;

REVOKE ALL ON FUNCTION public.submit_subscription_payment(NUMERIC, TEXT, TEXT, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.submit_subscription_payment(NUMERIC, TEXT, TEXT, TEXT, TEXT) TO authenticated;
