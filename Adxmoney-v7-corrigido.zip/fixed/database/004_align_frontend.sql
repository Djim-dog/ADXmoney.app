-- ====================================================================
-- ADXmoney App - Migration 004: Align Database with Frontend
-- PostgreSQL / Supabase
-- Adiciona tabelas, colunas, RPCs e políticas que o frontend já consome
-- mas que estavam em falta nas migrações 001-003.
-- ====================================================================

-- --------------------------------------------------------------------
-- 1. ALTER profiles – colunas extras usadas pelo frontend
-- --------------------------------------------------------------------
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS subscription_status TEXT NOT NULL DEFAULT 'visitor'
    CHECK (subscription_status IN ('visitor', 'pending', 'active', 'expired', 'cancelled')),
  ADD COLUMN IF NOT EXISTS subscription_onboarding_completed BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS primary_link TEXT,
  ADD COLUMN IF NOT EXISTS country TEXT DEFAULT 'Angola',
  ADD COLUMN IF NOT EXISTS referral_code TEXT,
  ADD COLUMN IF NOT EXISTS invited_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS referred_completed BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS tiktok TEXT,
  ADD COLUMN IF NOT EXISTS instagram TEXT,
  ADD COLUMN IF NOT EXISTS youtube TEXT;

-- Índice para pesquisas de código de convite
CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_referral_code
  ON public.profiles (upper(referral_code))
  WHERE referral_code IS NOT NULL;

-- --------------------------------------------------------------------
-- 2. Tabela subscription_payments
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.subscription_payments (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount NUMERIC(14, 2) NOT NULL CHECK (amount > 0),
  currency TEXT NOT NULL DEFAULT 'AOA',
  method TEXT NOT NULL,
  proof_url TEXT,
  status TEXT NOT NULL DEFAULT 'PENDING'
    CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED')),
  rejection_reason TEXT,
  processed_at TIMESTAMPTZ,
  processed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_subscription_payments_user
  ON public.subscription_payments (user_id, status);
CREATE INDEX IF NOT EXISTS idx_subscription_payments_status
  ON public.subscription_payments (status, created_at DESC);

-- FK nomeada para o select com join do frontend
ALTER TABLE public.subscription_payments
  DROP CONSTRAINT IF EXISTS fk_subscription_payments_profiles;
ALTER TABLE public.subscription_payments
  ADD CONSTRAINT fk_subscription_payments_profiles
  FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

-- --------------------------------------------------------------------
-- 3. Tabela engagement_orders (Loja)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.engagement_orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  platform TEXT NOT NULL CHECK (platform IN ('TikTok', 'Instagram', 'YouTube')),
  service_type TEXT NOT NULL CHECK (service_type IN ('Seguidores', 'Gostos', 'Comentários', 'Visualizações')),
  target_link TEXT NOT NULL,
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  total_price NUMERIC(14, 2) NOT NULL CHECK (total_price >= 0),
  currency TEXT NOT NULL DEFAULT 'USD',
  method TEXT,
  proof_url TEXT,
  status TEXT NOT NULL DEFAULT 'PENDING'
    CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED', 'PROCESSING', 'COMPLETED')),
  rejection_reason TEXT,
  processed_at TIMESTAMPTZ,
  processed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_engagement_orders_user
  ON public.engagement_orders (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_engagement_orders_status
  ON public.engagement_orders (status, created_at DESC);

-- --------------------------------------------------------------------
-- 4. Tabela campaign_requests (Campanha Coletiva 10 USD)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.campaign_requests (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  platform TEXT NOT NULL,
  target_url TEXT NOT NULL,
  action_type TEXT NOT NULL DEFAULT 'follow',
  objective TEXT,
  description TEXT,
  target_audience TEXT DEFAULT 'Geral',
  requester_phone TEXT,
  cost_usd NUMERIC(10, 2) NOT NULL DEFAULT 10.00,
  currency TEXT NOT NULL DEFAULT 'USD',
  amount_paid NUMERIC(14, 2),
  proof_url TEXT,
  status TEXT NOT NULL DEFAULT 'PENDING'
    CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED', 'IN_PROGRESS', 'COMPLETED')),
  rejection_reason TEXT,
  processed_at TIMESTAMPTZ,
  processed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_campaign_requests_user
  ON public.campaign_requests (user_id, status);

-- --------------------------------------------------------------------
-- 5. Community Tasks system
-- --------------------------------------------------------------------

-- community_settings: se a tabela já existir com estrutura antiga, recria de forma segura
DO $$
BEGIN
  -- Se a tabela existe mas não tem a coluna "platform", dropa e recria
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'public' AND table_name = 'community_settings'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'community_settings' AND column_name = 'platform'
  ) THEN
    DROP TABLE public.community_settings CASCADE;
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS public.community_settings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  platform TEXT NOT NULL UNIQUE CHECK (platform IN ('tiktok', 'instagram', 'youtube')),
  daily_limit INTEGER NOT NULL DEFAULT 100,
  reward_per_task NUMERIC(10, 2) NOT NULL DEFAULT 5.00,
  is_active BOOLEAN NOT NULL DEFAULT true,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.community_settings (platform, daily_limit, reward_per_task)
VALUES
  ('tiktok', 100, 5.00),
  ('instagram', 100, 5.00),
  ('youtube', 100, 5.00)
ON CONFLICT (platform) DO NOTHING;

-- community_tasks
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'public' AND table_name = 'community_tasks'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'community_tasks' AND column_name = 'profile_url'
  ) THEN
    DROP TABLE public.community_tasks CASCADE;
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS public.community_tasks (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  creator_user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  platform TEXT NOT NULL CHECK (platform IN ('tiktok', 'instagram', 'youtube', 'other')),
  task_type TEXT NOT NULL CHECK (task_type IN ('follow', 'like', 'comment', 'view')),
  profile_url TEXT NOT NULL,
  description TEXT,
  max_completions INTEGER NOT NULL DEFAULT 50,
  current_completions INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  reward_amount NUMERIC(10, 2) NOT NULL DEFAULT 5.00,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- task_distribution_queue
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'public' AND table_name = 'task_distribution_queue'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'task_distribution_queue' AND column_name = 'task_id'
  ) THEN
    DROP TABLE public.task_distribution_queue CASCADE;
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS public.task_distribution_queue (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  task_id UUID NOT NULL REFERENCES public.community_tasks(id) ON DELETE CASCADE,
  platform TEXT NOT NULL,
  task_type TEXT NOT NULL,
  profile_url TEXT NOT NULL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'ASSIGNED'
    CHECK (status IN ('ASSIGNED', 'COMPLETED', 'REPORTED', 'EXPIRED')),
  assigned_at TIMESTAMPTZ DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  UNIQUE (user_id, task_id)
);

CREATE INDEX IF NOT EXISTS idx_task_queue_user
  ON public.task_distribution_queue (user_id, status);

-- task_reports
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'public' AND table_name = 'task_reports'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'task_reports' AND column_name = 'reporter_user_id'
  ) THEN
    DROP TABLE public.task_reports CASCADE;
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS public.task_reports (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  reporter_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  task_id UUID NOT NULL REFERENCES public.community_tasks(id) ON DELETE CASCADE,
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING'
    CHECK (status IN ('PENDING', 'REVIEWED', 'DISMISSED')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- --------------------------------------------------------------------
-- 6. Grants & RLS para as novas tabelas
-- --------------------------------------------------------------------
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.subscription_payments TO service_role;
GRANT SELECT, INSERT ON TABLE public.subscription_payments TO authenticated;

GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.engagement_orders TO service_role;
GRANT SELECT, INSERT ON TABLE public.engagement_orders TO authenticated;

GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.campaign_requests TO service_role;
GRANT SELECT, INSERT ON TABLE public.campaign_requests TO authenticated;

GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.community_settings TO service_role;
GRANT SELECT ON TABLE public.community_settings TO authenticated;

GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.community_tasks TO service_role;
GRANT SELECT ON TABLE public.community_tasks TO authenticated;

GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.task_distribution_queue TO service_role;
GRANT SELECT, INSERT, UPDATE ON TABLE public.task_distribution_queue TO authenticated;

GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.task_reports TO service_role;
GRANT SELECT, INSERT ON TABLE public.task_reports TO authenticated;

ALTER TABLE public.subscription_payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.engagement_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.campaign_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.community_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.community_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.task_distribution_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.task_reports ENABLE ROW LEVEL SECURITY;

-- Policies: subscription_payments
DROP POLICY IF EXISTS "sub_payments_select" ON public.subscription_payments;
CREATE POLICY "sub_payments_select" ON public.subscription_payments
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "sub_payments_insert" ON public.subscription_payments;
CREATE POLICY "sub_payments_insert" ON public.subscription_payments
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Policies: engagement_orders
DROP POLICY IF EXISTS "eng_orders_select" ON public.engagement_orders;
CREATE POLICY "eng_orders_select" ON public.engagement_orders
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "eng_orders_insert" ON public.engagement_orders;
CREATE POLICY "eng_orders_insert" ON public.engagement_orders
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Policies: campaign_requests
DROP POLICY IF EXISTS "camp_req_select" ON public.campaign_requests;
CREATE POLICY "camp_req_select" ON public.campaign_requests
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "camp_req_insert" ON public.campaign_requests;
CREATE POLICY "camp_req_insert" ON public.campaign_requests
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Policies: community
DROP POLICY IF EXISTS "comm_settings_select" ON public.community_settings;
CREATE POLICY "comm_settings_select" ON public.community_settings
  FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "comm_tasks_select" ON public.community_tasks;
CREATE POLICY "comm_tasks_select" ON public.community_tasks
  FOR SELECT TO authenticated USING (is_active = true OR public.is_admin());

DROP POLICY IF EXISTS "task_queue_select" ON public.task_distribution_queue;
CREATE POLICY "task_queue_select" ON public.task_distribution_queue
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "task_queue_update" ON public.task_distribution_queue;
CREATE POLICY "task_queue_update" ON public.task_distribution_queue
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "task_reports_insert" ON public.task_reports;
CREATE POLICY "task_reports_insert" ON public.task_reports
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = reporter_user_id);

DROP POLICY IF EXISTS "task_reports_select" ON public.task_reports;
CREATE POLICY "task_reports_select" ON public.task_reports
  FOR SELECT TO authenticated
  USING (auth.uid() = reporter_user_id OR public.is_admin());

-- --------------------------------------------------------------------
-- 7. RPCs – complete_account_setup (usado pelo AccountSetup.tsx)
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.complete_account_setup(
  p_user_id UUID,
  p_name TEXT,
  p_phone TEXT,
  p_primary_link TEXT DEFAULT NULL,
  p_invite_code TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_caller UUID := auth.uid();
  v_first_login BOOLEAN;
  v_affiliate RECORD;
  v_clean_code TEXT;
  v_user_wallet_id UUID;
  v_affiliate_wallet_id UUID;
  v_bonus_applied BOOLEAN := FALSE;
  v_referral_code TEXT;
BEGIN
  IF v_caller IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;

  -- Só o próprio utilizador (ou admin) pode completar o setup
  IF v_caller != p_user_id AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'Permissão negada.';
  END IF;

  SELECT first_login INTO v_first_login
  FROM public.profiles WHERE id = p_user_id;

  IF v_first_login IS NOT TRUE THEN
    RETURN jsonb_build_object('success', false, 'message', 'O setup desta conta já foi concluído.');
  END IF;

  -- Garantir carteira
  INSERT INTO public.wallets (user_id, balance, reserved_balance)
  VALUES (p_user_id, 0.00, 0.00)
  ON CONFLICT (user_id) DO NOTHING;

  SELECT id INTO v_user_wallet_id FROM public.wallets WHERE user_id = p_user_id;

  -- Gerar referral_code único se ainda não existir
  SELECT referral_code INTO v_referral_code FROM public.profiles WHERE id = p_user_id;
  IF v_referral_code IS NULL OR length(trim(v_referral_code)) = 0 THEN
    v_referral_code := 'ADX' || upper(substr(replace(p_user_id::text, '-', ''), 1, 8));
  END IF;

  -- Processar código de convite
  IF p_invite_code IS NOT NULL AND length(trim(p_invite_code)) > 0 THEN
    v_clean_code := upper(trim(p_invite_code));

    -- Procurar em affiliate_profiles ou em profiles.referral_code
    SELECT ap.* INTO v_affiliate
    FROM public.affiliate_profiles ap
    WHERE upper(ap.affiliate_code) = v_clean_code AND ap.is_active = true;

    IF v_affiliate.id IS NULL THEN
      -- Fallback: profiles.referral_code OU custom_affiliate_code (Gold+)
      SELECT p.id AS user_id,
             COALESCE(p.custom_affiliate_code, p.referral_code) AS affiliate_code,
             true AS is_active
      INTO v_affiliate
      FROM public.profiles p
      WHERE p.id != p_user_id
        AND p.is_active = true
        AND (
          upper(COALESCE(p.referral_code, '')) = v_clean_code
          OR upper(COALESCE(p.custom_affiliate_code, '')) = v_clean_code
        )
      LIMIT 1;
    END IF;

    IF v_affiliate.user_id IS NOT NULL AND v_affiliate.user_id != p_user_id THEN
      IF NOT EXISTS (SELECT 1 FROM public.affiliate_referrals WHERE referred_user_id = p_user_id) THEN
        INSERT INTO public.affiliate_referrals (
          affiliate_user_id, referred_user_id, affiliate_code,
          bonus_user, commission_affiliate, status
        ) VALUES (
          v_affiliate.user_id, p_user_id, v_clean_code,
          250.00, 500.00, 'COMPLETED'
        );

        -- Bónus utilizador +250 Kz
        UPDATE public.wallets
        SET balance = balance + 250.00, updated_at = NOW()
        WHERE id = v_user_wallet_id;

        INSERT INTO public.wallet_transactions (
          wallet_id, user_id, type, amount, description, reference_id, status
        ) VALUES (
          v_user_wallet_id, p_user_id, 'SIGNUP_BONUS', 250.00,
          'Bónus de primeiro acesso via convite', v_clean_code, 'COMPLETED'
        );

        -- Comissão afiliado +500 Kz
        INSERT INTO public.wallets (user_id, balance, reserved_balance)
        VALUES (v_affiliate.user_id, 0.00, 0.00)
        ON CONFLICT (user_id) DO NOTHING;

        SELECT id INTO v_affiliate_wallet_id
        FROM public.wallets WHERE user_id = v_affiliate.user_id;

        UPDATE public.wallets
        SET balance = balance + 500.00, updated_at = NOW()
        WHERE id = v_affiliate_wallet_id;

        INSERT INTO public.wallet_transactions (
          wallet_id, user_id, type, amount, description, reference_id, status
        ) VALUES (
          v_affiliate_wallet_id, v_affiliate.user_id, 'AFFILIATE_COMMISSION', 500.00,
          'Comissão de novo utilizador indicado: ' || COALESCE(p_name, 'Novo Utilizador'),
          p_user_id::text, 'COMPLETED'
        );

        -- Atualizar stats do afiliado se existir perfil de afiliado
        UPDATE public.affiliate_profiles
        SET total_referrals = total_referrals + 1,
            total_earned = total_earned + 500.00,
            updated_at = NOW()
        WHERE user_id = v_affiliate.user_id;

        UPDATE public.profiles
        SET invited_by = v_affiliate.user_id,
            referred_completed = true
        WHERE id = p_user_id;

        v_bonus_applied := TRUE;
      END IF;
    END IF;
  END IF;

  -- Atualizar perfil
  UPDATE public.profiles
  SET name = COALESCE(NULLIF(trim(p_name), ''), name),
      phone = COALESCE(NULLIF(trim(p_phone), ''), phone),
      primary_link = NULLIF(trim(p_primary_link), ''),
      referral_code = v_referral_code,
      first_login = false,
      updated_at = NOW()
  WHERE id = p_user_id;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (
    p_user_id,
    'ACCOUNT_SETUP_COMPLETED',
    'Configuração inicial concluída',
    CASE WHEN v_bonus_applied
      THEN 'Com bónus de afiliado de 250 Kz aplicado.'
      ELSE 'Concluído sem código de convite.'
    END
  );

  RETURN jsonb_build_object(
    'success', true,
    'message', CASE WHEN v_bonus_applied
      THEN 'Conta configurada com sucesso! Recebeu 250 Kz de bónus.'
      ELSE 'Conta configurada com sucesso!'
    END,
    'bonus_applied', v_bonus_applied
  );
END;
$$;

-- --------------------------------------------------------------------
-- 8. RPC submit_subscription_payment
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.submit_subscription_payment(
  p_amount NUMERIC,
  p_currency TEXT,
  p_method TEXT,
  p_proof_url TEXT DEFAULT NULL,
  p_payment_date TEXT DEFAULT NULL   -- aceite mas ignorado (compatibilidade com frontend)
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_user_id UUID := auth.uid();
  v_payment_id UUID;
BEGIN
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;

  IF p_amount IS NULL OR p_amount <= 0 THEN
    RAISE EXCEPTION 'Valor inválido.';
  END IF;

  INSERT INTO public.subscription_payments (
    user_id, amount, currency, method, proof_url, status
  ) VALUES (
    v_user_id, p_amount, COALESCE(p_currency, 'AOA'), p_method, p_proof_url, 'PENDING'
  )
  RETURNING id INTO v_payment_id;

  -- Marcar perfil como pending
  UPDATE public.profiles
  SET subscription_status = 'pending', updated_at = NOW()
  WHERE id = v_user_id;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (v_user_id, 'SUBSCRIPTION_SUBMITTED', 'Pedido de assinatura enviado', p_method);

  RETURN jsonb_build_object('success', true, 'payment_id', v_payment_id);
END;
$$;

-- --------------------------------------------------------------------
-- 9. RPC admin_process_subscription_payment
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.admin_process_subscription_payment(
  p_payment_id UUID,
  p_status TEXT,
  p_rejection_reason TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_admin UUID := auth.uid();
  v_payment RECORD;
BEGIN
  IF v_admin IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores podem processar assinaturas.';
  END IF;

  IF p_status NOT IN ('APPROVED', 'REJECTED') THEN
    RAISE EXCEPTION 'Status inválido. Use APPROVED ou REJECTED.';
  END IF;

  SELECT * INTO v_payment
  FROM public.subscription_payments
  WHERE id = p_payment_id
  FOR UPDATE;

  IF v_payment.id IS NULL THEN
    RAISE EXCEPTION 'Pagamento não encontrado.';
  END IF;

  IF v_payment.status != 'PENDING' THEN
    RAISE EXCEPTION 'Este pagamento já foi processado.';
  END IF;

  UPDATE public.subscription_payments
  SET status = p_status,
      rejection_reason = CASE WHEN p_status = 'REJECTED' THEN p_rejection_reason ELSE NULL END,
      processed_at = NOW(),
      processed_by = v_admin,
      updated_at = NOW()
  WHERE id = p_payment_id;

  IF p_status = 'APPROVED' THEN
    UPDATE public.profiles
    SET subscription_status = 'active',
        subscription_onboarding_completed = true,
        updated_at = NOW()
    WHERE id = v_payment.user_id;
  ELSE
    UPDATE public.profiles
    SET subscription_status = 'visitor',
        updated_at = NOW()
    WHERE id = v_payment.user_id;
  END IF;

  INSERT INTO public.activity_logs (user_id, action_type, title, details, metadata)
  VALUES (
    v_payment.user_id,
    'SUBSCRIPTION_' || p_status,
    'Assinatura ' || lower(p_status),
    COALESCE(p_rejection_reason, 'Processado pelo admin'),
    jsonb_build_object('payment_id', p_payment_id, 'admin_id', v_admin)
  );

  RETURN jsonb_build_object('success', true, 'status', p_status);
END;
$$;

-- --------------------------------------------------------------------
-- 10. RPC submit_engagement_order (Loja)
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.submit_engagement_order(
  p_platform TEXT,
  p_service_type TEXT,
  p_target_link TEXT,
  p_quantity INTEGER,
  p_total_price NUMERIC,
  p_currency TEXT,
  p_method TEXT,
  p_proof_url TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_user_id UUID := auth.uid();
  v_order_id UUID;
BEGIN
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;

  IF p_quantity IS NULL OR p_quantity <= 0 THEN
    RAISE EXCEPTION 'Quantidade inválida.';
  END IF;

  IF p_target_link IS NULL OR length(trim(p_target_link)) < 5 THEN
    RAISE EXCEPTION 'Link de destino inválido.';
  END IF;

  INSERT INTO public.engagement_orders (
    user_id, platform, service_type, target_link, quantity,
    total_price, currency, method, proof_url, status
  ) VALUES (
    v_user_id, p_platform, p_service_type, trim(p_target_link), p_quantity,
    p_total_price, COALESCE(p_currency, 'USD'), p_method, p_proof_url, 'PENDING'
  )
  RETURNING id INTO v_order_id;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (
    v_user_id,
    'ENGAGEMENT_ORDER_CREATED',
    'Pedido de engajamento criado',
    p_platform || ' • ' || p_service_type || ' × ' || p_quantity
  );

  RETURN jsonb_build_object(
    'success', true,
    'order_id', v_order_id,
    'short_code', upper(substr(v_order_id::text, 1, 8))
  );
END;
$$;

-- --------------------------------------------------------------------
-- 11. Community Tasks RPCs
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.fetch_or_assign_community_tasks()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_user_id UUID := auth.uid();
  v_result jsonb;
BEGIN
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;

  -- Atribuir até 5 tarefas ativas que o utilizador ainda não tem
  INSERT INTO public.task_distribution_queue (
    user_id, task_id, platform, task_type, profile_url, description, status
  )
  SELECT
    v_user_id,
    ct.id,
    ct.platform,
    ct.task_type,
    ct.profile_url,
    ct.description,
    'ASSIGNED'
  FROM public.community_tasks ct
  WHERE ct.is_active = true
    AND ct.current_completions < ct.max_completions
    AND NOT EXISTS (
      SELECT 1 FROM public.task_distribution_queue tq
      WHERE tq.user_id = v_user_id AND tq.task_id = ct.id
    )
  ORDER BY ct.created_at DESC
  LIMIT 5
  ON CONFLICT (user_id, task_id) DO NOTHING;

  -- Devolver as tarefas ASSIGNED do utilizador
  SELECT coalesce(jsonb_agg(
    jsonb_build_object(
      'id', tq.id,
      'task_id', tq.task_id,
      'platform', tq.platform,
      'task_type', tq.task_type,
      'profile_url', tq.profile_url,
      'description', tq.description,
      'status', tq.status
    )
  ), '[]'::jsonb)
  INTO v_result
  FROM public.task_distribution_queue tq
  WHERE tq.user_id = v_user_id AND tq.status = 'ASSIGNED';

  RETURN v_result;
END;
$$;

CREATE OR REPLACE FUNCTION public.complete_community_task(p_task_id UUID)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_user_id UUID := auth.uid();
  v_queue RECORD;
  v_reward NUMERIC(10, 2);
  v_wallet_id UUID;
BEGIN
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;

  SELECT * INTO v_queue
  FROM public.task_distribution_queue
  WHERE user_id = v_user_id AND task_id = p_task_id AND status = 'ASSIGNED'
  FOR UPDATE;

  IF v_queue.id IS NULL THEN
    RAISE EXCEPTION 'Tarefa não encontrada ou já concluída.';
  END IF;

  UPDATE public.task_distribution_queue
  SET status = 'COMPLETED', completed_at = NOW()
  WHERE id = v_queue.id;

  UPDATE public.community_tasks
  SET current_completions = current_completions + 1, updated_at = NOW()
  WHERE id = p_task_id;

  -- Creditar recompensa
  SELECT reward_amount INTO v_reward FROM public.community_tasks WHERE id = p_task_id;
  v_reward := COALESCE(v_reward, 5.00);

  INSERT INTO public.wallets (user_id, balance, reserved_balance)
  VALUES (v_user_id, 0.00, 0.00)
  ON CONFLICT (user_id) DO NOTHING;

  SELECT id INTO v_wallet_id FROM public.wallets WHERE user_id = v_user_id FOR UPDATE;

  UPDATE public.wallets
  SET balance = balance + v_reward, updated_at = NOW()
  WHERE id = v_wallet_id;

  INSERT INTO public.wallet_transactions (
    wallet_id, user_id, type, amount, description, reference_id, status
  ) VALUES (
    v_wallet_id, v_user_id, 'CAMPAIGN_REWARD', v_reward,
    'Tarefa de comunidade concluída', p_task_id::text, 'COMPLETED'
  );

  RETURN jsonb_build_object('success', true, 'reward', v_reward);
END;
$$;

CREATE OR REPLACE FUNCTION public.report_community_task(
  p_task_id UUID,
  p_reason TEXT
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_user_id UUID := auth.uid();
BEGIN
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;

  IF p_reason IS NULL OR length(trim(p_reason)) < 3 THEN
    RAISE EXCEPTION 'Motivo da denúncia é obrigatório.';
  END IF;

  INSERT INTO public.task_reports (reporter_user_id, task_id, reason)
  VALUES (v_user_id, p_task_id, trim(p_reason));

  UPDATE public.task_distribution_queue
  SET status = 'REPORTED'
  WHERE user_id = v_user_id AND task_id = p_task_id AND status = 'ASSIGNED';

  RETURN jsonb_build_object('success', true);
END;
$$;

-- --------------------------------------------------------------------
-- 12. Manter compatibilidade com complete_first_access (legado)
-- --------------------------------------------------------------------
-- A função completa_first_access já existe na 003.
-- O frontend atual usa complete_account_setup.
-- Ambas podem coexistir sem conflito.

-- --------------------------------------------------------------------
-- 13. Comentários de Storage (criar manualmente no Dashboard Supabase)
-- --------------------------------------------------------------------
-- Criar os buckets (se ainda não existirem):
--   1. subscription-proofs  (private)
--   2. proofs               (private)  – fallback usado em alguns componentes
--
-- Policies sugeridas para o bucket subscription-proofs:
--   - authenticated pode fazer UPLOAD no path {user_id}/*
--   - authenticated pode ler apenas os seus próprios ficheiros
--   - admin (via service_role ou is_admin) pode ler tudo
--
-- Exemplo de policy (Storage → Policies):
--   INSERT: (bucket_id = 'subscription-proofs' AND auth.uid()::text = (storage.foldername(name))[1])
--   SELECT: (bucket_id = 'subscription-proofs' AND (auth.uid()::text = (storage.foldername(name))[1] OR public.is_admin()))

COMMENT ON TABLE public.subscription_payments IS 'Pedidos de pagamento de assinatura anual – alinhado com frontend';
COMMENT ON TABLE public.engagement_orders IS 'Pedidos da Loja (seguidores, gostos, etc.)';
COMMENT ON TABLE public.campaign_requests IS 'Solicitações de campanha coletiva (10 USD)';
COMMENT ON TABLE public.community_tasks IS 'Pool de tarefas de comunidade disponíveis';
COMMENT ON TABLE public.task_distribution_queue IS 'Tarefas atribuídas a cada utilizador';

-- --------------------------------------------------------------------
-- 14. Atualizar trigger handle_new_user para incluir novos campos
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
BEGIN
  INSERT INTO public.profiles (
    id, name, first_name, last_name, email, role,
    first_login, is_active, subscription_status, country
  )
  VALUES (
    new.id,
    COALESCE(
      new.raw_user_meta_data ->> 'name',
      (new.raw_user_meta_data ->> 'first_name') || ' ' || (new.raw_user_meta_data ->> 'last_name'),
      split_part(new.email, '@', 1)
    ),
    new.raw_user_meta_data ->> 'first_name',
    new.raw_user_meta_data ->> 'last_name',
    new.email,
    COALESCE(new.raw_user_meta_data ->> 'role', 'user'),
    true,
    true,
    'visitor',
    COALESCE(new.raw_user_meta_data ->> 'country', 'Angola')
  )
  ON CONFLICT (id) DO UPDATE
  SET email = EXCLUDED.email;

  INSERT INTO public.wallets (user_id, balance, reserved_balance)
  VALUES (new.id, 0.00, 0.00)
  ON CONFLICT (user_id) DO NOTHING;

  RETURN new;
END;
$$;
