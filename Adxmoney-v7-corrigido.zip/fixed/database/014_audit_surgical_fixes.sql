-- ====================================================================
-- 014 — Correções cirúrgicas da auditoria (idempotente, só CREATE OR REPLACE / GRANT / POLICY)
-- Executar UMA vez no SQL Editor, depois de 013.
-- Não apaga dados, não altera colunas existentes.
-- ====================================================================

-- --------------------------------------------------------------------
-- 1) CRÍTICO: handle_new_user NUNCA confia no role vindo do metadata
--    (antes: signUp com data {role:'admin'} criava um administrador)
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
BEGIN
  INSERT INTO public.profiles (
    id, name, first_name, last_name, email, role,
    first_login, is_active, subscription_status, country
  )
  VALUES (
    new.id,
    COALESCE(
      NULLIF(trim(new.raw_user_meta_data ->> 'name'), ''),
      NULLIF(trim(concat_ws(' ', new.raw_user_meta_data ->> 'first_name', new.raw_user_meta_data ->> 'last_name')), ''),
      split_part(new.email, '@', 1)
    ),
    new.raw_user_meta_data ->> 'first_name',
    new.raw_user_meta_data ->> 'last_name',
    new.email,
    'user',
    true,
    true,
    'visitor',
    COALESCE(new.raw_user_meta_data ->> 'country', 'Angola')
  )
  ON CONFLICT (id) DO UPDATE
  SET email = EXCLUDED.email;

  INSERT INTO public.wallets (user_id, balance, reserved_balance)
  VALUES (new.id, 0.00, 0.00)
  ON CONFLICT (user_id) DO NOTHING;

  RETURN new;
END;
$$;

-- Coluna usada pela Edge Function admin-create-user (não existia → criação falhava)
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS facebook TEXT;

-- Guard de colunas sensíveis: service_role (Edge Functions) passa; utilizador normal continua protegido
-- e first_login deixa de poder voltar a true (evitava repetir o setup/bónus).
CREATE OR REPLACE FUNCTION public.protect_profile_sensitive_columns()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
BEGIN
  IF current_setting('app.skip_profile_guard', true) = 'on' THEN
    RETURN NEW;
  END IF;

  IF COALESCE(auth.role(), '') = 'service_role' THEN
    RETURN NEW;
  END IF;

  IF public.is_admin() THEN
    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    NEW.role := OLD.role;
    NEW.subscription_status := OLD.subscription_status;
    NEW.is_active := OLD.is_active;
    NEW.member_level := OLD.member_level;
    NEW.priority_withdrawal := OLD.priority_withdrawal;
    NEW.level_updated_at := OLD.level_updated_at;
    NEW.custom_affiliate_code := OLD.custom_affiliate_code;
    -- first_login só pode ir de true → false
    IF OLD.first_login IS FALSE THEN
      NEW.first_login := FALSE;
    END IF;
    IF NEW.suspended_until IS DISTINCT FROM OLD.suspended_until THEN
      NEW.suspended_until := OLD.suspended_until;
    END IF;
  END IF;

  RETURN NEW;
END;
$fn$;

-- Função legada que insere directo em auth.users (sem identities → login impossível): desligar
REVOKE EXECUTE ON FUNCTION public.admin_create_user(text, text, text, text, text) FROM PUBLIC, anon, authenticated;

-- --------------------------------------------------------------------
-- 2) Inserção directa em tabelas financeiras: só via RPC
--    (antes: utilizador podia inserir linha com status APPROVED / valores livres)
-- --------------------------------------------------------------------
REVOKE INSERT ON TABLE public.subscription_payments FROM authenticated;
REVOKE INSERT ON TABLE public.engagement_orders     FROM authenticated;
REVOKE INSERT ON TABLE public.campaign_requests     FROM authenticated;
REVOKE INSERT ON TABLE public.wallet_deposits       FROM authenticated;
REVOKE UPDATE ON TABLE public.task_distribution_queue FROM authenticated;

-- Admin precisa de UPDATE em engagement_orders (o painel faz update directo) — policy só admin
GRANT UPDATE ON TABLE public.engagement_orders TO authenticated;
DROP POLICY IF EXISTS "eng_orders_admin_update" ON public.engagement_orders;
CREATE POLICY "eng_orders_admin_update" ON public.engagement_orders
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- Admin precisa de INSERT/UPDATE em community_tasks (painel lança tarefas)
GRANT INSERT, UPDATE ON TABLE public.community_tasks TO authenticated;
DROP POLICY IF EXISTS "comm_tasks_admin_write" ON public.community_tasks;
CREATE POLICY "comm_tasks_admin_write" ON public.community_tasks
  FOR ALL TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- --------------------------------------------------------------------
-- 3) Ledger: tipo de reembolso
-- --------------------------------------------------------------------
ALTER TABLE public.wallet_transactions
  DROP CONSTRAINT IF EXISTS wallet_transactions_type_check;
ALTER TABLE public.wallet_transactions
  ADD CONSTRAINT wallet_transactions_type_check CHECK (type IN (
    'SIGNUP_BONUS', 'AFFILIATE_COMMISSION', 'CAMPAIGN_REWARD', 'CAMPAIGN_TOKEN',
    'CAMPAIGN_REFUND', 'DEPOSIT', 'WITHDRAWAL_LOCK', 'WITHDRAWAL_PAID',
    'WITHDRAWAL_REFUND', 'MANUAL_ADJUSTMENT'
  ));

-- --------------------------------------------------------------------
-- 4) Pedido de campanha: preço fixo no servidor + reembolso ao rejeitar
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.submit_paid_campaign_request(
  p_title TEXT,
  p_platform TEXT,
  p_target_url TEXT,
  p_action_type TEXT DEFAULT 'follow',
  p_objective TEXT DEFAULT NULL,
  p_description TEXT DEFAULT NULL,
  p_target_audience TEXT DEFAULT 'Geral',
  p_requester_phone TEXT DEFAULT NULL,
  p_cost_kz NUMERIC DEFAULT 9500,   -- ignorado: preço é fixo no servidor
  p_additional_information TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_wallet RECORD;
  v_req_id UUID;
  v_cost CONSTANT NUMERIC := 9500;
  v_platform TEXT;
  v_active BOOLEAN;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;

  SELECT is_active INTO v_active FROM public.profiles WHERE id = v_uid;
  IF v_active IS DISTINCT FROM TRUE THEN
    RAISE EXCEPTION 'Conta inactiva.';
  END IF;

  IF p_title IS NULL OR length(trim(p_title)) < 3 THEN
    RAISE EXCEPTION 'Título inválido.';
  END IF;
  IF p_target_url IS NULL OR length(trim(p_target_url)) < 5 THEN
    RAISE EXCEPTION 'URL alvo inválida.';
  END IF;

  v_platform := COALESCE(NULLIF(trim(p_platform), ''), 'Instagram');
  IF lower(v_platform) LIKE '%tiktok%' THEN v_platform := 'TikTok';
  ELSIF lower(v_platform) LIKE '%insta%' THEN v_platform := 'Instagram';
  ELSIF lower(v_platform) LIKE '%you%' THEN v_platform := 'YouTube';
  END IF;

  INSERT INTO public.wallets (user_id, balance, reserved_balance)
  VALUES (v_uid, 0, 0)
  ON CONFLICT (user_id) DO NOTHING;

  SELECT * INTO v_wallet FROM public.wallets WHERE user_id = v_uid FOR UPDATE;

  IF v_wallet.balance < v_cost THEN
    RETURN jsonb_build_object(
      'success', false, 'error', 'Saldo insuficiente.',
      'balance', v_wallet.balance, 'required', v_cost
    );
  END IF;

  INSERT INTO public.campaign_requests (
    user_id, title, platform, target_url, action_type, objective, description,
    target_audience, requester_phone, cost_usd, currency, amount_paid, status, additional_information
  ) VALUES (
    v_uid, trim(p_title), v_platform, trim(p_target_url),
    COALESCE(NULLIF(trim(p_action_type), ''), 'follow'),
    NULLIF(trim(COALESCE(p_objective, '')), ''),
    NULLIF(trim(COALESCE(p_description, '')), ''),
    COALESCE(NULLIF(trim(p_target_audience), ''), 'Geral'),
    NULLIF(trim(COALESCE(p_requester_phone, '')), ''),
    ROUND(v_cost / 950.0, 2), 'AOA', v_cost, 'PENDING',
    NULLIF(trim(COALESCE(p_additional_information, '')), '')
  )
  RETURNING id INTO v_req_id;

  UPDATE public.wallets SET balance = balance - v_cost, updated_at = NOW() WHERE id = v_wallet.id;

  INSERT INTO public.wallet_transactions (wallet_id, user_id, type, amount, description, reference_id, status)
  VALUES (v_wallet.id, v_uid, 'CAMPAIGN_TOKEN', -v_cost,
          'Taxa de solicitação de campanha: ' || trim(p_title), v_req_id::text, 'COMPLETED');

  RETURN jsonb_build_object('success', true, 'request_id', v_req_id, 'charged', v_cost, 'status', 'PENDING');
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_process_campaign_request(
  p_request_id UUID,
  p_status TEXT,
  p_rejection_reason TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_admin UUID := auth.uid();
  v_req RECORD;
  v_wallet RECORD;
  v_refunded BOOLEAN := FALSE;
BEGIN
  IF v_admin IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores podem processar pedidos.';
  END IF;
  IF p_status NOT IN ('APPROVED', 'REJECTED') THEN
    RAISE EXCEPTION 'Status inválido.';
  END IF;

  SELECT * INTO v_req FROM public.campaign_requests WHERE id = p_request_id FOR UPDATE;
  IF v_req.id IS NULL THEN
    RAISE EXCEPTION 'Pedido não encontrado.';
  END IF;
  IF v_req.status <> 'PENDING' THEN
    RAISE EXCEPTION 'Este pedido já foi processado (%).', v_req.status;
  END IF;

  IF p_status = 'REJECTED' AND COALESCE(v_req.amount_paid, 0) > 0 THEN
    SELECT * INTO v_wallet FROM public.wallets WHERE user_id = v_req.user_id FOR UPDATE;
    IF v_wallet.id IS NOT NULL THEN
      UPDATE public.wallets SET balance = balance + v_req.amount_paid, updated_at = NOW()
      WHERE id = v_wallet.id;
      INSERT INTO public.wallet_transactions (wallet_id, user_id, type, amount, description, reference_id, status)
      VALUES (v_wallet.id, v_req.user_id, 'CAMPAIGN_REFUND', v_req.amount_paid,
              'Reembolso de pedido de campanha rejeitado: ' || v_req.title, v_req.id::text, 'COMPLETED');
      v_refunded := TRUE;
    END IF;
  END IF;

  UPDATE public.campaign_requests
  SET status = p_status,
      rejection_reason = CASE WHEN p_status = 'REJECTED'
                              THEN COALESCE(NULLIF(trim(COALESCE(p_rejection_reason, '')), ''), 'Rejeitado pela administração')
                              ELSE NULL END,
      processed_at = NOW(), processed_by = v_admin, updated_at = NOW()
  WHERE id = v_req.id;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (v_req.user_id, 'CAMPAIGN_REQUEST_' || p_status,
          CASE WHEN p_status = 'APPROVED' THEN 'Pedido de campanha aprovado' ELSE 'Pedido de campanha rejeitado' END,
          CASE WHEN v_refunded THEN 'Valor reembolsado na carteira: ' || v_req.amount_paid || ' Kz' ELSE v_req.title END);

  RETURN jsonb_build_object('success', true, 'status', p_status, 'refunded', v_refunded);
END;
$$;
GRANT EXECUTE ON FUNCTION public.admin_process_campaign_request(UUID, TEXT, TEXT) TO authenticated;

-- --------------------------------------------------------------------
-- 5) Depósito: comprovativo tem de estar na pasta do próprio utilizador
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.submit_wallet_deposit(
  p_amount NUMERIC, p_currency TEXT, p_method TEXT, p_proof_url TEXT
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_id UUID;
  v_amount NUMERIC;
  v_active BOOLEAN;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;

  SELECT is_active INTO v_active FROM public.profiles WHERE id = v_uid;
  IF v_active IS DISTINCT FROM TRUE THEN RAISE EXCEPTION 'Conta inactiva.'; END IF;

  v_amount := ROUND(COALESCE(p_amount, 0)::numeric, 2);
  IF v_amount < 1000 THEN RAISE EXCEPTION 'O valor mínimo de depósito é 1.000 Kz.'; END IF;
  IF v_amount > 5000000 THEN RAISE EXCEPTION 'O valor máximo de depósito é 5.000.000 Kz.'; END IF;

  IF p_method IS NULL OR length(trim(p_method)) < 3 THEN
    RAISE EXCEPTION 'Método de pagamento inválido.';
  END IF;

  IF p_proof_url IS NULL OR left(trim(p_proof_url), length('deposits/' || v_uid::text || '/')) <> ('deposits/' || v_uid::text || '/') THEN
    RAISE EXCEPTION 'Comprovativo inválido para este utilizador.';
  END IF;

  IF (SELECT count(*) FROM public.wallet_deposits WHERE user_id = v_uid AND status = 'PENDING') >= 5 THEN
    RAISE EXCEPTION 'Tem demasiados depósitos pendentes. Aguarde a validação.';
  END IF;

  INSERT INTO public.wallet_deposits (user_id, amount, currency, method, proof_url, status)
  VALUES (v_uid, v_amount, COALESCE(NULLIF(trim(p_currency), ''), 'AOA'), trim(p_method), trim(p_proof_url), 'PENDING')
  RETURNING id INTO v_id;

  RETURN jsonb_build_object('success', true, 'id', v_id, 'amount', v_amount, 'status', 'PENDING');
END;
$$;

-- --------------------------------------------------------------------
-- 6) Assinatura: UMA versão canónica (as 3 anteriores divergiam entre si)
--    - preço calculado no servidor (4.900 Kz base) por moeda
--    - não rebaixa assinante activo; estado 'pending' agora persiste (guard desligado)
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.submit_subscription_payment(
  p_amount NUMERIC,                -- ignorado: preço é do servidor
  p_currency TEXT,
  p_method TEXT,
  p_proof_url TEXT DEFAULT NULL,
  p_payment_date TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_pay_id UUID;
  v_cur TEXT := upper(trim(coalesce(p_currency, 'AOA')));
  v_meth TEXT := upper(trim(split_part(coalesce(p_method, ''), ' ', 1)));
  v_details TEXT := trim(coalesce(p_method, ''));
  v_base_aoa CONSTANT NUMERIC := 4900.00;
  v_amount NUMERIC;
  v_status TEXT;
  v_active BOOLEAN;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;

  SELECT subscription_status, is_active INTO v_status, v_active FROM public.profiles WHERE id = v_uid;
  IF v_active IS DISTINCT FROM TRUE THEN RAISE EXCEPTION 'Conta inactiva.'; END IF;
  IF v_status = 'active' THEN RAISE EXCEPTION 'A sua assinatura já está activa.'; END IF;

  IF EXISTS (SELECT 1 FROM public.subscription_payments WHERE user_id = v_uid AND status = 'PENDING') THEN
    RAISE EXCEPTION 'Já tem um pagamento de assinatura em validação.';
  END IF;

  -- Taxas iguais às de submit_engagement_order (007e). CONFIRMAR antes de produção.
  v_amount := CASE v_cur
    WHEN 'AOA' THEN v_base_aoa
    WHEN 'USD' THEN round(v_base_aoa / 950.0, 2)
    WHEN 'EUR' THEN round(v_base_aoa / 950.0 * 0.92, 2)
    WHEN 'BRL' THEN round(v_base_aoa / 950.0 * 5.40, 2)
    ELSE NULL END;
  IF v_amount IS NULL THEN RAISE EXCEPTION 'Moeda não suportada.'; END IF;

  IF v_meth LIKE 'EXPRESS%' OR v_meth LIKE 'MULTICAIXA%' THEN v_meth := 'EXPRESS';
  ELSIF v_meth LIKE 'UNITEL%' THEN v_meth := 'UNITEL';
  ELSIF v_meth LIKE 'REMITLY%' THEN v_meth := 'REMITLY';
  ELSE RAISE EXCEPTION 'Método de pagamento inválido.';
  END IF;

  IF p_proof_url IS NULL OR split_part(trim(p_proof_url), '/', 1) <> v_uid::text THEN
    RAISE EXCEPTION 'Comprovativo inválido para este utilizador.';
  END IF;

  INSERT INTO public.subscription_payments (user_id, amount, currency, method, proof_url, status)
  VALUES (v_uid, v_amount, v_cur,
          v_meth || CASE WHEN length(v_details) > 20 THEN ' | ' || left(v_details, 400) ELSE '' END,
          trim(p_proof_url), 'PENDING')
  RETURNING id INTO v_pay_id;

  PERFORM set_config('app.skip_profile_guard', 'on', true);
  UPDATE public.profiles SET subscription_status = 'pending', updated_at = NOW() WHERE id = v_uid;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (v_uid, 'SUBSCRIPTION_SUBMITTED', 'Pedido de assinatura enviado', v_meth || ' / ' || v_cur);

  RETURN jsonb_build_object('success', true, 'payment_id', v_pay_id, 'amount', v_amount, 'currency', v_cur);
END;
$$;
REVOKE ALL ON FUNCTION public.submit_subscription_payment(NUMERIC, TEXT, TEXT, TEXT, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.submit_subscription_payment(NUMERIC, TEXT, TEXT, TEXT, TEXT) TO authenticated;

-- Rejeitar um pagamento NÃO pode rebaixar quem já é assinante activo
CREATE OR REPLACE FUNCTION public.admin_process_subscription_payment(
  p_payment_id UUID,
  p_status TEXT,
  p_rejection_reason TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_admin UUID := auth.uid();
  v_payment RECORD;
BEGIN
  IF v_admin IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores podem processar assinaturas.';
  END IF;
  IF p_status NOT IN ('APPROVED', 'REJECTED') THEN
    RAISE EXCEPTION 'Status inválido. Use APPROVED ou REJECTED.';
  END IF;

  SELECT * INTO v_payment FROM public.subscription_payments WHERE id = p_payment_id FOR UPDATE;
  IF v_payment.id IS NULL THEN RAISE EXCEPTION 'Pagamento não encontrado.'; END IF;
  IF v_payment.status <> 'PENDING' THEN RAISE EXCEPTION 'Este pagamento já foi processado.'; END IF;

  UPDATE public.subscription_payments
  SET status = p_status,
      rejection_reason = CASE WHEN p_status = 'REJECTED' THEN p_rejection_reason ELSE NULL END,
      processed_at = NOW(), processed_by = v_admin, updated_at = NOW()
  WHERE id = p_payment_id;

  IF p_status = 'APPROVED' THEN
    UPDATE public.profiles
    SET subscription_status = 'active', subscription_onboarding_completed = true, updated_at = NOW()
    WHERE id = v_payment.user_id;
  ELSE
    UPDATE public.profiles
    SET subscription_status = 'visitor', updated_at = NOW()
    WHERE id = v_payment.user_id AND subscription_status = 'pending';
  END IF;

  INSERT INTO public.activity_logs (user_id, action_type, title, details, metadata)
  VALUES (v_payment.user_id, 'SUBSCRIPTION_' || p_status, 'Assinatura ' || lower(p_status),
          COALESCE(p_rejection_reason, 'Processado pelo admin'),
          jsonb_build_object('payment_id', p_payment_id, 'admin_id', v_admin));

  RETURN jsonb_build_object('success', true, 'status', p_status);
END;
$$;

-- --------------------------------------------------------------------
-- 7) Saque: UMA versão canónica (lock antes de validar, mínimo 1.000, conta activa, sem suspensão)
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.request_withdrawal(
  p_amount NUMERIC,
  p_method TEXT,
  p_payment_details JSONB
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_wal RECORD;
  v_wid UUID;
  v_active BOOLEAN;
  v_susp TIMESTAMPTZ;
  v_amount NUMERIC;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;

  SELECT is_active, suspended_until INTO v_active, v_susp FROM public.profiles WHERE id = v_uid;
  IF v_active IS DISTINCT FROM TRUE THEN RAISE EXCEPTION 'Conta inactiva.'; END IF;
  IF v_susp IS NOT NULL AND v_susp > NOW() THEN RAISE EXCEPTION 'Conta suspensa temporariamente.'; END IF;

  v_amount := ROUND(COALESCE(p_amount, 0)::numeric, 2);
  IF v_amount <= 0 THEN RAISE EXCEPTION 'O valor do saque deve ser maior que zero.'; END IF;
  IF v_amount < 1000 THEN RAISE EXCEPTION 'Valor mínimo de saque: 1000 Kz.'; END IF;
  IF p_method IS NULL OR length(trim(p_method)) = 0 THEN
    RAISE EXCEPTION 'Informe o método de pagamento para o saque.';
  END IF;
  IF p_payment_details IS NOT NULL AND length(p_payment_details::text) > 4000 THEN
    RAISE EXCEPTION 'Dados de pagamento demasiado longos.';
  END IF;

  SELECT * INTO v_wal FROM public.wallets WHERE user_id = v_uid FOR UPDATE;
  IF v_wal.id IS NULL THEN RAISE EXCEPTION 'Carteira não encontrada.'; END IF;
  IF v_wal.balance < v_amount THEN
    RAISE EXCEPTION 'Saldo disponível insuficiente para realizar este saque.';
  END IF;

  UPDATE public.wallets
  SET balance = balance - v_amount, reserved_balance = reserved_balance + v_amount, updated_at = NOW()
  WHERE id = v_wal.id;

  INSERT INTO public.withdrawals (user_id, amount, method, payment_details, status, requested_at)
  VALUES (v_uid, v_amount, trim(p_method), COALESCE(p_payment_details, '{}'::jsonb), 'PENDING', NOW())
  RETURNING id INTO v_wid;

  INSERT INTO public.wallet_transactions (wallet_id, user_id, type, amount, description, reference_id, status)
  VALUES (v_wal.id, v_uid, 'WITHDRAWAL_LOCK', -v_amount,
          'Reserva de saldo para solicitacao de saque #' || substr(v_wid::text, 1, 8), v_wid::text, 'COMPLETED');

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (v_uid, 'WITHDRAWAL_REQUESTED', 'Solicitacao de saque criada',
          'Valor: ' || v_amount || ' Kz via ' || trim(p_method));

  RETURN jsonb_build_object('success', true, 'withdrawal_id', v_wid, 'amount', v_amount, 'status', 'PENDING');
END;
$$;
GRANT EXECUTE ON FUNCTION public.request_withdrawal(NUMERIC, TEXT, JSONB) TO authenticated;

-- Admin: comparação NULL != 'admin' deixava passar quem não tem perfil; usar is_admin()
CREATE OR REPLACE FUNCTION public.admin_process_withdrawal(
  p_withdrawal_id UUID,
  p_action TEXT,
  p_rejection_reason TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_admin_id UUID := auth.uid();
  v_withdrawal RECORD;
  v_wallet RECORD;
BEGIN
  IF v_admin_id IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Acesso negado: apenas administradores podem processar saques.';
  END IF;

  SELECT * INTO v_withdrawal FROM public.withdrawals WHERE id = p_withdrawal_id FOR UPDATE;
  IF v_withdrawal.id IS NULL THEN RAISE EXCEPTION 'Solicitação de saque não encontrada.'; END IF;
  IF v_withdrawal.status IN ('PAID', 'REJECTED') THEN
    RAISE EXCEPTION 'Este saque já foi finalizado anteriormente.';
  END IF;

  SELECT * INTO v_wallet FROM public.wallets WHERE user_id = v_withdrawal.user_id FOR UPDATE;
  IF v_wallet.id IS NULL THEN RAISE EXCEPTION 'Carteira do utilizador não encontrada.'; END IF;

  IF p_action = 'APPROVE' THEN
    IF v_withdrawal.status <> 'PENDING' THEN RAISE EXCEPTION 'Só é possível aprovar saques pendentes.'; END IF;
    UPDATE public.withdrawals SET status = 'APPROVED', processed_at = NOW(), processed_by = v_admin_id
    WHERE id = p_withdrawal_id;

  ELSIF p_action = 'PAID' THEN
    UPDATE public.wallets
    SET reserved_balance = GREATEST(0.00, reserved_balance - v_withdrawal.amount), updated_at = NOW()
    WHERE id = v_wallet.id;
    UPDATE public.withdrawals SET status = 'PAID', processed_at = NOW(), processed_by = v_admin_id
    WHERE id = p_withdrawal_id;
    INSERT INTO public.wallet_transactions (wallet_id, user_id, type, amount, description, reference_id, status)
    VALUES (v_wallet.id, v_withdrawal.user_id, 'WITHDRAWAL_PAID', 0.00,
            'Saque liquidado e transferido ao usuário (' || v_withdrawal.amount || ' Kz)',
            p_withdrawal_id::text, 'COMPLETED');

  ELSIF p_action = 'REJECT' THEN
    UPDATE public.wallets
    SET balance = balance + v_withdrawal.amount,
        reserved_balance = GREATEST(0.00, reserved_balance - v_withdrawal.amount), updated_at = NOW()
    WHERE id = v_wallet.id;
    UPDATE public.withdrawals
    SET status = 'REJECTED',
        rejection_reason = COALESCE(p_rejection_reason, 'Motivo não especificado pela administração'),
        processed_at = NOW(), processed_by = v_admin_id
    WHERE id = p_withdrawal_id;
    INSERT INTO public.wallet_transactions (wallet_id, user_id, type, amount, description, reference_id, status)
    VALUES (v_wallet.id, v_withdrawal.user_id, 'WITHDRAWAL_REFUND', v_withdrawal.amount,
            'Estorno de saque rejeitado: ' || COALESCE(p_rejection_reason, 'Dados incorretos'),
            p_withdrawal_id::text, 'COMPLETED');
  ELSE
    RAISE EXCEPTION 'Ação inválida. Use APPROVE, PAID ou REJECT.';
  END IF;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (v_admin_id, 'ADMIN_WITHDRAWAL_' || p_action,
          'Saque #' || substr(p_withdrawal_id::text, 1, 8) || ' processado: ' || p_action,
          'Usuário: ' || v_withdrawal.user_id || ' | Valor: ' || v_withdrawal.amount || ' Kz');

  RETURN jsonb_build_object('success', true, 'action', p_action, 'withdrawal_id', p_withdrawal_id,
                            'status', (SELECT status FROM public.withdrawals WHERE id = p_withdrawal_id));
END;
$$;

-- --------------------------------------------------------------------
-- 8) Tarefas da comunidade: validações que faltavam no servidor
--    (assinatura activa, tarefa activa, limite max_completions, limite diário, tempo mínimo)
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.complete_community_task(p_task_id UUID)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_queue RECORD;
  v_task RECORD;
  v_reward NUMERIC(10, 2);
  v_wallet_id UUID;
  v_sub TEXT;
  v_active BOOLEAN;
  v_daily_limit INTEGER;
  v_done_today INTEGER;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;

  SELECT subscription_status, is_active INTO v_sub, v_active FROM public.profiles WHERE id = v_uid;
  IF v_active IS DISTINCT FROM TRUE THEN RAISE EXCEPTION 'Conta inactiva.'; END IF;
  IF v_sub IS DISTINCT FROM 'active' THEN RAISE EXCEPTION 'Assinatura activa necessária.'; END IF;

  SELECT * INTO v_queue FROM public.task_distribution_queue
  WHERE user_id = v_uid AND task_id = p_task_id AND status = 'ASSIGNED' FOR UPDATE;
  IF v_queue.id IS NULL THEN RAISE EXCEPTION 'Tarefa não encontrada ou já concluída.'; END IF;

  IF v_queue.assigned_at IS NOT NULL AND v_queue.assigned_at > NOW() - INTERVAL '15 seconds' THEN
    RAISE EXCEPTION 'Execute a tarefa antes de a confirmar.';
  END IF;

  SELECT * INTO v_task FROM public.community_tasks WHERE id = p_task_id FOR UPDATE;
  IF v_task.id IS NULL OR v_task.is_active IS NOT TRUE THEN
    RAISE EXCEPTION 'Esta tarefa já não está disponível.';
  END IF;
  IF v_task.current_completions >= v_task.max_completions THEN
    RAISE EXCEPTION 'Esta tarefa já atingiu o limite de participações.';
  END IF;

  SELECT daily_limit INTO v_daily_limit FROM public.community_settings WHERE platform = lower(v_task.platform);
  IF v_daily_limit IS NOT NULL THEN
    SELECT count(*) INTO v_done_today
    FROM public.task_distribution_queue q
    WHERE q.user_id = v_uid AND q.status = 'COMPLETED' AND lower(q.platform) = lower(v_task.platform)
      AND q.completed_at >= date_trunc('day', NOW());
    IF v_done_today >= v_daily_limit THEN
      RAISE EXCEPTION 'Limite diário desta plataforma atingido.';
    END IF;
  END IF;

  UPDATE public.task_distribution_queue SET status = 'COMPLETED', completed_at = NOW() WHERE id = v_queue.id;
  UPDATE public.community_tasks SET current_completions = current_completions + 1, updated_at = NOW() WHERE id = p_task_id;

  v_reward := COALESCE(v_task.reward_amount, 5.00);

  INSERT INTO public.wallets (user_id, balance, reserved_balance) VALUES (v_uid, 0.00, 0.00)
  ON CONFLICT (user_id) DO NOTHING;
  SELECT id INTO v_wallet_id FROM public.wallets WHERE user_id = v_uid FOR UPDATE;

  UPDATE public.wallets SET balance = balance + v_reward, updated_at = NOW() WHERE id = v_wallet_id;

  INSERT INTO public.wallet_transactions (wallet_id, user_id, type, amount, description, reference_id, status)
  VALUES (v_wallet_id, v_uid, 'CAMPAIGN_REWARD', v_reward, 'Tarefa de comunidade concluída', p_task_id::text, 'COMPLETED');

  RETURN jsonb_build_object('success', true, 'reward', v_reward);
END;
$$;

-- Denúncia: só de tarefas atribuídas ao próprio utilizador, uma vez por tarefa
CREATE OR REPLACE FUNCTION public.report_community_task(p_task_id UUID, p_reason TEXT)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  IF p_reason IS NULL OR length(trim(p_reason)) < 3 THEN
    RAISE EXCEPTION 'Motivo da denúncia é obrigatório.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.task_distribution_queue WHERE user_id = v_uid AND task_id = p_task_id) THEN
    RAISE EXCEPTION 'Tarefa não encontrada.';
  END IF;
  IF EXISTS (SELECT 1 FROM public.task_reports WHERE reporter_user_id = v_uid AND task_id = p_task_id) THEN
    RAISE EXCEPTION 'Já denunciou esta tarefa.';
  END IF;

  INSERT INTO public.task_reports (reporter_user_id, task_id, reason) VALUES (v_uid, p_task_id, left(trim(p_reason), 500));

  UPDATE public.task_distribution_queue SET status = 'REPORTED'
  WHERE user_id = v_uid AND task_id = p_task_id AND status = 'ASSIGNED';

  RETURN jsonb_build_object('success', true);
END;
$$;

-- --------------------------------------------------------------------
-- 9) RPCs chamadas pelo painel admin mas inexistentes no repositório
--    (se já existirem em produção com outra definição, REVER antes de correr este bloco)
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.admin_assign_campaign(p_campaign_id UUID, p_user_ids UUID[])
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_count INTEGER := 0;
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores podem atribuir campanhas.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.campaigns WHERE id = p_campaign_id) THEN
    RAISE EXCEPTION 'Campanha não encontrada.';
  END IF;

  INSERT INTO public.campaign_assignments (campaign_id, user_id, status)
  SELECT p_campaign_id, p.id, 'ASSIGNED'
  FROM public.profiles p
  WHERE p.id = ANY (COALESCE(p_user_ids, ARRAY[]::UUID[])) AND p.is_active = true
  ON CONFLICT (campaign_id, user_id) DO NOTHING;
  GET DIAGNOSTICS v_count = ROW_COUNT;

  RETURN jsonb_build_object('success', true, 'assigned', v_count);
END;
$$;
GRANT EXECUTE ON FUNCTION public.admin_assign_campaign(UUID, UUID[]) TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_toggle_affiliate(
  p_user_id UUID, p_is_active BOOLEAN, p_custom_code TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_code TEXT;
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores podem gerir afiliados.';
  END IF;

  v_code := upper(NULLIF(trim(COALESCE(p_custom_code, '')), ''));
  IF v_code IS NOT NULL AND v_code !~ '^[A-Z0-9_-]{3,20}$' THEN
    RAISE EXCEPTION 'Código inválido (3–20 caracteres A–Z, 0–9, _ ou -).';
  END IF;

  INSERT INTO public.affiliate_profiles (user_id, affiliate_code, is_active)
  VALUES (p_user_id,
          COALESCE(v_code, 'ADX' || upper(substr(replace(p_user_id::text, '-', ''), 1, 8))),
          p_is_active)
  ON CONFLICT (user_id) DO UPDATE
  SET is_active = EXCLUDED.is_active,
      affiliate_code = COALESCE(v_code, public.affiliate_profiles.affiliate_code),
      updated_at = NOW();

  RETURN jsonb_build_object('success', true);
END;
$$;
GRANT EXECUTE ON FUNCTION public.admin_toggle_affiliate(UUID, BOOLEAN, TEXT) TO authenticated;

-- --------------------------------------------------------------------
-- 10) Storage: policies para os dois caminhos usados pelo app
--     {uid}/...  e  deposits/{uid}/...   (a policy sugerida em 004 bloqueava deposits/)
--     Requer que o bucket 'subscription-proofs' já exista e seja PRIVADO.
-- --------------------------------------------------------------------
DROP POLICY IF EXISTS "proofs_insert_own" ON storage.objects;
CREATE POLICY "proofs_insert_own" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'subscription-proofs'
    AND (
      (storage.foldername(name))[1] = auth.uid()::text
      OR ((storage.foldername(name))[1] = 'deposits' AND (storage.foldername(name))[2] = auth.uid()::text)
    )
  );

DROP POLICY IF EXISTS "proofs_select_own_or_admin" ON storage.objects;
CREATE POLICY "proofs_select_own_or_admin" ON storage.objects
  FOR SELECT TO authenticated
  USING (
    bucket_id = 'subscription-proofs'
    AND (
      (storage.foldername(name))[1] = auth.uid()::text
      OR ((storage.foldername(name))[1] = 'deposits' AND (storage.foldername(name))[2] = auth.uid()::text)
      OR public.is_admin()
    )
  );
