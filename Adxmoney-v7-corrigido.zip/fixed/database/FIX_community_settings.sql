-- ============================================================
-- FIX: community_settings (estrutura correta)
-- Seguro: só mexe nesta tabela de configuração
-- ============================================================

-- 1. Apagar a tabela antiga (só se existir)
DROP TABLE IF EXISTS public.community_settings CASCADE;

-- 2. Criar com a estrutura correta
CREATE TABLE public.community_settings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  platform TEXT NOT NULL UNIQUE CHECK (platform IN ('tiktok', 'instagram', 'youtube')),
  daily_limit INTEGER NOT NULL DEFAULT 100,
  reward_per_task NUMERIC(10, 2) NOT NULL DEFAULT 5.00,
  is_active BOOLEAN NOT NULL DEFAULT true,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Inserir os 3 registos de configuração
INSERT INTO public.community_settings (platform, daily_limit, reward_per_task)
VALUES
  ('tiktok', 100, 5.00),
  ('instagram', 100, 5.00),
  ('youtube', 100, 5.00);

-- 4. Grants e RLS
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.community_settings TO service_role;
GRANT SELECT ON TABLE public.community_settings TO authenticated;

ALTER TABLE public.community_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "comm_settings_select" ON public.community_settings;
CREATE POLICY "comm_settings_select" ON public.community_settings
  FOR SELECT TO authenticated USING (true);
