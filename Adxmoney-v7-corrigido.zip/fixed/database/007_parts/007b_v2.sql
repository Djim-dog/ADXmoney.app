-- 007b refresh_user_level
CREATE OR REPLACE FUNCTION public.refresh_user_level(p_user_id UUID)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $adx$
BEGIN
  PERFORM set_config('app.skip_profile_guard', 'on', true);

  UPDATE public.profiles
  SET
    member_level = public.calculate_member_level(
      COALESCE((SELECT ap.total_referrals FROM public.affiliate_profiles ap WHERE ap.user_id = p_user_id), 0),
      COALESCE((SELECT ap.total_earned FROM public.affiliate_profiles ap WHERE ap.user_id = p_user_id), 0)
    ),
    priority_withdrawal = (
      public.calculate_member_level(
        COALESCE((SELECT ap.total_referrals FROM public.affiliate_profiles ap WHERE ap.user_id = p_user_id), 0),
        COALESCE((SELECT ap.total_earned FROM public.affiliate_profiles ap WHERE ap.user_id = p_user_id), 0)
      ) IN ('gold', 'platinum')
    ),
    level_updated_at = NOW(),
    updated_at = NOW()
  WHERE id = p_user_id;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Utilizador nao encontrado');
  END IF;

  RETURN (
    SELECT jsonb_build_object(
      'success', true,
      'user_id', p_user_id,
      'member_level', p.member_level,
      'priority_withdrawal', p.priority_withdrawal,
      'total_referrals', COALESCE((SELECT ap.total_referrals FROM public.affiliate_profiles ap WHERE ap.user_id = p_user_id), 0),
      'total_earned', COALESCE((SELECT ap.total_earned FROM public.affiliate_profiles ap WHERE ap.user_id = p_user_id), 0)
    )
    FROM public.profiles p
    WHERE p.id = p_user_id
  );
END;
$adx$;
