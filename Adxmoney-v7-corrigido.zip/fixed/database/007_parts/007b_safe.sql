-- 007b refresh_user_level
CREATE OR REPLACE FUNCTION public.refresh_user_level(p_user_id UUID)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS '
DECLARE
  r_count INTEGER := 0;
  r_earned NUMERIC := 0;
  r_level TEXT;
  r_priority BOOLEAN;
BEGIN
  SELECT COALESCE(ap.total_referrals, 0), COALESCE(ap.total_earned, 0)
  INTO r_count, r_earned
  FROM public.affiliate_profiles ap
  WHERE ap.user_id = p_user_id;
  IF r_count IS NULL THEN r_count := 0; END IF;
  IF r_earned IS NULL THEN r_earned := 0; END IF;
  r_level := public.calculate_member_level(r_count, r_earned);
  r_priority := (r_level = ''gold'' OR r_level = ''platinum'');
  PERFORM set_config(''app.skip_profile_guard'', ''on'', true);
  UPDATE public.profiles
  SET member_level = r_level,
      priority_withdrawal = r_priority,
      level_updated_at = NOW(),
      updated_at = NOW()
  WHERE id = p_user_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object(''success'', false, ''error'', ''Utilizador nao encontrado'');
  END IF;
  RETURN jsonb_build_object(
    ''success'', true,
    ''user_id'', p_user_id,
    ''member_level'', r_level,
    ''priority_withdrawal'', r_priority,
    ''total_referrals'', r_count,
    ''total_earned'', r_earned
  );
END;
';
