-- 007a protect profiles
CREATE OR REPLACE FUNCTION public.protect_profile_sensitive_columns()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS '
BEGIN
  IF current_setting(''app.skip_profile_guard'', true) = ''on'' THEN
    RETURN NEW;
  END IF;
  IF public.is_admin() THEN
    RETURN NEW;
  END IF;
  IF TG_OP = ''UPDATE'' THEN
    NEW.role := OLD.role;
    NEW.subscription_status := OLD.subscription_status;
    NEW.is_active := OLD.is_active;
    NEW.member_level := OLD.member_level;
    NEW.priority_withdrawal := OLD.priority_withdrawal;
    NEW.level_updated_at := OLD.level_updated_at;
    NEW.custom_affiliate_code := OLD.custom_affiliate_code;
    IF NEW.suspended_until IS DISTINCT FROM OLD.suspended_until THEN
      NEW.suspended_until := OLD.suspended_until;
    END IF;
  END IF;
  RETURN NEW;
END;
';

DROP TRIGGER IF EXISTS trg_protect_profile_sensitive ON public.profiles;
CREATE TRIGGER trg_protect_profile_sensitive
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE PROCEDURE public.protect_profile_sensitive_columns();
