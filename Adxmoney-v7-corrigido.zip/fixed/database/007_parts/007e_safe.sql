-- 007e submit_engagement_order
CREATE OR REPLACE FUNCTION public.submit_engagement_order(
  p_platform TEXT,
  p_service_type TEXT,
  p_target_link TEXT,
  p_quantity INTEGER,
  p_total_price NUMERIC,
  p_currency TEXT,
  p_method TEXT,
  p_proof_url TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS '
DECLARE
  uid UUID := auth.uid();
  oid UUID;
  unit_usd NUMERIC;
  cur TEXT := upper(trim(coalesce(p_currency, ''USD'')));
  rate NUMERIC;
  computed NUMERIC;
  meth TEXT := upper(trim(coalesce(p_method, '''')));
  qty INTEGER := coalesce(p_quantity, 0);
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION ''Nao autenticado'';
  END IF;
  IF qty < 10 OR qty > 1000000 THEN
    RAISE EXCEPTION ''Quantidade invalida (minimo 10, maximo 1000000).'';
  END IF;
  IF p_target_link IS NULL OR length(trim(p_target_link)) < 5 THEN
    RAISE EXCEPTION ''Link de destino invalido.'';
  END IF;
  IF cur NOT IN (''AOA'', ''USD'', ''EUR'', ''BRL'') THEN
    RAISE EXCEPTION ''Moeda nao suportada.'';
  END IF;
  IF p_platform IN (''TikTok'', ''Instagram'') THEN
    IF p_service_type = ''Seguidores'' THEN unit_usd := 0.0315;
    ELSE unit_usd := 0.027;
    END IF;
  ELSIF p_platform = ''YouTube'' THEN
    IF p_service_type = ''Seguidores'' THEN unit_usd := 0.038;
    ELSE unit_usd := 0.032;
    END IF;
  ELSE
    RAISE EXCEPTION ''Plataforma invalida.'';
  END IF;
  IF cur = ''USD'' THEN rate := 1;
  ELSIF cur = ''AOA'' THEN rate := 950;
  ELSIF cur = ''EUR'' THEN rate := 0.92;
  ELSIF cur = ''BRL'' THEN rate := 5.40;
  ELSE rate := 1;
  END IF;
  computed := round(unit_usd * rate * qty, 2);
  IF meth LIKE ''%UNITEL%'' THEN meth := ''UNITEL'';
  ELSIF meth LIKE ''%EXPRESS%'' OR meth LIKE ''%MULTICAIXA%'' THEN meth := ''EXPRESS'';
  ELSIF meth LIKE ''%REMITLY%'' THEN meth := ''REMITLY'';
  ELSE meth := left(meth, 32);
  END IF;
  INSERT INTO public.engagement_orders (
    user_id, platform, service_type, target_link, quantity,
    total_price, currency, method, proof_url, status
  ) VALUES (
    uid, p_platform, p_service_type, trim(p_target_link), qty,
    computed, cur, meth, p_proof_url, ''PENDING''
  ) RETURNING id INTO oid;
  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (uid, ''ENGAGEMENT_ORDER_CREATED'', ''Pedido de engajamento criado'',
    p_platform || '' - '' || p_service_type || '' x '' || qty);
  RETURN jsonb_build_object(
    ''success'', true,
    ''order_id'', oid,
    ''short_code'', upper(substr(oid::text, 1, 8)),
    ''total_price'', computed
  );
END;
';

GRANT EXECUTE ON FUNCTION public.submit_engagement_order(TEXT, TEXT, TEXT, INTEGER, NUMERIC, TEXT, TEXT, TEXT) TO authenticated;
