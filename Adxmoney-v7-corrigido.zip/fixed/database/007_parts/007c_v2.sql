-- 007c set_custom_affiliate_code
CREATE OR REPLACE FUNCTION public.set_custom_affiliate_code(p_code TEXT)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $adx$
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Nao autenticado';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid()
      AND member_level IN ('gold', 'platinum')
  ) THEN
    RAISE EXCEPTION 'Codigo personalizado disponivel apenas a partir do nivel Gold.';
  END IF;

  IF p_code IS NULL
     OR length(trim(p_code)) < 4
     OR length(trim(p_code)) > 16 THEN
    RAISE EXCEPTION 'O codigo deve ter entre 4 e 16 caracteres.';
  END IF;

  IF length(translate(upper(trim(p_code)), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_', '')) > 0 THEN
    RAISE EXCEPTION 'Use apenas letras, numeros e underscore.';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.profiles
    WHERE upper(COALESCE(custom_affiliate_code, '')) = upper(trim(p_code))
      AND id <> auth.uid()
  ) OR EXISTS (
    SELECT 1 FROM public.profiles
    WHERE upper(COALESCE(referral_code, '')) = upper(trim(p_code))
      AND id <> auth.uid()
  ) OR EXISTS (
    SELECT 1 FROM public.affiliate_profiles
    WHERE upper(affiliate_code) = upper(trim(p_code))
      AND user_id <> auth.uid()
  ) THEN
    RAISE EXCEPTION 'Este codigo ja esta em uso. Escolha outro.';
  END IF;

  PERFORM set_config('app.skip_profile_guard', 'on', true);

  UPDATE public.profiles
  SET custom_affiliate_code = upper(trim(p_code)), updated_at = NOW()
  WHERE id = auth.uid();

  UPDATE public.affiliate_profiles
  SET affiliate_code = upper(trim(p_code)), updated_at = NOW()
  WHERE user_id = auth.uid();

  RETURN jsonb_build_object('success', true, 'custom_affiliate_code', upper(trim(p_code)));
END;
$adx$;
