-- 007c set_custom_affiliate_code
CREATE OR REPLACE FUNCTION public.set_custom_affiliate_code(p_code TEXT)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS '
DECLARE
  uid UUID;
  lvl TEXT;
  clean TEXT;
BEGIN
  uid := auth.uid();
  IF uid IS NULL THEN
    RAISE EXCEPTION ''Nao autenticado'';
  END IF;
  SELECT member_level INTO lvl FROM public.profiles WHERE id = uid;
  IF lvl IS NULL OR (lvl <> ''gold'' AND lvl <> ''platinum'') THEN
    RAISE EXCEPTION ''Codigo personalizado disponivel apenas a partir do nivel Gold.'';
  END IF;
  clean := upper(trim(p_code));
  IF clean IS NULL OR length(clean) < 4 OR length(clean) > 16 THEN
    RAISE EXCEPTION ''O codigo deve ter entre 4 e 16 caracteres.'';
  END IF;
  IF clean !~ ''^[A-Z0-9_]+$'' THEN
    RAISE EXCEPTION ''Use apenas letras, numeros e underscore.'';
  END IF;
  IF EXISTS (
    SELECT 1 FROM public.profiles
    WHERE upper(COALESCE(custom_affiliate_code, '''')) = clean AND id <> uid
  ) OR EXISTS (
    SELECT 1 FROM public.profiles
    WHERE upper(COALESCE(referral_code, '''')) = clean AND id <> uid
  ) OR EXISTS (
    SELECT 1 FROM public.affiliate_profiles
    WHERE upper(affiliate_code) = clean AND user_id <> uid
  ) THEN
    RAISE EXCEPTION ''Este codigo ja esta em uso. Escolha outro.'';
  END IF;
  PERFORM set_config(''app.skip_profile_guard'', ''on'', true);
  UPDATE public.profiles SET custom_affiliate_code = clean, updated_at = NOW() WHERE id = uid;
  UPDATE public.affiliate_profiles SET affiliate_code = clean, updated_at = NOW() WHERE user_id = uid;
  RETURN jsonb_build_object(''success'', true, ''custom_affiliate_code'', clean);
END;
';
