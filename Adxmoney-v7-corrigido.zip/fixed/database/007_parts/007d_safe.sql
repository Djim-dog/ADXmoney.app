-- 007d submit_subscription_payment
CREATE OR REPLACE FUNCTION public.submit_subscription_payment(
  p_amount NUMERIC,
  p_currency TEXT,
  p_method TEXT,
  p_proof_url TEXT DEFAULT NULL,
  p_payment_date TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS '
DECLARE
  uid UUID := auth.uid();
  pay_id UUID;
  cur TEXT := upper(trim(coalesce(p_currency, ''AOA'')));
  meth TEXT := upper(trim(split_part(coalesce(p_method, ''''), '' '', 1)));
  details TEXT := trim(coalesce(p_method, ''''));
  forced NUMERIC := 4900.00;
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION ''Nao autenticado'';
  END IF;
  IF cur NOT IN (''AOA'', ''USD'', ''EUR'', ''BRL'') THEN
    RAISE EXCEPTION ''Moeda nao suportada.'';
  END IF;
  IF meth LIKE ''EXPRESS%'' THEN meth := ''EXPRESS'';
  ELSIF meth LIKE ''UNITEL%'' THEN meth := ''UNITEL'';
  ELSIF meth LIKE ''REMITLY%'' THEN meth := ''REMITLY'';
  ELSIF meth LIKE ''MULTICAIXA%'' THEN meth := ''EXPRESS'';
  ELSE
    RAISE EXCEPTION ''Metodo de pagamento invalido.'';
  END IF;
  IF p_proof_url IS NULL OR trim(p_proof_url) = '''' OR split_part(p_proof_url, ''/'', 1) <> uid::text THEN
    RAISE EXCEPTION ''Comprovativo invalido para este utilizador.'';
  END IF;
  INSERT INTO public.subscription_payments (
    user_id, amount, currency, method, proof_url, status
  ) VALUES (
    uid, forced, cur,
    meth || CASE WHEN length(details) > 20 THEN '' | '' || left(details, 400) ELSE '''' END,
    p_proof_url, ''PENDING''
  ) RETURNING id INTO pay_id;
  PERFORM set_config(''app.skip_profile_guard'', ''on'', true);
  UPDATE public.profiles SET subscription_status = ''pending'', updated_at = NOW() WHERE id = uid;
  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (uid, ''SUBSCRIPTION_SUBMITTED'', ''Pedido de assinatura enviado'', meth || '' / '' || cur);
  RETURN jsonb_build_object(''success'', true, ''payment_id'', pay_id, ''amount'', forced);
END;
';

GRANT EXECUTE ON FUNCTION public.submit_subscription_payment(NUMERIC, TEXT, TEXT, TEXT, TEXT) TO authenticated;
