-- 007f request_withdrawal min 1000
CREATE OR REPLACE FUNCTION public.request_withdrawal(
  p_amount NUMERIC,
  p_method TEXT,
  p_payment_details JSONB
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $adx$
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Nao autenticado';
  END IF;

  IF p_amount IS NULL OR p_amount <= 0 THEN
    RAISE EXCEPTION 'O valor do saque deve ser maior que zero.';
  END IF;

  IF p_amount < 1000 THEN
    RAISE EXCEPTION 'Valor minimo de saque: 1000 Kz.';
  END IF;

  IF p_method IS NULL OR length(trim(p_method)) = 0 THEN
    RAISE EXCEPTION 'Informe o metodo de pagamento para o saque.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.wallets WHERE user_id = auth.uid()) THEN
    RAISE EXCEPTION 'Carteira nao encontrada.';
  END IF;

  IF (SELECT balance FROM public.wallets WHERE user_id = auth.uid()) < p_amount THEN
    RAISE EXCEPTION 'Saldo disponivel insuficiente para realizar este saque.';
  END IF;

  PERFORM 1 FROM public.wallets WHERE user_id = auth.uid() FOR UPDATE;

  UPDATE public.wallets
  SET balance = balance - p_amount,
      reserved_balance = reserved_balance + p_amount,
      updated_at = NOW()
  WHERE user_id = auth.uid();

  RETURN (
    WITH ins AS (
      INSERT INTO public.withdrawals (
        user_id, amount, method, payment_details, status, requested_at
      ) VALUES (
        auth.uid(), p_amount, trim(p_method),
        COALESCE(p_payment_details, '{}'::jsonb), 'PENDING', NOW()
      )
      RETURNING id
    ),
    tx AS (
      INSERT INTO public.wallet_transactions (
        wallet_id, user_id, type, amount, description, reference_id, status
      )
      SELECT w.id, auth.uid(), 'WITHDRAWAL_LOCK', -p_amount,
             'Reserva de saldo para saque',
             ins.id::text, 'COMPLETED'
      FROM public.wallets w, ins
      WHERE w.user_id = auth.uid()
      RETURNING 1
    ),
    log AS (
      INSERT INTO public.activity_logs (user_id, action_type, title, details)
      SELECT auth.uid(), 'WITHDRAWAL_REQUESTED', 'Solicitacao de saque criada',
             'Valor: ' || p_amount || ' Kz via ' || p_method
      FROM ins
      RETURNING 1
    )
    SELECT jsonb_build_object(
      'success', true,
      'withdrawal_id', ins.id,
      'amount', p_amount,
      'status', 'PENDING'
    )
    FROM ins
  );
END;
$adx$;

GRANT EXECUTE ON FUNCTION public.request_withdrawal(NUMERIC, TEXT, JSONB) TO authenticated;
