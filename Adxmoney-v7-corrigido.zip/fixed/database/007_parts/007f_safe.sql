-- 007f request_withdrawal min 1000
CREATE OR REPLACE FUNCTION public.request_withdrawal(
  p_amount NUMERIC,
  p_method TEXT,
  p_payment_details JSONB
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS '
DECLARE
  uid UUID;
  wal RECORD;
  wid UUID;
  min_amt NUMERIC := 1000.00;
BEGIN
  uid := auth.uid();
  IF uid IS NULL THEN
    RAISE EXCEPTION ''Nao autenticado'';
  END IF;
  IF p_amount IS NULL OR p_amount <= 0 THEN
    RAISE EXCEPTION ''O valor do saque deve ser maior que zero.'';
  END IF;
  IF p_amount < min_amt THEN
    RAISE EXCEPTION ''Valor minimo de saque: 1000 Kz.'';
  END IF;
  IF p_method IS NULL OR length(trim(p_method)) = 0 THEN
    RAISE EXCEPTION ''Informe o metodo de pagamento para o saque.'';
  END IF;
  SELECT * INTO wal FROM public.wallets WHERE user_id = uid FOR UPDATE;
  IF wal.id IS NULL THEN
    RAISE EXCEPTION ''Carteira nao encontrada.'';
  END IF;
  IF wal.balance < p_amount THEN
    RAISE EXCEPTION ''Saldo disponivel insuficiente para realizar este saque.'';
  END IF;
  UPDATE public.wallets
  SET balance = balance - p_amount,
      reserved_balance = reserved_balance + p_amount,
      updated_at = NOW()
  WHERE id = wal.id;
  INSERT INTO public.withdrawals (
    user_id, amount, method, payment_details, status, requested_at
  ) VALUES (
    uid, p_amount, trim(p_method), COALESCE(p_payment_details, ''{}''::jsonb), ''PENDING'', NOW()
  ) RETURNING id INTO wid;
  INSERT INTO public.wallet_transactions (
    wallet_id, user_id, type, amount, description, reference_id, status
  ) VALUES (
    wal.id, uid, ''WITHDRAWAL_LOCK'', -p_amount,
    ''Reserva de saldo para saque #'' || substr(wid::text, 1, 8),
    wid::text, ''COMPLETED''
  );
  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (uid, ''WITHDRAWAL_REQUESTED'', ''Solicitacao de saque criada'',
    ''Valor: '' || p_amount || '' Kz via '' || p_method);
  RETURN jsonb_build_object(
    ''success'', true,
    ''withdrawal_id'', wid,
    ''amount'', p_amount,
    ''status'', ''PENDING''
  );
END;
';

GRANT EXECUTE ON FUNCTION public.request_withdrawal(NUMERIC, TEXT, JSONB) TO authenticated;
