-- preferred_language for IA ADX (pt | en | fr)
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS preferred_language TEXT NOT NULL DEFAULT 'pt'
    CHECK (preferred_language IN ('pt', 'en', 'fr'));

COMMENT ON COLUMN public.profiles.preferred_language IS 'Idioma da UI e da IA ADX: pt, en, fr';
