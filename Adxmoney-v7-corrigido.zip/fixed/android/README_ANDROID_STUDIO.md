# ADXmoney — gerar APK no Android Studio

## Pré-requisitos
- Android Studio Hedgehog ou mais recente
- JDK 17
- Deploy da PWA em **HTTPS** (ex. Vercel)

## Passos

1. Abre o ficheiro:
   `android/app/src/main/java/com/adxmoney/app/MainActivity.kt`
2. Altera a linha:
   `const val WEB_APP_URL = "https://adxmoney.vercel.app"`
   para o **teu URL real** (com https://).
3. No Android Studio: **File → Open** → selecciona a pasta `android/`
4. Aguarda o Gradle Sync
5. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**
6. O APK fica em:
   `android/app/build/outputs/apk/debug/app-debug.apk`
7. Copia para o telemóvel e instala (activa “fontes desconhecidas” se pedir)

## Release (opcional)
**Build → Generate Signed Bundle / APK** com o teu keystore.

## Notas
- O app é um **WebView** que carrega a PWA completa (mesmo UI do site).
- Internet obrigatória para login e dados.
- Ícone: `mipmap/ic_launcher` — podes substituir pelos PNG do `public/icon-512.png`.
