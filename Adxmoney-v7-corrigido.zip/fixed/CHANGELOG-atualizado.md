# ADXmoney — ZIP completo atualizado

Comparado com o ZIP anterior (`Adxmoney-app-assinatura-etapas`):

## Já incluído no ZIP anterior (mantido)
- Assinatura em 3 etapas (`SubscriptionModal`)
- Unitel / Multicaixa Express / Remitly + upload de comprovativo
- Admin: pedidos de assinatura + apagar comprovativo após aprovar/rejeitar
- IA Coach / Conteúdo / Suporte
- Carteira, saques, campanhas, afiliados

## Novo neste ZIP
1. **Página pública Criar Conta ADX**
   - Rotas: `/register` e `/criar-conta`
   - Ficheiro: `src/pages/Register.tsx`
   - Formulário: Nome + E-mail + WhatsApp
   - Após criar: mostra senha temporária + botão "Entrar com e-mail"
   - Sem UI de admin (sem papel, sem "enviar credenciais")

2. **Edge function `public-register`**
   - `supabase/functions/public-register/index.ts`
   - Pública (sem JWT)
   - Sempre `role: user` + `first_login: true`
   - Cria auth user + profile + wallet

3. **Login atualizado**
   - Link "Criar conta ADX"
   - Pré-preenche e-mail se vier do registo

4. **Rotas em `App.tsx`**
   - `/register` e `/criar-conta`

## Deploy

### Frontend
Faz deploy deste ZIP no teu hosting (Vercel / o que usas).

### Edge function (se ainda não fizeste)
```bash
supabase functions deploy public-register --no-verify-jwt
```

## Fluxo do utilizador novo
1. `/register` → cria conta
2. Vê senha → "Entrar com e-mail"
3. `/login` → autentica
4. `/account/setup` (first login)
5. App / assinatura (como antes)
