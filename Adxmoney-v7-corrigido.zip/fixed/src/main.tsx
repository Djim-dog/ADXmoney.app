import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./globals.css";

createRoot(document.getElementById("root")!).render(<App />);

// Registar Service Worker (PWA) — só em produção / HTTPS
if (typeof window !== "undefined" && "serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    const isLocal =
      location.hostname === "localhost" ||
      location.hostname === "127.0.0.1";
    if (isLocal && location.protocol !== "https:") {
      // Em localhost HTTP o SW ainda funciona; registamos na mesma
    }
    navigator.serviceWorker
      .register("/sw.js")
      .then((reg) => {
        // Actualização em background
        reg.update().catch(() => {});
      })
      .catch(() => {
        /* SW opcional — app continua sem offline */
      });
  });
}
