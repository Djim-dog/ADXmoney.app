import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Suspense, lazy } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { OfflineBanner } from "@/components/OfflineBanner";
import Login from "./pages/Login";
import Register from "./pages/Register";
import AccountSetup from "./pages/AccountSetup";
import { SplashScreen } from "@/components/SplashScreen";
import NotFound from "./pages/NotFound";

// Rotas pesadas carregadas a pedido (Admin ~2k linhas + recharts não vão para quem é utilizador)
const AdminDashboardPage = lazy(() => import("./pages/AdminDashboard"));
const UserAppPage = lazy(() => import("./pages/UserApp"));

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 30_000, refetchOnWindowFocus: false, retry: 1 } },
});

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <OfflineBanner />
        <Toaster />
        <Sonner position="top-right" richColors />
        <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
          <Suspense fallback={<SplashScreen message="Carregando..." />}>
          <Routes>
            {/* Auth públicas */}
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/criar-conta" element={<Register />} />

            {/* Raiz → app (ProtectedRoute trata login / first_login / role) */}
            <Route
              path="/"
              element={
                <ProtectedRoute>
                  <Navigate to="/app" replace />
                </ProtectedRoute>
              }
            />

            {/* Admin */}
            <Route
              path="/admin"
              element={
                <ProtectedRoute requiredRole="admin">
                  <AdminDashboardPage />
                </ProtectedRoute>
              }
            />

            {/* First login / setup */}
            <Route
              path="/account/setup"
              element={
                <ProtectedRoute>
                  <AccountSetup />
                </ProtectedRoute>
              }
            />

            {/* App utilizador */}
            <Route
              path="/app"
              element={
                <ProtectedRoute requiredRole="user">
                  <UserAppPage />
                </ProtectedRoute>
              }
            />

            {/* Legado: redireciona para o fluxo único no /app (sem perda de links antigos) */}
            <Route path="/subscribe" element={<Navigate to="/app" replace />} />
            <Route path="/engagement/order" element={<Navigate to="/app" replace />} />
            <Route path="/dashboard" element={<Navigate to="/app" replace />} />

            <Route path="*" element={<NotFound />} />
          </Routes>
          </Suspense>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
