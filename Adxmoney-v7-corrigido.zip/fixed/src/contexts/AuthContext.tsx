import React, { createContext, useContext, useEffect, useState } from "react";
import { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export interface Profile {
  id: string;
  name: string | null;
  first_name: string | null;
  last_name: string | null;
  email: string | null;
  phone: string | null;
  avatar_url: string | null;
  role: "admin" | "user" | string;
  first_login: boolean;
  is_active: boolean;
  primary_link?: string | null;
  country?: string | null;
  referral_code?: string | null;
  custom_affiliate_code?: string | null;
  invited_by?: string | null;
  referred_completed?: boolean;
  created_at: string | null;
  updated_at: string | null;
  subscription_status?: "visitor" | "active" | string | null;
  subscription_onboarding_completed?: boolean;
  preferred_language?: "pt" | "en" | "fr" | string | null;
}

interface AuthContextType {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  isAdmin: boolean;
  isActive: boolean;
  loading: boolean;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  session: null,
  user: null,
  profile: null,
  isAdmin: false,
  isActive: true,
  loading: true,
  signOut: async () => {},
  refreshProfile: async () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  // Função para sincronizar perfil automaticamente a partir do user autenticado
  const fetchOrSyncProfile = async (authUser: User): Promise<Profile | null> => {
    try {
      const { data: profileData, error: profileError } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", authUser.id)
        .maybeSingle();

      if (profileData && !profileError) {
        const loaded = profileData as Profile;
        setProfile(loaded);
        return loaded;
      }

      // Falha de rede/RLS: NÃO escrever nada (antes um upsert aqui podia repor role/first_login/saldo).
      if (profileError) {
        throw profileError;
      }

      // Sem perfil e sem erro: o trigger handle_new_user cria perfil + carteira no servidor.
      // Esperar brevemente e voltar a ler, em vez de escrever do cliente.
      await new Promise((r) => setTimeout(r, 600));
      const { data: retry } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", authUser.id)
        .maybeSingle();
      if (retry) {
        setProfile(retry as Profile);
        return retry as Profile;
      }
      throw new Error("Perfil ainda indisponível");
    } catch (err) {
      console.error("[AuthContext] Erro ao sincronizar perfil:", err);
      // Mantém o último perfil conhecido; se não houver, fallback mínimo SEM privilégios e SEM forçar setup
      let kept: Profile | null = null;
      setProfile((prev) => {
        if (prev && prev.id === authUser.id) {
          kept = prev;
          return prev;
        }
        const fallback: Profile = {
          id: authUser.id,
          email: authUser.email || "",
          name: (authUser.user_metadata?.name as string) || authUser.email?.split("@")[0] || "Utilizador",
          first_name: null,
          last_name: null,
          phone: null,
          avatar_url: null,
          role: "user",
          first_login: false,
          is_active: true,
          created_at: null,
          updated_at: null,
        };
        kept = fallback;
        return fallback;
      });
      return kept;
    }
  };

  useEffect(() => {
    let isMounted = true;

    const initAuth = async () => {
      try {
        const { data: { session: initialSession } } = await supabase.auth.getSession();
        if (!isMounted) return;

        setSession(initialSession);
        setUser(initialSession?.user ?? null);

        if (initialSession?.user) {
          await fetchOrSyncProfile(initialSession.user);
        }
      } catch (err) {
        console.error("[AuthContext] Erro ao inicializar sessão:", err);
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    initAuth();

    const { data: authListener } = supabase.auth.onAuthStateChange(
      (event, newSession) => {
        if (!isMounted) return;

        setSession(newSession);
        // Mantém a MESMA referência de user quando o id não muda (evita refetch em cascata nos ecrãs)
        setUser((prev) => {
          const next = newSession?.user ?? null;
          if (prev && next && prev.id === next.id) return prev;
          return next;
        });

        if (!newSession?.user) {
          setProfile(null);
          setLoading(false);
          return;
        }

        // Token renovado / INITIAL_SESSION duplicado: não voltar a pedir o perfil
        if (event === "TOKEN_REFRESHED" || event === "INITIAL_SESSION") {
          return;
        }

        // Fora do callback para não bloquear o cliente de auth
        setTimeout(async () => {
          if (!isMounted) return;
          await fetchOrSyncProfile(newSession.user);
          if (isMounted) setLoading(false);
        }, 0);
      }
    );

    return () => {
      isMounted = false;
      authListener?.subscription.unsubscribe();
    };
  }, []);

  // Subscrever a alterações em tempo real no perfil do utilizador (por exemplo, status de assinatura)
  useEffect(() => {
    if (!user) return;

    const profileSubscription = supabase
      .channel(`profile-updates-${user.id}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "profiles",
          filter: `id=eq.${user.id}`,
        },
        (payload) => {
          setProfile((prev) => {
            if (prev && prev.id === user.id) {
              return { ...prev, ...payload.new } as Profile;
            }
            return payload.new as Profile;
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(profileSubscription);
    };
  }, [user?.id]);

  const signOut = async () => {
    try {
      await supabase.auth.signOut();
    } catch (err) {
      console.error("[AuthContext] Erro no logout:", err);
    } finally {
      setSession(null);
      setUser(null);
      setProfile(null);
    }
  };

  const refreshProfile = async () => {
    const { data: { user: currentUser } } = await supabase.auth.getUser();
    if (currentUser) {
      await fetchOrSyncProfile(currentUser);
    }
  };

  const isAdmin = profile?.role === "admin";
  const isActive = profile ? profile.is_active !== false : true;

  return (
    <AuthContext.Provider
      value={{
        session,
        user,
        profile,
        isAdmin,
        isActive,
        loading,
        signOut,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
