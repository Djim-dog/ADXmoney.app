import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { SplashScreen } from '@/components/SplashScreen';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRole?: "admin" | "user";
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  children,
  requiredRole
}) => {
  const { user, profile, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <SplashScreen message="Validando credenciais..." />;
  }

  if (!user) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  // Há sessão mas o perfil ainda está a ser lido: esperar (nunca decidir papel por metadata do cliente)
  if (!profile) {
    return <SplashScreen message="Validando credenciais..." />;
  }

  const effectiveRole = profile.role === 'admin' ? 'admin' : 'user';

  // Flag de segurança: setup acabou de concluir (evita loop por race do perfil em memória)
  let setupJustDone = false;
  try {
    setupJustDone = sessionStorage.getItem("adx_setup_done") === "1";
  } catch {
    /* ignore */
  }

  // Perfil já sincronizado como concluído → limpar flag
  if (profile?.first_login === false && setupJustDone) {
    try {
      sessionStorage.removeItem("adx_setup_done");
    } catch {
      /* ignore */
    }
    setupJustDone = false;
  }

  // 1. Impor primeiro acesso (exceto se o setup acabou de concluir neste ciclo)
  if (profile?.first_login && !setupJustDone && location.pathname !== "/account/setup") {
    return <Navigate to="/account/setup" replace />;
  }

  // 2. Se já completou o first_login (ou setupJustDone), não voltar para setup
  if (
    (profile?.first_login === false || setupJustDone) &&
    location.pathname === "/account/setup"
  ) {
    return <Navigate to="/app" replace />;
  }

  // 3. Verificação de Assinatura (para usuários)
  // Removido o redirect forçado para permitir modo "Visitante"
  // As limitações serão tratadas nos componentes
  /*
  if (requiredRole === 'user' && profile && profile.subscription_status !== 'active' && location.pathname !== '/subscribe') {
      return <Navigate to="/subscribe" replace />;
  }
  */

  if (location.pathname === '/') {
    return effectiveRole === 'admin' ? <Navigate to="/admin" replace /> : <Navigate to="/app" replace />;
  }

  if (requiredRole === 'admin' && effectiveRole !== 'admin') {
    return <Navigate to="/app" replace />;
  }

  if (requiredRole === 'user' && effectiveRole === 'admin') {
    return <Navigate to="/admin" replace />;
  }

  return <>{children}</>;
};
