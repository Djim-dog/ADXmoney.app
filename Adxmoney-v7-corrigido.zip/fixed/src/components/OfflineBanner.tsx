import { useEffect, useState } from "react";
import { WifiOff, Wifi } from "lucide-react";

/**
 * Banner profissional de conectividade.
 * - Offline: barra fixa no topo (app continua a mostrar login/shell em cache)
 * - Volta online: aviso breve e desaparece
 */
export function OfflineBanner() {
  const [offline, setOffline] = useState(
    typeof navigator !== "undefined" ? !navigator.onLine : false
  );
  const [justOnline, setJustOnline] = useState(false);

  useEffect(() => {
    const goOffline = () => {
      setOffline(true);
      setJustOnline(false);
    };
    const goOnline = () => {
      setOffline(false);
      setJustOnline(true);
      const t = window.setTimeout(() => setJustOnline(false), 3200);
      return () => window.clearTimeout(t);
    };

    window.addEventListener("offline", goOffline);
    window.addEventListener("online", goOnline);
    // Estado inicial (alguns browsers atrasam)
    setOffline(!navigator.onLine);

    return () => {
      window.removeEventListener("offline", goOffline);
      window.removeEventListener("online", goOnline);
    };
  }, []);

  if (offline) {
    return (
      <div
        role="status"
        aria-live="polite"
        className="fixed top-0 inset-x-0 z-[100] safe-area-top"
      >
        <div className="mx-auto max-w-lg px-3 pt-[max(0.5rem,env(safe-area-inset-top))]">
          <div className="flex items-center gap-2.5 rounded-2xl bg-slate-900 text-white px-3.5 py-2.5 shadow-xl shadow-slate-900/25 border border-white/10">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center shrink-0">
              <WifiOff className="w-4 h-4" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-[12px] font-bold leading-tight">Sem ligação à internet</p>
              <p className="text-[10px] text-white/70 leading-snug">
                Pode ver o ecrã de login e o menu. Login, saldos e saques só funcionam online.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (justOnline) {
    return (
      <div
        role="status"
        aria-live="polite"
        className="fixed top-0 inset-x-0 z-[100]"
      >
        <div className="mx-auto max-w-lg px-3 pt-[max(0.5rem,env(safe-area-inset-top))]">
          <div className="flex items-center gap-2.5 rounded-2xl bg-emerald-600 text-white px-3.5 py-2.5 shadow-lg shadow-emerald-600/30">
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <Wifi className="w-4 h-4" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-[12px] font-bold leading-tight">Ligação restabelecida</p>
              <p className="text-[10px] text-white/85">Pode continuar a usar o ADXmoney.</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
