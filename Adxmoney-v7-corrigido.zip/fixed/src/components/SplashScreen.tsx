import React, { useState, useEffect } from "react";
import { RefreshCw } from "lucide-react";

interface SplashScreenProps {
  message?: string;
  showReloadAfterMs?: number;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  message = "Conectando ao sistema...",
  showReloadAfterMs = 7000
}) => {
  const [showReload, setShowReload] = useState(false);
  const [imgError, setImgError] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowReload(true);
    }, showReloadAfterMs);

    return () => clearTimeout(timer);
  }, [showReloadAfterMs]);

  const handleReload = () => {
    window.location.reload();
  };

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed inset-0 z-50 flex flex-col items-center justify-center antialiased p-4 select-none"
      style={{
        background:
          "radial-gradient(ellipse 120% 80% at 50% -20%, rgba(15, 118, 110, 0.1), transparent 50%), #f5f6f8",
      }}
    >
      <div className="relative flex flex-col items-center gap-7 max-w-xs text-center animate-fade-up">
        {/* Logo */}
        <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-[1.75rem] gradient-adx flex items-center justify-center shadow-2xl shadow-teal-900/25 overflow-hidden">
          {!imgError ? (
            <img
              src="/logo.png"
              alt="ADXmoney"
              onError={() => setImgError(true)}
              className="w-full h-full object-cover"
            />
          ) : (
            <span className="text-white text-3xl font-extrabold tracking-wider">ADX</span>
          )}
        </div>

        {/* Nome do app */}
        <div className="flex flex-col items-center gap-2.5">
          <h1 className="font-extrabold text-slate-900 tracking-tight text-3xl">ADXmoney</h1>
          <p className="text-[12px] text-slate-400 font-semibold uppercase tracking-[0.15em]">
            Monetização premium
          </p>
          <div className="flex items-center gap-2 text-slate-500 font-medium mt-1">
            <span className="w-2 h-2 rounded-full bg-teal-500 animate-pulse flex-shrink-0" />
            <span className="text-sm">{message}</span>
          </div>
        </div>

        {showReload && (
          <div className="mt-2 flex flex-col items-center gap-2 animate-in fade-in duration-500">
            <p className="text-xs text-slate-400">Está demorando mais do que o esperado?</p>
            <button
              onClick={handleReload}
              type="button"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-teal-700 bg-teal-50 hover:bg-teal-100 rounded-full border border-teal-200 transition-colors shadow-sm active:scale-95"
            >
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              Recarregar página
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
