import React, { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import {
  Loader2,
  Sparkles,
  Target,
  Users,
  Wallet,
  Megaphone,
  RefreshCw,
  ArrowRight,
  CreditCard,
} from "lucide-react";

interface Action {
  title: string;
  description: string;
  priority: "high" | "medium" | "low";
  type: string;
}

interface CoachResponse {
  greeting: string;
  summary: string;
  actions: Action[];
  motivation: string;
  meta?: {
    balance: number;
    pending_tasks: number;
    total_referrals: number;
    is_subscriber: boolean;
  };
}

interface Props {
  open: boolean;
  onClose: () => void;
  /** Navegar para uma aba do app */
  onNavigate?: (tab: "tasks" | "campaigns" | "affiliate" | "wallet" | "engagement") => void;
  /** Abrir o gerador de conteúdo */
  onOpenContentGenerator?: () => void;
}

const priorityColor = {
  high: "bg-rose-50 text-rose-700 border-rose-100",
  medium: "bg-amber-50 text-amber-700 border-amber-100",
  low: "bg-slate-50 text-slate-600 border-slate-100",
};

const typeIcon: Record<string, React.ElementType> = {
  task: Target,
  affiliate: Users,
  withdraw: Wallet,
  content: Megaphone,
  subscription: CreditCard,
  general: Sparkles,
};

const typeActionLabel: Record<string, string> = {
  task: "Ver tarefas",
  affiliate: "Ver afiliado",
  withdraw: "Ver carteira",
  content: "Gerar conteúdo",
  subscription: "Ver assinatura",
  general: "OK",
};

export default function IAAdxCoach({
  open,
  onClose,
  onNavigate,
  onOpenContentGenerator,
}: Props) {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<CoachResponse | null>(null);

  const loadCoach = async () => {
    setLoading(true);
    setData(null);
    try {
      const { data: res, error } = await supabase.functions.invoke("ai-coach", {
        body: {},
      });

      if (error) throw error;
      if (res?.error) throw new Error(res.error);

      setData(res as CoachResponse);
    } catch (err: any) {
      console.error(err);
      toast.error(err.message || "Erro ao carregar o Coach");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    if (open) {
      loadCoach();
    }
  }, [open]);

  const handleActionClick = (type: string) => {
    onClose();
    switch (type) {
      case "task":
        onNavigate?.("tasks");
        break;
      case "affiliate":
        onNavigate?.("affiliate");
        break;
      case "withdraw":
        onNavigate?.("wallet");
        break;
      case "content":
        onOpenContentGenerator?.();
        break;
      case "subscription":
        onNavigate?.("wallet");
        break;
      default:
        break;
    }
  };

  const meta = data?.meta;

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="bg-white rounded-2xl border border-slate-200 max-w-md p-0 max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="px-5 pt-5 pb-3 text-left space-y-1 border-b border-slate-100">
          <DialogTitle className="text-[17px] font-semibold text-slate-900 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#0f766e]" />
            Coach de Ganhos
          </DialogTitle>
          <DialogDescription className="text-[13px] text-slate-500">
            O que podes fazer hoje para ganhar mais
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {loading && (
            <div className="flex flex-col items-center justify-center py-12 gap-3">
              <Loader2 className="w-7 h-7 animate-spin text-[#0f766e]" />
              <p className="text-[13px] text-slate-500">
                A analisar a tua conta...
              </p>
            </div>
          )}

          {!loading && data && (
            <>
              {/* Cartões de resumo rápido */}
              {meta && (
                <div className="grid grid-cols-3 gap-2">
                  <div className="rounded-xl bg-emerald-50 border border-emerald-100 p-2.5 text-center">
                    <p className="text-[10px] font-medium text-emerald-600 uppercase tracking-wide">
                      Saldo
                    </p>
                    <p className="text-[13px] font-semibold text-emerald-800 mt-0.5 tabular-nums">
                      {meta.balance.toLocaleString("pt-AO", {
                        maximumFractionDigits: 0,
                      })}{" "}
                      <span className="text-[10px] font-normal">Kz</span>
                    </p>
                  </div>
                  <div className="rounded-xl bg-amber-50 border border-amber-100 p-2.5 text-center">
                    <p className="text-[10px] font-medium text-amber-600 uppercase tracking-wide">
                      Tarefas
                    </p>
                    <p className="text-[13px] font-semibold text-amber-800 mt-0.5 tabular-nums">
                      {meta.pending_tasks}
                    </p>
                  </div>
                  <div className="rounded-xl bg-violet-50 border border-violet-100 p-2.5 text-center">
                    <p className="text-[10px] font-medium text-violet-600 uppercase tracking-wide">
                      Afiliados
                    </p>
                    <p className="text-[13px] font-semibold text-violet-800 mt-0.5 tabular-nums">
                      {meta.total_referrals}
                    </p>
                  </div>
                </div>
              )}

              {/* Saudação + Resumo */}
              <div className="space-y-1.5">
                <p className="text-[15px] font-medium text-slate-900">
                  {data.greeting}
                </p>
                <p className="text-[13px] text-slate-600 leading-relaxed">
                  {data.summary}
                </p>
              </div>

              {/* Ações com botão */}
              {data.actions?.length > 0 && (
                <div className="space-y-2.5">
                  <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Ações prioritárias
                  </p>
                  {data.actions.map((action, i) => {
                    const Icon = typeIcon[action.type] || typeIcon.general;
                    const btnLabel =
                      typeActionLabel[action.type] || typeActionLabel.general;
                    const canNavigate = [
                      "task",
                      "affiliate",
                      "withdraw",
                      "content",
                      "subscription",
                    ].includes(action.type);

                    return (
                      <div
                        key={i}
                        className={`rounded-xl border p-3.5 ${
                          priorityColor[action.priority] || priorityColor.medium
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <div className="mt-0.5 shrink-0">
                            <Icon className="w-4 h-4" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-[13px] font-semibold leading-snug">
                              {action.title}
                            </p>
                            <p className="text-[12px] mt-0.5 opacity-80 leading-relaxed">
                              {action.description}
                            </p>
                            {canNavigate && (
                              <button
                                type="button"
                                onClick={() => handleActionClick(action.type)}
                                className="mt-2 inline-flex items-center gap-1 text-[12px] font-semibold opacity-90 hover:opacity-100 transition-opacity"
                              >
                                {btnLabel}
                                <ArrowRight className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Motivação */}
              {data.motivation && (
                <div className="bg-slate-50 rounded-xl p-3.5 border border-slate-100">
                  <p className="text-[12.5px] text-slate-600 leading-relaxed italic">
                    “{data.motivation}”
                  </p>
                </div>
              )}
            </>
          )}
        </div>

        <div className="px-5 py-3.5 border-t border-slate-100 flex gap-2">
          <Button
            variant="outline"
            onClick={loadCoach}
            disabled={loading}
            className="flex-1 h-10 rounded-xl text-[13px]"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 mr-1.5 ${loading ? "animate-spin" : ""}`}
            />
            Atualizar
          </Button>
          <Button
            onClick={onClose}
            className="flex-1 h-10 rounded-xl bg-[#0f766e] hover:bg-[#0d9488] text-white text-[13px]"
          >
            Fechar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
