import { checkProofFile, proofPath } from "@/lib/upload";
import React, { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Search,
  PlusCircle,
  CheckCircle2,
  Clock,
  XCircle,
  RefreshCw,
  Loader2,
  ArrowRight,
  ArrowLeft,
  ShoppingBag,
  Coins
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { CampaignRequestModal } from "./CampaignRequestModal";
import { Megaphone } from "lucide-react";

interface EngagementOrder {
  id: string;
  user_id: string;
  platform: string;
  service_type: string;
  target_link: string;
  quantity: number;
  total_price: number;
  currency: string;
  method: string;
  proof_url: string;
  status: "PENDING" | "APPROVED" | "REJECTED";
  rejection_reason?: string;
  created_at: string;
}

interface LoProps {
  selectedCurrency?: "USD" | "AOA" | "EUR" | "BRL";
  exchangeRates?: {
    AOA: number;
    USD: number;
    EUR: number;
    BRL: number;
  };
  formatCurrency?: (amountKz: number) => string;
  onOpenIA?: () => void;
}

export const LoComponent: React.FC<LoProps> = ({
  selectedCurrency = "USD",
  exchangeRates: propsRates,
  formatCurrency: propsFormat,
  onOpenIA,
}) => {
  const { user } = useAuth();
  
  // Taxas de câmbio unificadas vindas do Pai ou fallback
  const exchangeRates = propsRates || {
    USD: 1.00,
    AOA: 950.00,
    EUR: 0.92,
    BRL: 5.40,
  };

  const currency = selectedCurrency;

  const formatValue = (amountInCurrency: number) => {
    const symbols = { AOA: "Kz", USD: "$", EUR: "€", BRL: "R$" };
    const formatter = new Intl.NumberFormat("pt-PT", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    
    if (currency === "AOA") return `${formatter.format(amountInCurrency)} Kz`;
    return `${symbols[currency]} ${formatter.format(amountInCurrency)}`;
  };

  // Principal Mode: "menu" | "solicitar" | "consultar"
  const [mode, setMode] = useState<"menu" | "solicitar" | "consultar">("menu");

  // Wizard Steps (1: Pedido + Cálculo, 2: Confirmação, 3: Pagamento, 4: Finalização)
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  const [platform, setPlatform] = useState<"TikTok" | "Instagram" | "YouTube">("TikTok");
  const [serviceType, setServiceType] = useState<"Seguidores" | "Gostos" | "Comentários">("Seguidores");
  const [targetLink, setTargetLink] = useState("");
  const [quantity, setQuantity] = useState<number>(0);

  // Histórico
  const [userOrders, setUserOrders] = useState<EngagementOrder[]>([]);
  const [loadingList, setLoadingList] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [createdOrderCode, setCreatedOrderCode] = useState<string>("");

  // Consulta State
  const [searchCode, setSearchCode] = useState("");
  const [searchedOrder, setSearchedOrder] = useState<EngagementOrder | null>(null);
  const [searching, setSearching] = useState(false);
  
  // Pagamento State
  const [method, setMethod] = useState<"MULTICAIXA" | "UNITEL">("MULTICAIXA");
  const [file, setFile] = useState<File | null>(null);

  // Modal para Solicitar Campanha Coletiva (10 USD)
  const [isCampaignModalOpen, setIsCampaignModalOpen] = useState(false);

  // Preço unitário base em USD (Ex: Seguidores TikTok = $0.03, Likes = $0.025, etc.)
  const getUnitUSD = (plat: string, srv: string): number => {
    if (plat === "TikTok" || plat === "Instagram") {
      if (srv === "Seguidores") return 0.0315; // ~29 AOA
      return 0.027; // ~25 AOA
    }
    if (plat === "YouTube") {
      if (srv === "Seguidores") return 0.038; // ~35 AOA
      return 0.032; // ~30 AOA
    }
    return 0.0315;
  };

  const unitUSD = getUnitUSD(platform, serviceType);
  const safeQuantity = Math.max(0, quantity || 0);
  const unitPriceInSelectedCurrency = unitUSD * exchangeRates[currency];
  const totalPrice = unitPriceInSelectedCurrency * safeQuantity;

  const fetchUserOrders = async () => {
    if (!user) return;
    setLoadingList(true);
    try {
      const { data } = await supabase
        .from("engagement_orders")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });
      setUserOrders((data as EngagementOrder[]) || []);
    } finally {
      setLoadingList(false);
    }
  };

  useEffect(() => {
    if (user) fetchUserOrders();
  }, [user]);

  const handleSearchOrder = async (codeToSearch?: string) => {
    const code = codeToSearch || searchCode;
    if (!code.trim()) {
      toast.error("Insira o código do pedido.");
      return;
    }
    setSearching(true);
    setSearchedOrder(null);
    try {
      const { data } = await supabase
        .from("engagement_orders")
        .select("*")
        .ilike("id", `%${code.trim()}%`)
        .limit(1);

      if (data && data.length > 0) {
        setSearchedOrder(data[0] as EngagementOrder);
        toast.success("Pedido localizado!");
      } else {
        toast.error("Pedido não encontrado.");
      }
    } finally {
      setSearching(false);
    }
  };

  const handleFinalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !file) return;
    if (safeQuantity <= 0) {
      toast.error("Informe uma quantidade válida.");
      return;
    }
    setSubmitting(true);
    try {
      const check = checkProofFile(file);
      if (!check.ok) throw new Error(check.error);
      const fileName = proofPath(`${user.id}`, check.ext!);

      const { error: uploadError } = await supabase.storage
        .from("subscription-proofs")
        .upload(fileName, file, { upsert: false, contentType: file.type });

      if (uploadError) {
        throw new Error(`Falha no upload do comprovativo: ${uploadError.message}`);
      }

      // RPC segura – grava engagement_orders com validações
      const { data, error } = await supabase.rpc("submit_engagement_order", {
        p_platform: platform,
        p_service_type: serviceType,
        p_target_link: targetLink.trim(),
        p_quantity: safeQuantity,
        p_total_price: totalPrice,
        p_currency: currency,
        p_method: method,
        p_proof_url: fileName,
      });

      if (error) throw error;

      const shortCode =
        (data as any)?.short_code ||
        ((data as any)?.order_id ? String((data as any).order_id).substring(0, 8).toUpperCase() : "OK");
      setCreatedOrderCode(shortCode);
      toast.success("Pedido submetido com sucesso!");
      setStep(4);
      fetchUserOrders();
    } catch (err: any) {
      toast.error(err.message || "Erro ao submeter pedido.");
    } finally {
      setSubmitting(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "APPROVED":
        return <Badge className="bg-emerald-50 text-emerald-700 border-0 text-[11px] font-medium">Aprovado</Badge>;
      case "REJECTED":
        return <Badge className="bg-rose-50 text-rose-700 border-0 text-[11px] font-medium">Rejeitado</Badge>;
      default:
        return <Badge className="bg-amber-50 text-amber-700 border-0 text-[11px] font-medium">Pendente</Badge>;
    }
  };

  return (
    <div className="space-y-4 tab-enter">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h2 className="text-[17px] font-semibold text-slate-900">Loja</h2>
          <p className="text-[13px] text-slate-500 mt-0.5">Impulsos e campanhas</p>
        </div>
        <div className="flex items-center gap-1">
          {onOpenIA && mode === "menu" && (
            <Button
              size="sm"
              variant="outline"
              onClick={onOpenIA}
              className="h-8 text-[12px] font-medium rounded-xl border-slate-200"
            >
              IA ADX
            </Button>
          )}
          {mode !== "menu" && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => {
                setMode("menu");
                setStep(1);
                setSearchedOrder(null);
              }}
              className="h-8 text-[13px] text-slate-600 font-medium"
            >
              <ArrowLeft className="w-3.5 h-3.5 mr-1" /> Voltar
            </Button>
          )}
        </div>
      </div>

      {mode === "menu" && (
        <div className="space-y-3">
          <div className="bg-white border border-slate-200/80 rounded-2xl p-4 flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-[12px] text-slate-500">
                Campanha coletiva · <span className="font-medium text-slate-700">10 USD</span>
              </p>
              <p className="text-[14px] font-medium text-slate-900 mt-0.5">Criar ação na comunidade</p>
              <p className="text-[12px] text-slate-400 mt-0.5">Avaliada pela administração</p>
            </div>
            <Button
              type="button"
              onClick={() => setIsCampaignModalOpen(true)}
              className="bg-[#0f766e] hover:bg-[#0d9488] text-white text-[13px] font-medium h-9 px-4 rounded-xl shrink-0"
            >
              Criar
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => {
                setMode("solicitar");
                setStep(1);
              }}
              className="bg-white border border-slate-200/80 p-4 rounded-2xl text-left pressable flex flex-col gap-3"
            >
              <div className="w-9 h-9 rounded-xl bg-slate-50 text-slate-700 flex items-center justify-center">
                <PlusCircle className="w-4.5 h-4.5" />
              </div>
              <div>
                <h3 className="text-[13px] font-medium text-slate-900">Comprar impulso</h3>
                <p className="text-[12px] text-slate-400 mt-0.5">Seguidores e gostos</p>
              </div>
            </button>

            <button
              onClick={() => setMode("consultar")}
              className="bg-white border border-slate-200/80 p-4 rounded-2xl text-left pressable flex flex-col gap-3"
            >
              <div className="w-9 h-9 rounded-xl bg-slate-50 text-slate-700 flex items-center justify-center">
                <Search className="w-4.5 h-4.5" />
              </div>
              <div>
                <h3 className="text-[13px] font-medium text-slate-900">Consultar</h3>
                <p className="text-[12px] text-slate-400 mt-0.5">Rastrear por código</p>
              </div>
            </button>
          </div>

          <div className="bg-white border border-slate-200/80 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[13px] font-medium text-slate-700">Histórico recente</span>
              <button onClick={fetchUserOrders} className="text-slate-400 hover:text-slate-600 pressable p-1">
                <RefreshCw className={`w-3.5 h-3.5 ${loadingList ? "animate-spin" : ""}`} />
              </button>
            </div>

            <div className="divide-y divide-slate-100">
              {userOrders.length === 0 ? (
                <p className="text-[13px] text-slate-400 text-center py-4">Nenhum pedido recente.</p>
              ) : (
                userOrders.slice(0, 3).map((o) => (
                  <div key={o.id} className="py-2.5 flex items-center justify-between text-xs">
                    <div>
                      <span className="font-bold text-slate-900">{o.platform} ({o.service_type})</span>
                      <span className="text-[10px] text-slate-400 block font-mono">#{o.id.substring(0, 6).toUpperCase()}</span>
                    </div>
                    {getStatusBadge(o.status)}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* WIZARD DE SOLICITAÇÃO */}
      {mode === "solicitar" && (
        <div className="bg-white border border-slate-200/80 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <span className="text-[13px] font-medium text-slate-700">
                Passo {step} de 4
              </span>
              <div className="flex gap-1">
                {[1, 2, 3, 4].map((s) => (
                  <div key={s} className={`w-6 h-1 rounded-full ${step >= s ? "bg-[#0f766e]" : "bg-slate-200"}`} />
                ))}
              </div>
            </div>

            {/* ETAPA 1: ESCOLHA DE REDE, SERVIÇO, QUANTIDADE E CÁLCULO PROFISSIONAL */}
            {step === 1 && (
              <div className="space-y-4">
                {/* Rede Social */}
                <div className="space-y-1.5">
                  <Label className="text-[11px] font-black uppercase text-slate-400 tracking-wider">Rede Social</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {(["TikTok", "Instagram", "YouTube"] as const).map((p) => (
                      <button
                        key={p}
                        type="button"
                        onClick={() => setPlatform(p)}
                        className={`p-2.5 rounded-xl border-2 text-[11px] font-black uppercase transition-all active:scale-95 ${
                          platform === p ? "border-emerald-600 bg-emerald-50 text-emerald-900 shadow-sm" : "border-slate-100 text-slate-400 bg-white"
                        }`}
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Serviço */}
                <div className="space-y-1.5">
                  <Label className="text-[11px] font-black uppercase text-slate-400 tracking-wider">Serviço</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: "Seguidores", label: platform === "YouTube" ? "Inscritos" : "Seguidores" },
                      { id: "Gostos", label: "Curtidas" },
                      { id: "Comentários", label: "Comentários" },
                    ].map((s) => (
                      <button
                        key={s.id}
                        type="button"
                        onClick={() => setServiceType(s.id as any)}
                        className={`p-2.5 rounded-xl border-2 text-[10px] font-black uppercase transition-all active:scale-95 ${
                          serviceType === s.id ? "border-emerald-600 bg-emerald-50 text-emerald-900 shadow-sm" : "border-slate-100 text-slate-400 bg-white"
                        }`}
                      >
                        {s.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Link */}
                <div className="space-y-1.5">
                  <Label className="text-[11px] font-black uppercase text-slate-400 tracking-wider">Link de Destino</Label>
                  <Input
                    placeholder="https://..."
                    value={targetLink}
                    onChange={(e) => setTargetLink(e.target.value)}
                    className="h-11 text-xs rounded-xl bg-slate-50 border-none focus:bg-white focus:ring-1 focus:ring-emerald-500 transition-all"
                  />
                </div>

                {/* Quantidade */}
                <div className="space-y-1.5">
                  <Label className="text-[11px] font-black uppercase text-slate-400 tracking-wider">Quantidade</Label>
                  <Input
                    type="number"
                    inputMode="numeric"
                    min={10}
                    max={1000000}
                    value={quantity || ""}
                    onChange={(e) => {
                      const n = parseInt(e.target.value.replace(/\D/g, ""), 10) || 0;
                      setQuantity(Math.min(1000000, Math.max(0, n)));
                    }}
                    placeholder="Mín. 10"
                    className="h-11 text-sm rounded-xl font-mono font-black bg-slate-50 border-none focus:bg-white focus:ring-1 focus:ring-emerald-500 transition-all"
                  />
                </div>

                {/* CÁLCULO PROFISSIONAL EM TEMPO REAL */}
                <div className="bg-slate-900 p-4 rounded-2xl flex items-center justify-between shadow-lg shadow-slate-200">
                  <div>
                    <span className="text-[9px] text-emerald-400 font-black uppercase tracking-widest block">Total Estimado ({currency})</span>
                    <span className="text-[10px] text-slate-400 font-bold">
                      {safeQuantity} un × {formatValue(unitPriceInSelectedCurrency)}
                    </span>
                  </div>
                  <span className="text-lg font-black text-white font-mono tabular-nums">
                    {formatValue(totalPrice)}
                  </span>
                </div>

                <Button
                  onClick={() => {
                    if (!targetLink.trim()) {
                      toast.error("Insira o link.");
                      return;
                    }
                    if (safeQuantity < 10) {
                      toast.error("A quantidade mínima é 10.");
                      return;
                    }
                    setStep(2);
                  }}
                  className="w-full h-12 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-xl text-xs uppercase tracking-widest shadow-xl shadow-emerald-100 active:scale-95 transition-all"
                >
                  Continuar <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            )}

            {/* ETAPA 2 */}
            {step === 2 && (
              <div className="space-y-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Moeda:</span>
                    <span className="font-bold text-slate-900">{currency}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Rede:</span>
                    <span className="font-bold text-slate-900">{platform}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Serviço:</span>
                    <span className="font-bold text-slate-900">{serviceType}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Quantidade:</span>
                    <span className="font-bold font-mono">{safeQuantity}</span>
                  </div>
                  <div className="pt-2 border-t border-slate-200 flex justify-between text-sm font-black">
                    <span>Total:</span>
                    <span className="font-mono text-emerald-600">
                      {totalPrice.toLocaleString("pt-AO", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {currency}
                    </span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setStep(1)} className="flex-1 h-10 text-xs rounded-xl">
                    Voltar
                  </Button>
                  <Button onClick={() => setStep(3)} className="flex-1 h-10 bg-emerald-600 text-white font-bold rounded-xl text-xs">
                    Pagamento
                  </Button>
                </div>
              </div>
            )}

            {/* ETAPA 3 */}
            {step === 3 && (
              <form onSubmit={handleFinalSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: "MULTICAIXA", label: "Multicaixa Express" },
                    { id: "UNITEL", label: "Unitel Money" },
                  ].map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setMethod(m.id as any)}
                      className={`p-2.5 rounded-xl border text-xs font-bold ${
                        method === m.id ? "border-emerald-600 bg-emerald-50 text-emerald-900" : "border-slate-200 text-slate-600"
                      }`}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>

                <div className="p-3 bg-slate-50 rounded-xl text-[11px] text-slate-600 space-y-1">
                  <p>Ref: <strong className="font-mono">924 555 888</strong> ({method})</p>
                  <p>Valor Exato: <strong className="font-mono">{totalPrice.toLocaleString("pt-AO", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {currency}</strong></p>
                </div>

                <div
                  onClick={() => document.getElementById("m-file")?.click()}
                  className="border-2 border-dashed rounded-xl p-3 text-center cursor-pointer text-xs text-slate-500"
                >
                  <input id="m-file" type="file" className="hidden" onChange={(e) => e.target.files && setFile(e.target.files[0])} />
                  {file ? <span className="text-emerald-600 font-bold">{file.name}</span> : <span>Anexar Comprovativo</span>}
                </div>

                <div className="flex gap-2">
                  <Button type="button" variant="outline" onClick={() => setStep(2)} className="flex-1 h-10 text-xs rounded-xl">
                    Voltar
                  </Button>
                  <Button type="submit" disabled={submitting || !file} className="flex-1 h-10 bg-emerald-600 text-white font-bold rounded-xl text-xs">
                    {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : "Concluir"}
                  </Button>
                </div>
              </form>
            )}

            {/* ETAPA 4 */}
            {step === 4 && (
              <div className="text-center space-y-3 py-4">
                <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="text-sm font-black text-slate-900">Pedido Enviado!</h3>
                <div className="bg-slate-50 p-3 rounded-xl inline-block font-mono font-bold text-base text-slate-800">
                  {createdOrderCode}
                </div>
                <Button onClick={() => setMode("menu")} className="w-full h-10 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-[13px] font-medium">
                  Voltar ao início
                </Button>
              </div>
            )}
        </div>
      )}

      {/* TELA DE CONSULTA */}
      {mode === "consultar" && (
        <div className="bg-white border border-slate-200/80 rounded-2xl p-5 space-y-4">
            <div className="flex gap-2">
              <Input
                placeholder="Código (ex: A1B2C3D4)"
                value={searchCode}
                onChange={(e) => setSearchCode(e.target.value)}
                className="h-10 text-[13px] rounded-xl font-mono uppercase"
              />
              <Button onClick={() => handleSearchOrder()} disabled={searching} className="h-10 px-4 bg-[#0f766e] hover:bg-[#0d9488] text-white rounded-xl text-[13px] font-medium">
                {searching ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : "Buscar"}
              </Button>
            </div>

            {searchedOrder && (
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-2 text-[13px]">
                <div className="flex justify-between items-center">
                  <span className="font-mono font-medium text-slate-800">#{searchedOrder.id.substring(0, 6).toUpperCase()}</span>
                  {getStatusBadge(searchedOrder.status)}
                </div>
                <p className="text-slate-600">{searchedOrder.platform} • {searchedOrder.service_type} ({searchedOrder.quantity} un)</p>
                {searchedOrder.rejection_reason && (
                  <p className="text-rose-600 text-[12px]">Motivo: {searchedOrder.rejection_reason}</p>
                )}
              </div>
            )}
        </div>
      )}

      {/* Modal de Solicitação de Campanha Coletiva (10 USD) */}
      <CampaignRequestModal
        isOpen={isCampaignModalOpen}
        onClose={() => setIsCampaignModalOpen(false)}
        onSuccess={() => {
          toast.success("Solicitação enviada para a administração!");
        }}
        userId={user?.id || ""}
      />
    </div>
  );
};

export default LoComponent;
