import React, { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Send,
  Loader2,
  DollarSign,
  ArrowRight,
  ArrowLeft,
  Target,
  AlertTriangle,
  Wallet,
  ShieldCheck,
  Info,
} from "lucide-react";
import { toast } from "sonner";

interface CampaignRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  userId: string;
  /** Chamado quando o saldo é insuficiente — abrir carregamento de conta */
  onNeedDeposit?: () => void;
}

/** Custo da solicitação em Kz (10 USD × 950) — alinhado à carteira */
const COST_KZ = 9500;

export const CampaignRequestModal: React.FC<CampaignRequestModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  userId,
  onNeedDeposit,
}) => {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [submitting, setSubmitting] = useState(false);
  const [balance, setBalance] = useState<number>(0);
  const [isSubscriber, setIsSubscriber] = useState(false);
  const [loadingBalance, setLoadingBalance] = useState(true);

  // Form State
  const [title, setTitle] = useState("");
  const [platform, setPlatform] = useState("Instagram");
  const [targetUrl, setTargetUrl] = useState("");
  const [actionType, setActionType] = useState("follow");
  const [objective, setObjective] = useState("");
  const [description, setDescription] = useState("");
  const [targetAudience, setTargetAudience] = useState("Geral");
  const [requesterPhone, setRequesterPhone] = useState("");
  const [currency, setCurrency] = useState<"USD" | "AOA" | "EUR" | "BRL">("USD");

  const exchangeRates = { USD: 1, AOA: 950, EUR: 0.92, BRL: 5.4 };
  const currencySymbols = { USD: "$", AOA: "Kz", EUR: "€", BRL: "R$" };
  const costInSelectedCurrency = (COST_KZ / 950) * exchangeRates[currency];
  const hasEnoughBalance = balance >= COST_KZ;

  useEffect(() => {
    if (!isOpen || !userId) return;
    const load = async () => {
      setLoadingBalance(true);
      try {
        const { data: w } = await supabase
          .from("wallets")
          .select("balance")
          .eq("user_id", userId)
          .maybeSingle();
        setBalance(Number(w?.balance ?? 0));

        const { data: p } = await supabase
          .from("profiles")
          .select("subscription_status")
          .eq("id", userId)
          .maybeSingle();
        setIsSubscriber(p?.subscription_status === "active");
      } catch (e) {
        console.error(e);
      } finally {
        setLoadingBalance(false);
      }
    };
    load();
  }, [isOpen, userId]);

  const resetForm = () => {
    setTitle("");
    setPlatform("Instagram");
    setTargetUrl("");
    setActionType("follow");
    setObjective("");
    setDescription("");
    setTargetAudience("Geral");
    setRequesterPhone("");
    setStep(1);
  };

  const handleNext = () => {
    if (step === 1) {
      if (!title.trim() || !targetUrl.trim() || !objective.trim()) {
        toast.error("Preencha todos os campos obrigatórios da Etapa 1.");
        return;
      }
      setStep(2);
    } else if (step === 2) {
      if (!description.trim()) {
        toast.error("Descreva as orientações para a comunidade.");
        return;
      }
      setStep(3);
    }
  };

  const handlePayWithBalance = async () => {
    if (!hasEnoughBalance) {
      toast.error("Saldo insuficiente. Carregue a conta para continuar.");
      return;
    }
    await submitRequest();
  };

  const handleNeedDeposit = () => {
    onClose();
    if (onNeedDeposit) {
      onNeedDeposit();
    } else {
      toast.info("Saldo insuficiente. Abra Conta → Carregar conta.");
    }
  };

  const submitRequest = async () => {
    if (!userId) {
      toast.error("Erro de identificação do utilizador.");
      return;
    }

    setSubmitting(true);
    try {
      const fullDescription = `[Campanha - Custo: ${COST_KZ} Kz | Plataforma: ${platform} | Ação: ${actionType} | Público: ${targetAudience}] ${description}`;
      const extra = JSON.stringify({
        platform,
        target_url: targetUrl.trim(),
        action_type: actionType,
        target_audience: targetAudience,
        requester_phone: requesterPhone.trim(),
        cost_kz: COST_KZ,
        cost_usd_equiv: 10,
        paid_currency: currency,
        cost_formatted: `${costInSelectedCurrency.toLocaleString()} ${currencySymbols[currency]}`,
        paid_with_balance: true,
        estimated_reach: "1.000 a 5.000 membros ativos",
        estimated_completion: "24h a 48h após aprovação",
      });

      // RPC atómica: cria pedido PENDING + debita carteira (sem cobrança órfã)
      const { data, error } = await supabase.rpc("submit_paid_campaign_request", {
        p_title: title.trim(),
        p_platform: platform,
        p_target_url: targetUrl.trim(),
        p_action_type: actionType,
        p_objective: objective.trim() || null,
        p_description: fullDescription,
        p_target_audience: targetAudience,
        p_requester_phone: requesterPhone.trim() || null,
        p_cost_kz: COST_KZ,
        p_additional_information: extra,
      });
      if (error) throw error;

      const result = data as {
        success?: boolean;
        error?: string;
        balance?: number;
        required?: number;
      } | null;

      if (result && result.success === false) {
        toast.error(
          result.error ||
            `Saldo insuficiente. Disponível: ${result.balance ?? "?"} Kz | Necessário: ${result.required ?? COST_KZ} Kz`
        );
        return;
      }

      toast.success("Solicitação enviada! A equipa vai avaliar. Após aprovação a campanha será publicada.");
      resetForm();
      onSuccess();
      onClose();
    } catch (err: any) {
      console.error("Erro ao enviar solicitação:", err);
      toast.error(err.message || "Erro ao processar solicitação.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => { if (!open) resetForm(); onClose(); }}>
      <DialogContent className="max-w-xl bg-white border-none sm:rounded-3xl p-6 sm:p-8 shadow-2xl max-h-[92vh] overflow-y-auto">
        <DialogHeader className="border-b border-slate-100 pb-4">
          <div className="flex items-center justify-between mb-2">
            <Badge className="bg-emerald-50 text-emerald-700 border-none text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full">
              Campanha Coletiva
            </Badge>
            <div className="flex items-center gap-1.5 text-xs font-black text-slate-400">
              <span className={step >= 1 ? "text-emerald-600" : ""}>1. Dados</span>
              <span>•</span>
              <span className={step >= 2 ? "text-emerald-600" : ""}>2. Detalhes</span>
              <span>•</span>
              <span className={step === 3 ? "text-emerald-600" : ""}>3. Pagamento</span>
            </div>
          </div>
          <DialogTitle className="text-xl font-black text-slate-900">
            Solicitar Campanha
          </DialogTitle>
          <DialogDescription className="text-xs text-slate-500 font-medium">
            Taxa fixa de {COST_KZ.toLocaleString("pt-PT")} Kz (débito da carteira). A campanha passa por análise antes de ser publicada.
          </DialogDescription>
        </DialogHeader>

        {/* Aviso de assinatura */}
        <div className="mt-4 rounded-xl bg-amber-50 border border-amber-100 p-3 flex gap-2.5">
          <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <p className="text-[12px] text-amber-800 leading-relaxed">
            <strong>Para acompanhar a campanha</strong> após a publicação é necessário ser <strong>assinante</strong>.
            O sistema avalia a proposta; só após aprovação a campanha é publicada.
          </p>
        </div>

        {/* Regras */}
        <div className="mt-3 rounded-xl bg-slate-50 border border-slate-100 p-3 flex gap-2.5">
          <AlertTriangle className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
          <div className="text-[12px] text-slate-600 leading-relaxed space-y-1">
            <p className="font-semibold text-slate-800">Regras da campanha:</p>
            <ul className="list-disc pl-4 space-y-0.5">
              <li>Não é permitida promoção de canal pessoal ou engajamento próprio sem fins lucrativos.</li>
              <li>Campanhas servem para publicidades pagas e conteúdos de canais que já monetizam.</li>
              <li>Evita-se cliques e engajamento sem fins lucrativos.</li>
            </ul>
          </div>
        </div>

        {/* ETAPA 1 */}
        {step === 1 && (
          <div className="mt-5 space-y-4">
            <div className="space-y-1.5">
              <Label className="text-[13px] font-semibold">Título da campanha *</Label>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Ex: Follow no Instagram do produto X" className="h-11 rounded-xl" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-[13px] font-semibold">Plataforma</Label>
                <Select value={platform} onValueChange={setPlatform}>
                  <SelectTrigger className="h-11 rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Instagram">Instagram</SelectItem>
                    <SelectItem value="TikTok">TikTok</SelectItem>
                    <SelectItem value="YouTube">YouTube</SelectItem>
                    <SelectItem value="Facebook">Facebook</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-[13px] font-semibold">Tipo de ação</Label>
                <Select value={actionType} onValueChange={setActionType}>
                  <SelectTrigger className="h-11 rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="follow">Seguir</SelectItem>
                    <SelectItem value="like">Curtir</SelectItem>
                    <SelectItem value="comment">Comentar</SelectItem>
                    <SelectItem value="view">Visualizar</SelectItem>
                    <SelectItem value="share">Partilhar</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-[13px] font-semibold">URL alvo *</Label>
              <Input value={targetUrl} onChange={(e) => setTargetUrl(e.target.value)} placeholder="https://..." className="h-11 rounded-xl" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-[13px] font-semibold">Objetivo *</Label>
              <Input value={objective} onChange={(e) => setObjective(e.target.value)} placeholder="Ex: 2000 novos seguidores" className="h-11 rounded-xl" />
            </div>
            <Button onClick={handleNext} className="w-full h-11 rounded-xl bg-emerald-600 hover:bg-emerald-700 font-bold mt-2">
              Continuar <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        )}

        {/* ETAPA 2 */}
        {step === 2 && (
          <div className="mt-5 space-y-4">
            <div className="space-y-1.5">
              <Label className="text-[13px] font-semibold">Orientações para a comunidade *</Label>
              <Textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Explique o que os membros devem fazer, regras e observações..."
                className="min-h-[100px] rounded-xl"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-[13px] font-semibold">Público-alvo</Label>
              <Select value={targetAudience} onValueChange={setTargetAudience}>
                <SelectTrigger className="h-11 rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Geral">Geral</SelectItem>
                  <SelectItem value="Angola">Angola</SelectItem>
                  <SelectItem value="Brasil">Brasil</SelectItem>
                  <SelectItem value="Moçambique">Moçambique</SelectItem>
                  <SelectItem value="Portugal">Portugal</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-[13px] font-semibold">WhatsApp de contacto</Label>
              <Input value={requesterPhone} onChange={(e) => setRequesterPhone(e.target.value)} placeholder="+244..." className="h-11 rounded-xl" />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setStep(1)} className="flex-1 h-11 rounded-xl">
                <ArrowLeft className="w-4 h-4 mr-2" /> Voltar
              </Button>
              <Button onClick={handleNext} className="flex-1 h-11 rounded-xl bg-emerald-600 hover:bg-emerald-700 font-bold">
                Continuar <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        )}

        {/* ETAPA 3 - PAGAMENTO */}
        {step === 3 && (
          <div className="mt-5 space-y-4">
            <div className="rounded-2xl bg-slate-50 border border-slate-100 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-slate-700">Custo da solicitação</span>
                <span className="text-lg font-black text-emerald-700">{COST_KZ.toLocaleString("pt-PT")} Kz</span>
              </div>
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="flex items-center gap-1.5"><Wallet className="w-3.5 h-3.5" /> Seu saldo</span>
                <span className="font-bold">{loadingBalance ? "..." : `${Number(balance).toLocaleString("pt-PT", { minimumFractionDigits: 2 })} Kz`}</span>
              </div>
              {!isSubscriber && (
                <p className="text-[11px] text-amber-700 bg-amber-50 rounded-lg px-2 py-1.5">
                  Não és assinante. Podes solicitar a campanha, mas para acompanhar o progresso precisas de assinatura ativa.
                </p>
              )}
            </div>

            <div className="space-y-1.5">
              <Label className="text-[13px] font-semibold">Moeda de referência</Label>
              <Select value={currency} onValueChange={(v) => setCurrency(v as any)}>
                <SelectTrigger className="h-11 rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD ($)</SelectItem>
                  <SelectItem value="AOA">AOA (Kz)</SelectItem>
                  <SelectItem value="EUR">EUR (€)</SelectItem>
                  <SelectItem value="BRL">BRL (R$)</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-[11px] text-slate-400">
                Equivalente: {costInSelectedCurrency.toLocaleString()} {currencySymbols[currency]}
              </p>
            </div>

            <div className="flex flex-col gap-2 pt-2">
              {hasEnoughBalance ? (
                <Button
                  onClick={handlePayWithBalance}
                  disabled={submitting}
                  className="w-full h-12 rounded-xl bg-emerald-600 hover:bg-emerald-700 font-bold"
                >
                  {submitting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Wallet className="w-4 h-4 mr-2" />}
                  Pagar com saldo ({COST_KZ.toLocaleString("pt-PT")} Kz)
                </Button>
              ) : (
                <Button
                  onClick={handleNeedDeposit}
                  disabled={submitting}
                  className="w-full h-12 rounded-xl bg-teal-600 hover:bg-teal-700 font-bold"
                >
                  <Wallet className="w-4 h-4 mr-2" />
                  Carregar conta
                </Button>
              )}
              <Button variant="outline" onClick={() => setStep(2)} disabled={submitting} className="w-full h-11 rounded-xl">
                <ArrowLeft className="w-4 h-4 mr-2" /> Voltar
              </Button>
            </div>

            <p className="text-[11px] text-slate-400 text-center leading-relaxed">
              Após o pagamento, a equipa avalia a campanha. Só campanhas aprovadas são publicadas.
              Lembre-se: não são aceites promoções de canais pessoais nem engajamento sem fins lucrativos.
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
