import React, { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import {
  Loader2,
  MessageCircleQuestion,
  Send,
  MessageSquare,
} from "lucide-react";

interface Props {
  open: boolean;
  onClose: () => void;
}

const QUICK_QUESTIONS = [
  "Como faço um saque?",
  "Quanto demora o levantamento?",
  "Como funciona o código de afiliado?",
  "O que é a assinatura?",
  "Como começo a ganhar?",
];

export default function IAAdxSupport({ open, onClose }: Props) {
  const [question, setQuestion] = useState("");
  const [loading, setLoading] = useState(false);
  const [answer, setAnswer] = useState<string | null>(null);
  const [suggestions, setSuggestions] = useState<string[]>([]);

  const ask = async (q: string) => {
    const text = q.trim();
    if (!text) return;

    setLoading(true);
    setAnswer(null);
    setSuggestions([]);
    setQuestion(text);

    try {
      const { data, error } = await supabase.functions.invoke("ai-support", {
        body: { question: text },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      setAnswer(data.answer || "Sem resposta.");
      setSuggestions(
        Array.isArray(data.suggested_actions) ? data.suggested_actions : []
      );
    } catch (err: any) {
      console.error(err);
      toast.error(err.message || "Erro ao consultar o suporte");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    ask(question);
  };

  React.useEffect(() => {
    if (!open) {
      setQuestion("");
      setAnswer(null);
      setSuggestions([]);
      setLoading(false);
    }
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="bg-white rounded-2xl border border-slate-200 max-w-md p-0 max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="px-5 pt-5 pb-3 text-left space-y-1 border-b border-slate-100">
          <DialogTitle className="text-[17px] font-semibold text-slate-900 flex items-center gap-2">
            <MessageCircleQuestion className="w-4 h-4 text-[#0f766e]" />
            Suporte Inteligente
          </DialogTitle>
          <DialogDescription className="text-[13px] text-slate-500">
            Perguntas sobre regras, saques, afiliados e assinatura
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {/* Perguntas rápidas */}
          {!answer && !loading && (
            <div className="space-y-2">
              <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Perguntas frequentes
              </p>
              <div className="flex flex-wrap gap-2">
                {QUICK_QUESTIONS.map((q) => (
                  <button
                    key={q}
                    type="button"
                    onClick={() => ask(q)}
                    className="text-left text-[12px] px-3 py-2 rounded-xl bg-slate-50 border border-slate-100 text-slate-700 hover:bg-slate-100 transition-colors"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Loading */}
          {loading && (
            <div className="flex flex-col items-center justify-center py-10 gap-3">
              <Loader2 className="w-6 h-6 animate-spin text-[#0f766e]" />
              <p className="text-[13px] text-slate-500">A procurar a resposta...</p>
            </div>
          )}

          {/* Resposta */}
          {!loading && answer && (
            <div className="space-y-3">
              <div className="rounded-xl bg-slate-50 border border-slate-100 p-3.5">
                <p className="text-[11px] font-medium text-slate-400 mb-1.5">
                  A tua pergunta
                </p>
                <p className="text-[13px] text-slate-700">{question}</p>
              </div>
              <div className="rounded-xl bg-teal-50/60 border border-teal-100 p-3.5">
                <p className="text-[11px] font-medium text-teal-700 mb-1.5">
                  Resposta
                </p>
                <p className="text-[13px] text-slate-800 leading-relaxed whitespace-pre-wrap">
                  {answer}
                </p>
              </div>
              {suggestions.length > 0 && (
                <div className="space-y-1.5">
                  <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Sugestões
                  </p>
                  <ul className="space-y-1">
                    {suggestions.map((s, i) => (
                      <li
                        key={i}
                        className="text-[12px] text-slate-600 flex items-start gap-2"
                      >
                        <span className="text-[#0f766e] mt-0.5">•</span>
                        {s}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              <button
                type="button"
                onClick={() => {
                  setAnswer(null);
                  setSuggestions([]);
                  setQuestion("");
                }}
                className="text-[12px] font-medium text-[#0f766e] hover:underline"
              >
                Fazer outra pergunta
              </button>
            </div>
          )}
        </div>

        {/* Input */}
        <form
          onSubmit={handleSubmit}
          className="px-5 py-3.5 border-t border-slate-100 flex gap-2"
        >
          <Input
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Escreve a tua pergunta..."
            disabled={loading}
            className="h-10 rounded-xl text-[13px] border-slate-200"
            maxLength={500}
          />
          <Button
            type="submit"
            disabled={loading || !question.trim()}
            className="h-10 w-10 shrink-0 rounded-xl bg-[#0f766e] hover:bg-[#0d9488] text-white p-0"
          >
            {loading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </form>

        {/* Link WhatsApp */}
        <div className="px-5 pb-4">
          <button
            type="button"
            onClick={() =>
              window.open(
                "https://wa.me/244933271690?text=Olá,%20preciso%20de%20suporte%20no%20ADXmoney",
                "_blank"
              )
            }
            className="w-full flex items-center justify-center gap-2 h-9 rounded-xl border border-slate-200 text-[12px] font-medium text-slate-600 hover:bg-slate-50 transition-colors"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            Falar com suporte humano (WhatsApp)
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
