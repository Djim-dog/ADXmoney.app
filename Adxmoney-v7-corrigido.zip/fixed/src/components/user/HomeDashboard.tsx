import React, { useMemo, useState } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import {
  TrendingUp,
  TrendingDown,
  ArrowDownLeft,
  ArrowUpRight,
  Wallet,
  Layers,
  Megaphone,
  Gift,
  ShoppingCart,
  Sparkles,
  Activity,
  ChevronRight,
  RefreshCw,
  Minus,
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export type HomeTabTarget =
  | "tasks"
  | "campaigns"
  | "affiliate"
  | "wallet"
  | "engagement";

type PeriodDays = 7 | 30 | 90;

interface Tx {
  id?: string;
  amount: number;
  type?: string;
  description?: string;
  created_at: string;
  status?: string;
}

interface HomeDashboardProps {
  userName?: string | null;
  isSubscriber: boolean;
  balance: number;
  reservedBalance: number;
  transactions: Tx[];
  campaigns: any[];
  affiliate: any | null;
  formatCurrency: (amountKz: number) => string;
  onNavigate: (tab: HomeTabTarget) => void;
  onOpenSubscribe?: () => void;
  onOpenDeposit?: () => void;
  /** Timestamp da última sincronização de dados (ms) */
  dataUpdatedAt?: number | null;
  /** Mostra skeletons (ex.: refresh em curso) */
  isRefreshing?: boolean;
  onRefresh?: () => void;
}

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

function dayKey(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function shortLabel(d: Date, days: PeriodDays) {
  if (days >= 90) {
    return d.toLocaleDateString("pt-PT", { day: "2-digit", month: "numeric" });
  }
  return d.toLocaleDateString("pt-PT", { day: "2-digit", month: "short" });
}

function sumInPeriod(transactions: Tx[], from: Date, to: Date) {
  let entradas = 0;
  let saidas = 0;
  const fromT = from.getTime();
  const toT = to.getTime();
  for (const tx of transactions || []) {
    const t = new Date(tx.created_at).getTime();
    if (t < fromT || t > toT) continue;
    const amt = Number(tx.amount) || 0;
    if (amt >= 0) entradas += amt;
    else saidas += Math.abs(amt);
  }
  return { entradas, saidas, liquido: entradas - saidas };
}

function pctChange(current: number, previous: number): number | null {
  if (previous === 0) {
    if (current === 0) return 0;
    return null; // sem base comparável
  }
  return ((current - previous) / Math.abs(previous)) * 100;
}

function formatUpdatedAt(ts?: number | null) {
  if (!ts) return "—";
  const d = new Date(ts);
  return d.toLocaleString("pt-PT", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function DeltaBadge({ value }: { value: number | null }) {
  if (value === null) {
    return (
      <span className="inline-flex items-center gap-0.5 text-[10px] font-bold text-slate-400">
        <Minus className="w-3 h-3" /> —%
      </span>
    );
  }
  if (value === 0) {
    return (
      <span className="inline-flex items-center gap-0.5 text-[10px] font-bold text-slate-400">
        0%
      </span>
    );
  }
  const up = value > 0;
  return (
    <span
      className={`inline-flex items-center gap-0.5 text-[10px] font-bold ${
        up ? "text-emerald-600" : "text-rose-500"
      }`}
    >
      {up ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
      {up ? "+" : ""}
      {value.toFixed(1)}%
    </span>
  );
}

function HomeSkeleton() {
  return (
    <div className="space-y-5 pb-2 animate-in fade-in duration-300">
      <div className="space-y-2">
        <Skeleton className="h-3 w-16 rounded-md" />
        <Skeleton className="h-7 w-40 rounded-md" />
        <Skeleton className="h-4 w-56 rounded-md" />
      </div>
      <Skeleton className="h-28 w-full rounded-3xl" />
      <div className="grid grid-cols-3 gap-2.5">
        <Skeleton className="h-20 rounded-2xl" />
        <Skeleton className="h-20 rounded-2xl" />
        <Skeleton className="h-20 rounded-2xl" />
      </div>
      <Skeleton className="h-[220px] w-full rounded-3xl" />
      <Skeleton className="h-16 w-full rounded-2xl" />
      <div className="grid grid-cols-2 gap-2.5">
        <Skeleton className="h-28 rounded-2xl" />
        <Skeleton className="h-28 rounded-2xl" />
        <Skeleton className="h-28 rounded-2xl" />
        <Skeleton className="h-28 rounded-2xl" />
      </div>
    </div>
  );
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  userName,
  isSubscriber,
  balance,
  reservedBalance,
  transactions,
  campaigns,
  affiliate,
  formatCurrency,
  onNavigate,
  onOpenSubscribe,
  onOpenDeposit,
  dataUpdatedAt,
  isRefreshing,
  onRefresh,
}) => {
  const [period, setPeriod] = useState<PeriodDays>(30);
  const firstName = (userName || "Operador").split(" ")[0];

  const analytics = useMemo(() => {
    const days = period;
    const today = startOfDay(new Date());
    const periodStart = new Date(today);
    periodStart.setDate(today.getDate() - (days - 1));
    const prevEnd = new Date(periodStart);
    prevEnd.setDate(prevEnd.getDate() - 1);
    const prevStart = new Date(prevEnd);
    prevStart.setDate(prevEnd.getDate() - (days - 1));

    const endOfToday = new Date(today);
    endOfToday.setHours(23, 59, 59, 999);

    const current = sumInPeriod(transactions, periodStart, endOfToday);
    const previous = sumInPeriod(transactions, prevStart, prevEnd);

    const buckets: Record<string, { date: string; label: string; entradas: number; saidas: number }> = {};
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(today.getDate() - i);
      const key = dayKey(d);
      buckets[key] = { date: key, label: shortLabel(d, days), entradas: 0, saidas: 0 };
    }

    for (const tx of transactions || []) {
      const amt = Number(tx.amount) || 0;
      const d = startOfDay(new Date(tx.created_at));
      const key = dayKey(d);
      if (!buckets[key]) continue;
      if (amt >= 0) buckets[key].entradas += amt;
      else buckets[key].saidas += Math.abs(amt);
    }

    // Para 90 dias, agrupar por semana para legibilidade do eixo X
    let chartData = Object.values(buckets);
    if (days === 90) {
      const weekly: { label: string; entradas: number; saidas: number }[] = [];
      for (let i = 0; i < chartData.length; i += 7) {
        const slice = chartData.slice(i, i + 7);
        weekly.push({
          label: slice[0]?.label || "",
          entradas: slice.reduce((s, x) => s + x.entradas, 0),
          saidas: slice.reduce((s, x) => s + x.saidas, 0),
        });
      }
      chartData = weekly as typeof chartData;
    }

    const recent = [...(transactions || [])]
      .sort((a, b) => +new Date(b.created_at) - +new Date(a.created_at))
      .slice(0, 5);

    return {
      chartData,
      totalIn: current.entradas,
      totalOut: current.saidas,
      net: current.liquido,
      inDelta: pctChange(current.entradas, previous.entradas),
      outDelta: pctChange(current.saidas, previous.saidas),
      netDelta: pctChange(current.liquido, previous.liquido),
      recentMoves: recent,
      periodLabel:
        days === 7 ? "7 dias" : days === 30 ? "30 dias" : "90 dias",
    };
  }, [transactions, period]);

  const activeCampaignsList = (campaigns || []).filter(
    (c) =>
      c.assignment_status === "ASSIGNED" ||
      c.assignment_status === "IN_PROGRESS" ||
      c.status === "ACTIVE"
  );
  const activeCampaigns = activeCampaignsList.length;
  const doneCampaigns = (campaigns || []).filter(
    (c) => c.assignment_status === "COMPLETED" || c.status === "COMPLETED"
  ).length;
  const referrals = Number(affiliate?.total_referrals ?? 0);
  const affiliateEarned = Number(affiliate?.total_earned ?? 0);

  const hasChartActivity = analytics.chartData.some(
    (d) => d.entradas > 0 || d.saidas > 0
  );

  // Próxima ação recomendada (uma só, por prioridade)
  const nextAction = useMemo(() => {
    if (!isSubscriber) {
      return {
        title: "Ativar conta completa",
        desc: "Desbloqueie tarefas, campanhas e ganhos de afiliado",
        cta: "Ativar agora",
        onClick: () => onOpenSubscribe?.(),
        icon: Sparkles,
        tone: "dark" as const,
      };
    }
    if (reservedBalance > 0) {
      return {
        title: "Saque em processamento",
        desc: `${formatCurrency(reservedBalance)} reservado — acompanhe na conta`,
        cta: "Ver conta",
        onClick: () => onNavigate("wallet"),
        icon: Wallet,
        tone: "amber" as const,
      };
    }
    if (activeCampaigns > 0) {
      return {
        title:
          activeCampaigns === 1
            ? "1 campanha em curso"
            : `${activeCampaigns} campanhas em curso`,
        desc: "Conclua as ações pendentes para creditar recompensas",
        cta: "Ver ações",
        onClick: () => onNavigate("campaigns"),
        icon: Megaphone,
        tone: "violet" as const,
      };
    }
    if (referrals === 0) {
      return {
        title: "Ainda sem indicações",
        desc: "Partilhe o seu link e comece a ganhar comissões",
        cta: "Programa afiliado",
        onClick: () => onNavigate("affiliate"),
        icon: Gift,
        tone: "amber" as const,
      };
    }
    return {
      title: "Continue a operar",
      desc: "Veja tarefas da comunidade ou peça engajamento na loja",
      cta: "Ver tarefas",
      onClick: () => onNavigate("tasks"),
      icon: Layers,
      tone: "teal" as const,
    };
  }, [
    isSubscriber,
    reservedBalance,
    activeCampaigns,
    referrals,
    formatCurrency,
    onNavigate,
    onOpenSubscribe,
  ]);

  // Skeleton só no primeiro carregamento de dados (não em cada refresh)
  if (isRefreshing && !dataUpdatedAt) {
    return <HomeSkeleton />;
  }

  const NextIcon = nextAction.icon;
  const nextToneClass =
    nextAction.tone === "dark"
      ? "bg-slate-900 text-white"
      : nextAction.tone === "amber"
        ? "bg-amber-50 text-amber-950 border border-amber-100"
        : nextAction.tone === "violet"
          ? "bg-violet-50 text-violet-950 border border-violet-100"
          : "bg-teal-50 text-teal-950 border border-teal-100";

  const nextIconBox =
    nextAction.tone === "dark"
      ? "bg-white/10 text-amber-300"
      : nextAction.tone === "amber"
        ? "bg-amber-100 text-amber-700"
        : nextAction.tone === "violet"
          ? "bg-violet-100 text-violet-700"
          : "bg-teal-100 text-teal-700";

  const nextCtaClass =
    nextAction.tone === "dark"
      ? "text-white/90"
      : "text-slate-700";

  return (
    <div className="space-y-5 tab-enter pb-2">
      {/* Saudação + atualizado */}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[12px] font-semibold text-slate-400 uppercase tracking-wider">
            Resumo
          </p>
          <h2 className="text-[22px] font-extrabold text-slate-900 tracking-tight truncate">
            Olá, {firstName}
          </h2>
          <p className="text-[12px] text-slate-400 mt-1 flex items-center gap-1.5 flex-wrap">
            <span>Atualizado {formatUpdatedAt(dataUpdatedAt)}</span>
            {onRefresh && (
              <button
                type="button"
                onClick={onRefresh}
                disabled={!!isRefreshing}
                className="inline-flex items-center gap-1 text-teal-700 font-semibold hover:underline disabled:opacity-60"
              >
                <RefreshCw className={`w-3 h-3 ${isRefreshing ? "animate-spin" : ""}`} />
                {isRefreshing ? "A atualizar…" : "Atualizar"}
              </button>
            )}
          </p>
        </div>
        <span
          className={`shrink-0 text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full ${
            isSubscriber
              ? "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"
              : "bg-amber-50 text-amber-700 ring-1 ring-amber-100"
          }`}
        >
          {isSubscriber ? "Assinante" : "Visitante"}
        </span>
      </div>

      {/* Saldo */}
      <div className="rounded-3xl gradient-adx text-white p-5 shadow-lg shadow-teal-900/15">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2 text-white/80">
            <Wallet className="w-4 h-4" />
            <span className="text-[12px] font-semibold">Saldo disponível</span>
          </div>
          <button
            type="button"
            onClick={() => onNavigate("wallet")}
            className="text-[11px] font-bold text-white/90 underline-offset-2 hover:underline"
          >
            Ver conta
          </button>
        </div>
        <p className="text-[28px] font-black tracking-tight tabular-nums leading-none">
          {formatCurrency(balance)}
        </p>
        {reservedBalance > 0 && (
          <p className="text-[11px] text-white/70 mt-2">
            Reservado em saques: {formatCurrency(reservedBalance)}
          </p>
        )}
        <button
          type="button"
          onClick={() => onOpenDeposit?.()}
          className="mt-3 w-full h-10 rounded-xl bg-white/15 hover:bg-white/25 text-[12px] font-bold text-white border border-white/20"
        >
          Carregar conta
        </button>
      </div>

      {/* Próxima ação */}
      <button
        type="button"
        onClick={nextAction.onClick}
        className={`w-full rounded-2xl p-4 flex items-center gap-3 pressable text-left ${nextToneClass}`}
      >
        <div
          className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${nextIconBox}`}
        >
          <NextIcon className="w-5 h-5" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-[13px] font-bold leading-tight">{nextAction.title}</p>
          <p
            className={`text-[11px] mt-0.5 leading-snug ${
              nextAction.tone === "dark" ? "text-white/65" : "text-slate-500"
            }`}
          >
            {nextAction.desc}
          </p>
        </div>
        <span className={`text-[11px] font-bold shrink-0 flex items-center gap-0.5 ${nextCtaClass}`}>
          {nextAction.cta}
          <ChevronRight className="w-3.5 h-3.5" />
        </span>
      </button>

      {/* Entradas / Saídas / Líquido + deltas */}
      <div className="grid grid-cols-3 gap-2.5">
        <div className="rounded-2xl bg-white border border-slate-100 p-3 shadow-sm">
          <div className="flex items-center gap-1.5 text-emerald-600 mb-1">
            <ArrowDownLeft className="w-3.5 h-3.5" />
            <span className="text-[10px] font-bold uppercase tracking-wide">Entradas</span>
          </div>
          <p className="text-[13px] font-extrabold text-slate-900 tabular-nums leading-tight">
            {formatCurrency(analytics.totalIn)}
          </p>
          <div className="mt-1 flex items-center gap-1">
            <DeltaBadge value={analytics.inDelta} />
            <span className="text-[9px] text-slate-400">vs ant.</span>
          </div>
        </div>
        <div className="rounded-2xl bg-white border border-slate-100 p-3 shadow-sm">
          <div className="flex items-center gap-1.5 text-rose-500 mb-1">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span className="text-[10px] font-bold uppercase tracking-wide">Saídas</span>
          </div>
          <p className="text-[13px] font-extrabold text-slate-900 tabular-nums leading-tight">
            {formatCurrency(analytics.totalOut)}
          </p>
          <div className="mt-1 flex items-center gap-1">
            <DeltaBadge value={analytics.outDelta} />
            <span className="text-[9px] text-slate-400">vs ant.</span>
          </div>
        </div>
        <div className="rounded-2xl bg-white border border-slate-100 p-3 shadow-sm">
          <div className="flex items-center gap-1.5 text-teal-700 mb-1">
            {analytics.net >= 0 ? (
              <TrendingUp className="w-3.5 h-3.5" />
            ) : (
              <TrendingDown className="w-3.5 h-3.5" />
            )}
            <span className="text-[10px] font-bold uppercase tracking-wide">Líquido</span>
          </div>
          <p
            className={`text-[13px] font-extrabold tabular-nums leading-tight ${
              analytics.net >= 0 ? "text-emerald-700" : "text-rose-600"
            }`}
          >
            {formatCurrency(analytics.net)}
          </p>
          <div className="mt-1 flex items-center gap-1">
            <DeltaBadge value={analytics.netDelta} />
            <span className="text-[9px] text-slate-400">vs ant.</span>
          </div>
        </div>
      </div>

      {/* Gráfico + período */}
      <div className="rounded-3xl bg-white border border-slate-100 p-4 shadow-sm">
        <div className="flex items-center justify-between gap-2 mb-3 flex-wrap">
          <div>
            <p className="text-[13px] font-extrabold text-slate-900">Tendência de fluxo</p>
            <p className="text-[11px] text-slate-400 font-medium">
              Últimos {analytics.periodLabel} · dados reais
            </p>
          </div>
          <div className="flex bg-slate-100 p-0.5 rounded-xl">
            {([7, 30, 90] as PeriodDays[]).map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => setPeriod(d)}
                className={`px-2.5 py-1 text-[11px] font-bold rounded-lg transition-colors ${
                  period === d
                    ? "bg-white text-slate-900 shadow-sm"
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                {d}d
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-3 text-[10px] font-semibold mb-2">
          <span className="flex items-center gap-1 text-emerald-600">
            <span className="w-2 h-2 rounded-full bg-emerald-500" /> Entradas
          </span>
          <span className="flex items-center gap-1 text-rose-500">
            <span className="w-2 h-2 rounded-full bg-rose-400" /> Saídas
          </span>
        </div>

        <div className="h-[180px] w-full">
          {hasChartActivity ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={analytics.chartData} margin={{ top: 8, right: 4, left: -18, bottom: 0 }}>
                <defs>
                  <linearGradient id="gradIn" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#10b981" stopOpacity={0.02} />
                  </linearGradient>
                  <linearGradient id="gradOut" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#f43f5e" stopOpacity={0.28} />
                    <stop offset="100%" stopColor="#f43f5e" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 10, fill: "#94a3b8" }}
                  axisLine={false}
                  tickLine={false}
                  interval="preserveStartEnd"
                />
                <YAxis
                  tick={{ fontSize: 10, fill: "#94a3b8" }}
                  axisLine={false}
                  tickLine={false}
                  width={42}
                />
                <Tooltip
                  contentStyle={{
                    borderRadius: 12,
                    border: "1px solid #e2e8f0",
                    fontSize: 12,
                    boxShadow: "0 8px 24px rgba(15,23,42,0.08)",
                  }}
                  formatter={(value: number, name: string) => [
                    formatCurrency(Number(value) || 0),
                    name === "entradas" ? "Entradas" : "Saídas",
                  ]}
                />
                <Area
                  type="monotone"
                  dataKey="entradas"
                  stroke="#059669"
                  strokeWidth={2}
                  fill="url(#gradIn)"
                  animationDuration={500}
                />
                <Area
                  type="monotone"
                  dataKey="saidas"
                  stroke="#e11d48"
                  strokeWidth={2}
                  fill="url(#gradOut)"
                  animationDuration={500}
                />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center px-4">
              <Activity className="w-8 h-8 text-slate-300 mb-2" />
              <p className="text-[13px] font-bold text-slate-600">
                Sem movimentos nos últimos {analytics.periodLabel}
              </p>
              <p className="text-[11px] text-slate-400 mt-1 max-w-[240px]">
                Quando houver entradas e saídas na carteira, a tendência aparece aqui.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Resumo de trabalho */}
      <div>
        <p className="text-[13px] font-extrabold text-slate-900 mb-2.5">Resumo de trabalho</p>
        <div className="grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={() => onNavigate("campaigns")}
            className="rounded-2xl bg-white border border-slate-100 p-3.5 text-left shadow-sm pressable"
          >
            <div className="w-9 h-9 rounded-xl bg-violet-50 text-violet-600 flex items-center justify-center mb-2">
              <Megaphone className="w-4 h-4" />
            </div>
            <p className="text-[11px] font-semibold text-slate-400">Campanhas ativas</p>
            <p className="text-[18px] font-black text-slate-900 tabular-nums">{activeCampaigns}</p>
            <p className="text-[10px] text-slate-400 mt-0.5">{doneCampaigns} concluídas</p>
          </button>

          <button
            type="button"
            onClick={() => onNavigate("tasks")}
            className="rounded-2xl bg-white border border-slate-100 p-3.5 text-left shadow-sm pressable"
          >
            <div className="w-9 h-9 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center mb-2">
              <Layers className="w-4 h-4" />
            </div>
            <p className="text-[11px] font-semibold text-slate-400">Tarefas</p>
            <p className="text-[18px] font-black text-slate-900 tabular-nums">
              {isSubscriber ? "Abertas" : "—"}
            </p>
            <p className="text-[10px] text-slate-400 mt-0.5">
              {isSubscriber ? "Ver comunidade" : "Requer assinatura"}
            </p>
          </button>

          <button
            type="button"
            onClick={() => onNavigate("affiliate")}
            className="rounded-2xl bg-white border border-slate-100 p-3.5 text-left shadow-sm pressable"
          >
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-2">
              <Gift className="w-4 h-4" />
            </div>
            <p className="text-[11px] font-semibold text-slate-400">Indicações</p>
            <p className="text-[18px] font-black text-slate-900 tabular-nums">{referrals}</p>
            <p className="text-[10px] text-slate-400 mt-0.5">
              {affiliateEarned > 0 ? formatCurrency(affiliateEarned) + " ganhos" : "Programa afiliado"}
            </p>
          </button>

          <button
            type="button"
            onClick={() => onNavigate("engagement")}
            className="rounded-2xl bg-white border border-slate-100 p-3.5 text-left shadow-sm pressable"
          >
            <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center mb-2">
              <ShoppingCart className="w-4 h-4" />
            </div>
            <p className="text-[11px] font-semibold text-slate-400">Loja</p>
            <p className="text-[18px] font-black text-slate-900">Engajamento</p>
            <p className="text-[10px] text-slate-400 mt-0.5">Seguidores, gostos, views</p>
          </button>
        </div>
      </div>

      {/* Movimentos recentes */}
      <div className="rounded-3xl bg-white border border-slate-100 shadow-sm overflow-hidden">
        <div className="flex items-center justify-between px-4 pt-4 pb-2">
          <p className="text-[13px] font-extrabold text-slate-900">Movimentos recentes</p>
          <button
            type="button"
            onClick={() => onNavigate("wallet")}
            className="text-[11px] font-bold text-teal-700"
          >
            Ver todos
          </button>
        </div>
        {analytics.recentMoves.length === 0 ? (
          <p className="px-4 pb-4 text-[12px] text-slate-400">Ainda não há movimentos na carteira.</p>
        ) : (
          <ul className="divide-y divide-slate-50">
            {analytics.recentMoves.map((tx, i) => {
              const amt = Number(tx.amount) || 0;
              const positive = amt >= 0;
              return (
                <li key={tx.id || i} className="flex items-center gap-3 px-4 py-3">
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                      positive ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-500"
                    }`}
                  >
                    {positive ? (
                      <ArrowDownLeft className="w-3.5 h-3.5" />
                    ) : (
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[12px] font-semibold text-slate-800 truncate">
                      {tx.description || tx.type || "Movimento"}
                    </p>
                    <p className="text-[10px] text-slate-400">
                      {new Date(tx.created_at).toLocaleString("pt-PT", {
                        day: "2-digit",
                        month: "short",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                  <p
                    className={`text-[12px] font-extrabold tabular-nums shrink-0 ${
                      positive ? "text-emerald-600" : "text-rose-600"
                    }`}
                  >
                    {positive ? "+" : ""}
                    {formatCurrency(amt)}
                  </p>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
};

export default HomeDashboard;
