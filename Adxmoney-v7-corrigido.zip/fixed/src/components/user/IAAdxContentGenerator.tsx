import React, { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Copy, Loader2, Sparkles } from "lucide-react";

type Platform = "TikTok" | "Instagram" | "YouTube";
type Objective = "followers" | "engagement" | "affiliate" | "campaign";
type Lang = "pt" | "en" | "fr";

interface Props {
  open: boolean;
  onClose: () => void;
  defaultPlatform?: Platform;
  defaultObjective?: Objective;
}

const LABELS: Record<
  Lang,
  {
    title: string;
    desc: string;
    platform: string;
    objective: string;
    context: string;
    contextPh: string;
    generate: string;
    generating: string;
    caption: string;
    hashtags: string;
    idea: string;
    copyAll: string;
    copied: string;
    objectives: Record<Objective, string>;
  }
> = {
  pt: {
    title: "IA ADX — Gerador de conteúdo",
    desc: "Legenda, hashtags e ideia de vídeo",
    platform: "Plataforma",
    objective: "Objetivo",
    context: "Contexto (opcional)",
    contextPh: "Ex.: loja de roupa, link da campanha…",
    generate: "Gerar",
    generating: "A gerar…",
    caption: "Legenda",
    hashtags: "Hashtags",
    idea: "Ideia de vídeo",
    copyAll: "Copiar tudo",
    copied: "Copiado",
    objectives: {
      followers: "Seguidores",
      engagement: "Engajamento",
      affiliate: "Afiliado / convite",
      campaign: "Campanha / produto",
    },
  },
  en: {
    title: "IA ADX — Content generator",
    desc: "Caption, hashtags and video idea",
    platform: "Platform",
    objective: "Goal",
    context: "Context (optional)",
    contextPh: "E.g. clothing store, campaign link…",
    generate: "Generate",
    generating: "Generating…",
    caption: "Caption",
    hashtags: "Hashtags",
    idea: "Video idea",
    copyAll: "Copy all",
    copied: "Copied",
    objectives: {
      followers: "Followers",
      engagement: "Engagement",
      affiliate: "Affiliate / invite",
      campaign: "Campaign / product",
    },
  },
  fr: {
    title: "IA ADX — Générateur de contenu",
    desc: "Légende, hashtags et idée vidéo",
    platform: "Plateforme",
    objective: "Objectif",
    context: "Contexte (optionnel)",
    contextPh: "Ex. boutique, lien de campagne…",
    generate: "Générer",
    generating: "Génération…",
    caption: "Légende",
    hashtags: "Hashtags",
    idea: "Idée vidéo",
    copyAll: "Tout copier",
    copied: "Copié",
    objectives: {
      followers: "Abonnés",
      engagement: "Engagement",
      affiliate: "Affiliation / invitation",
      campaign: "Campagne / produit",
    },
  },
};

export const IAAdxContentGenerator: React.FC<Props> = ({
  open,
  onClose,
  defaultPlatform = "TikTok",
  defaultObjective = "engagement",
}) => {
  const { profile } = useAuth();
  const lang = ((profile as any)?.preferred_language as Lang) || "pt";
  const t = LABELS[lang] || LABELS.pt;

  const [platform, setPlatform] = useState<Platform>(defaultPlatform);
  const [objective, setObjective] = useState<Objective>(defaultObjective);
  const [context, setContext] = useState("");
  const [loading, setLoading] = useState(false);
  const [caption, setCaption] = useState("");
  const [hashtags, setHashtags] = useState<string[]>([]);
  const [videoIdea, setVideoIdea] = useState("");

  React.useEffect(() => {
    if (open) {
      setPlatform(defaultPlatform);
      setObjective(defaultObjective);
    }
  }, [open, defaultPlatform, defaultObjective]);

  const handleGenerate = async () => {
    setLoading(true);
    setCaption("");
    setHashtags([]);
    setVideoIdea("");
    try {
      const { data, error } = await supabase.functions.invoke("ai-generate-content", {
        body: {
          platform,
          objective,
          language: lang,
          context: context.trim(),
          referral_code: profile?.referral_code || "",
        },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      setCaption(data.caption || "");
      setHashtags(Array.isArray(data.hashtags) ? data.hashtags : []);
      setVideoIdea(data.video_idea || "");
    } catch (err: any) {
      console.error(err);
      toast.error(err.message || "Erro ao gerar conteúdo");
    } finally {
      setLoading(false);
    }
  };

  const copyAll = async () => {
    const tags = hashtags.map((h) => (h.startsWith("#") ? h : `#${h}`)).join(" ");
    const text = [caption, tags, videoIdea].filter(Boolean).join("\n\n");
    await navigator.clipboard.writeText(text);
    toast.success(t.copied);
  };

  const copyField = async (text: string) => {
    await navigator.clipboard.writeText(text);
    toast.success(t.copied);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="bg-white rounded-2xl border border-slate-200 max-w-md p-5 max-h-[90vh] overflow-y-auto">
        <DialogHeader className="text-left space-y-1">
          <DialogTitle className="text-[17px] font-semibold text-slate-900 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#0f766e]" />
            {t.title}
          </DialogTitle>
          <DialogDescription className="text-[13px] text-slate-500">
            {t.desc}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3.5 pt-2">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-[12px] text-slate-600">{t.platform}</Label>
              <Select value={platform} onValueChange={(v) => setPlatform(v as Platform)}>
                <SelectTrigger className="h-10 rounded-xl text-[13px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="TikTok">TikTok</SelectItem>
                  <SelectItem value="Instagram">Instagram</SelectItem>
                  <SelectItem value="YouTube">YouTube</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-[12px] text-slate-600">{t.objective}</Label>
              <Select value={objective} onValueChange={(v) => setObjective(v as Objective)}>
                <SelectTrigger className="h-10 rounded-xl text-[13px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {(Object.keys(t.objectives) as Objective[]).map((k) => (
                    <SelectItem key={k} value={k}>
                      {t.objectives[k]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label className="text-[12px] text-slate-600">{t.context}</Label>
            <Textarea
              value={context}
              onChange={(e) => setContext(e.target.value)}
              placeholder={t.contextPh}
              className="min-h-[72px] rounded-xl text-[13px] resize-none"
            />
          </div>

          <Button
            onClick={handleGenerate}
            disabled={loading}
            className="w-full h-11 rounded-xl bg-[#0f766e] hover:bg-[#0d9488] text-white text-[14px] font-medium"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
                {t.generating}
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                {t.generate}
              </>
            )}
          </Button>

          {(caption || videoIdea || hashtags.length > 0) && (
            <div className="space-y-3 pt-1 border-t border-slate-100">
              {caption && (
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[12px] font-medium text-slate-600">{t.caption}</span>
                    <button
                      type="button"
                      onClick={() => copyField(caption)}
                      className="text-slate-400 hover:text-slate-600 p-1"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p className="text-[13px] text-slate-800 bg-slate-50 rounded-xl p-3 leading-relaxed whitespace-pre-wrap">
                    {caption}
                  </p>
                </div>
              )}
              {hashtags.length > 0 && (
                <div className="space-y-1">
                  <span className="text-[12px] font-medium text-slate-600">{t.hashtags}</span>
                  <p className="text-[13px] text-slate-700">
                    {hashtags.map((h) => (h.startsWith("#") ? h : `#${h}`)).join(" ")}
                  </p>
                </div>
              )}
              {videoIdea && (
                <div className="space-y-1">
                  <span className="text-[12px] font-medium text-slate-600">{t.idea}</span>
                  <p className="text-[13px] text-slate-700 bg-slate-50 rounded-xl p-3 leading-relaxed">
                    {videoIdea}
                  </p>
                </div>
              )}
              <Button
                variant="outline"
                onClick={copyAll}
                className="w-full h-10 rounded-xl border-slate-200 text-[13px] font-medium"
              >
                <Copy className="w-3.5 h-3.5 mr-1.5" />
                {t.copyAll}
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default IAAdxContentGenerator;
