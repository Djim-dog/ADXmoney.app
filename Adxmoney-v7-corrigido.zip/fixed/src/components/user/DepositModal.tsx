import { checkProofFile, proofPath } from "@/lib/upload";
import React, { useState, useRef, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Loader2,
  Upload,
  Copy,
  ArrowLeft,
  ArrowRight,
  X,
  Image as ImageIcon,
  Wallet,
} from "lucide-react";
import { toast } from "sonner";

interface DepositModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  currency: "USD" | "AOA" | "EUR" | "BRL";
  exchangeRates: { AOA: number; USD: number; EUR: number; BRL: number };
  onSuccess?: () => void;
  defaultPayerName?: string;
}

type WalletMethod = "unitel" | "express" | "remitly";
type Step = 1 | 2 | 3;

const WALLETS: {
  id: WalletMethod;
  label: string;
  description: string;
  icon: string;
}[] = [
  {
    id: "unitel",
    label: "Unitel Money",
    description: "Transferência via carteira Unitel Money",
    icon: "/icons/unitel.jpg",
  },
  {
    id: "express",
    label: "Multicaixa Express",
    description: "Pagamento via Multicaixa Express",
    icon: "/icons/express.jpg",
  },
  {
    id: "remitly",
    label: "Remitly",
    description: "Transferência internacional (Remitly)",
    icon: "/icons/remitly.jpg",
  },
];

const PAYMENT_NUMBER = "933 271 690";
const PRESETS_KZ = [5000, 10000, 25000, 50000];
const MIN_KZ = 1000;
const MAX_KZ = 5_000_000;

const ACCEPTED_TYPES = [
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/webp",
  "application/pdf",
];
const MAX_FILE_MB = 5;

export const DepositModal: React.FC<DepositModalProps> = ({
  isOpen,
  onClose,
  userId,
  currency,
  exchangeRates,
  onSuccess,
  defaultPayerName = "",
}) => {
  const [step, setStep] = useState<Step>(1);
  const [selectedMethod, setSelectedMethod] = useState<WalletMethod | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [amountKz, setAmountKz] = useState(10000);
  const [customAmount, setCustomAmount] = useState("");
  const [payerName, setPayerName] = useState(defaultPayerName);
  const [transactionId, setTransactionId] = useState("");
  const [remitlyCountry, setRemitlyCountry] = useState<"Angola" | "Portugal">("Angola");
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen && defaultPayerName) setPayerName(defaultPayerName);
  }, [isOpen, defaultPayerName]);

  const displayAmount = () => {
    const usd = amountKz / 950;
    const converted = usd * exchangeRates[currency];
    const symbols = { AOA: "Kz", USD: "$", EUR: "€", BRL: "R$" };
    const fmt = new Intl.NumberFormat("pt-PT", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    if (currency === "AOA") return `${fmt.format(amountKz)} Kz`;
    return `${symbols[currency]} ${fmt.format(converted)}`;
  };

  const clearProof = () => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setProofFile(null);
    setPreviewUrl(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const resetForm = () => {
    setStep(1);
    setSelectedMethod(null);
    setAmountKz(10000);
    setCustomAmount("");
    setPayerName(defaultPayerName || "");
    setTransactionId("");
    setRemitlyCountry("Angola");
    clearProof();
  };

  const handleClose = () => {
    if (!submitting) {
      resetForm();
      onClose();
    }
  };

  const copyText = (text: string, label: string) => {
    navigator.clipboard.writeText(text.replace(/\s/g, "")).then(
      () => toast.success(`${label} copiado`),
      () => toast.error("Não foi possível copiar")
    );
  };

  const applyCustomAmount = () => {
    const n = Number(String(customAmount).replace(/[^\d.]/g, ""));
    if (!n || n < MIN_KZ) {
      toast.error(`Mínimo ${MIN_KZ.toLocaleString("pt-PT")} Kz`);
      return;
    }
    if (n > MAX_KZ) {
      toast.error(`Máximo ${MAX_KZ.toLocaleString("pt-PT")} Kz`);
      return;
    }
    setAmountKz(Math.round(n));
    toast.success("Valor atualizado");
  };

  const handleFile = (file: File | null) => {
    if (!file) return;
    if (!ACCEPTED_TYPES.includes(file.type)) {
      toast.error("Formato inválido. Use JPG, PNG, WEBP ou PDF.");
      return;
    }
    if (file.size > MAX_FILE_MB * 1024 * 1024) {
      toast.error(`Ficheiro demasiado grande (máx. ${MAX_FILE_MB} MB).`);
      return;
    }
    clearProof();
    setProofFile(file);
    if (file.type.startsWith("image/")) {
      setPreviewUrl(URL.createObjectURL(file));
    }
  };

  const goStep2 = () => {
    if (!selectedMethod) {
      toast.error("Selecione o método de pagamento.");
      return;
    }
    if (amountKz < MIN_KZ) {
      toast.error(`Valor mínimo: ${MIN_KZ.toLocaleString("pt-PT")} Kz`);
      return;
    }
    setStep(2);
  };

  const goStep3 = () => {
    if (!payerName.trim()) {
      toast.error("Indique o nome do titular do pagamento.");
      return;
    }
    if (!transactionId.trim()) {
      toast.error("Indique o ID / referência da transferência.");
      return;
    }
    setStep(3);
  };

  const submitDeposit = async () => {
    if (!proofFile) {
      toast.error("Anexe o comprovativo de pagamento.");
      return;
    }
    if (!selectedMethod) return;

    setSubmitting(true);
    try {
      const check = checkProofFile(proofFile);
      if (!check.ok) throw new Error(check.error);
      const filePath = proofPath(`deposits/${userId}`, check.ext!);

      const { error: uploadError } = await supabase.storage
        .from("subscription-proofs")
        .upload(filePath, proofFile, { upsert: false, contentType: proofFile.type });

      if (uploadError) {
        throw new Error(`Falha no upload do comprovativo: ${uploadError.message}`);
      }

      const cleanMethod =
        selectedMethod === "express"
          ? "EXPRESS"
          : selectedMethod === "unitel"
            ? "UNITEL"
            : "REMITLY";
      const city = remitlyCountry === "Portugal" ? "Lisboa" : "Luanda";
      const methodDetails =
        selectedMethod === "remitly"
          ? `${cleanMethod} | Beneficiario: Adxmoney | Pais: ${remitlyCountry} | Local: ${city} | Titular: ${payerName.trim()} | ID: ${transactionId.trim().slice(0, 64)} | DEPOSITO`
          : `${cleanMethod} | Titular: ${payerName.trim()} | ID: ${transactionId.trim().slice(0, 64)} | Nr: ${PAYMENT_NUMBER} | DEPOSITO`;

      const { data, error: rpcError } = await supabase.rpc("submit_wallet_deposit", {
        p_amount: amountKz,
        p_currency: "AOA",
        p_method: methodDetails,
        p_proof_url: filePath,
      });

      if (rpcError) throw rpcError;

      const result = data as { success?: boolean } | null;
      if (result && result.success === false) {
        throw new Error("Não foi possível registar o depósito.");
      }

      toast.success(
        "Pedido de carregamento enviado. Após validação do admin, o saldo será creditado."
      );
      resetForm();
      onClose();
      onSuccess?.();
    } catch (err: any) {
      console.error("Erro depósito:", err);
      toast.error(err.message || "Erro ao processar depósito.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(o) => !o && handleClose()}>
      <DialogContent className="max-w-md max-h-[92vh] overflow-y-auto rounded-3xl p-0 gap-0">
        <div className="px-5 pt-5 pb-3 border-b border-slate-100">
          <DialogHeader>
            <DialogTitle className="text-[17px] font-extrabold flex items-center gap-2">
              <Wallet className="w-5 h-5 text-teal-700" />
              Carregar conta
            </DialogTitle>
            <DialogDescription className="text-[12px] text-slate-500">
              Transfira e envie o comprovativo. O saldo é creditado após aprovação.
            </DialogDescription>
          </DialogHeader>

          {/* Progress */}
          <div className="flex items-center justify-between gap-1 mt-4 mb-1">
            {[
              { n: 1, label: "Valor" },
              { n: 2, label: "Transferência" },
              { n: 3, label: "Comprovativo" },
            ].map((s, i) => (
              <React.Fragment key={s.n}>
                <div className="flex flex-col items-center gap-1 min-w-0 flex-1">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-bold border-2 transition-colors ${
                      step >= s.n
                        ? "bg-teal-600 border-teal-600 text-white"
                        : "bg-white border-slate-200 text-slate-400"
                    }`}
                  >
                    {s.n}
                  </div>
                  <span
                    className={`text-[10px] font-semibold ${
                      step >= s.n ? "text-teal-700" : "text-slate-400"
                    }`}
                  >
                    {s.label}
                  </span>
                </div>
                {i < 2 && (
                  <div
                    className={`h-0.5 flex-1 rounded-full mb-4 ${
                      step > s.n ? "bg-teal-500" : "bg-slate-200"
                    }`}
                  />
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        <div className="px-5 py-4 space-y-4">
          {/* STEP 1 */}
          {step === 1 && (
            <>
              <div>
                <p className="text-[12px] font-bold text-slate-700 mb-2">Valor a carregar</p>
                <div className="grid grid-cols-2 gap-2">
                  {PRESETS_KZ.map((v) => (
                    <button
                      key={v}
                      type="button"
                      onClick={() => {
                        setAmountKz(v);
                        setCustomAmount("");
                      }}
                      className={`h-11 rounded-xl text-[13px] font-bold border transition-colors ${
                        amountKz === v && !customAmount
                          ? "bg-teal-600 text-white border-teal-600"
                          : "bg-white text-slate-700 border-slate-200 hover:border-teal-300"
                      }`}
                    >
                      {v.toLocaleString("pt-PT")} Kz
                    </button>
                  ))}
                </div>
                <div className="flex gap-2 mt-2">
                  <Input
                    value={customAmount}
                    onChange={(e) => setCustomAmount(e.target.value)}
                    placeholder="Outro valor (Kz)"
                    className="h-11 rounded-xl text-[13px]"
                    inputMode="numeric"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    className="h-11 rounded-xl shrink-0"
                    onClick={applyCustomAmount}
                  >
                    Aplicar
                  </Button>
                </div>
                <p className="text-[12px] text-slate-500 mt-2">
                  A transferir: <span className="font-bold text-slate-800">{displayAmount()}</span>
                  <span className="text-slate-400"> · mín. {MIN_KZ.toLocaleString("pt-PT")} Kz</span>
                </p>
              </div>

              <div>
                <p className="text-[12px] font-bold text-slate-700 mb-2">Método de pagamento</p>
                <div className="space-y-2">
                  {WALLETS.map((w) => (
                    <button
                      key={w.id}
                      type="button"
                      onClick={() => setSelectedMethod(w.id)}
                      className={`w-full flex items-center gap-3 p-3 rounded-2xl border text-left transition-colors ${
                        selectedMethod === w.id
                          ? "border-teal-500 bg-teal-50 ring-1 ring-teal-200"
                          : "border-slate-200 bg-white hover:border-slate-300"
                      }`}
                    >
                      <img
                        src={w.icon}
                        alt=""
                        className="w-10 h-10 rounded-xl object-cover bg-slate-100"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="text-[13px] font-bold text-slate-900">{w.label}</p>
                        <p className="text-[11px] text-slate-500">{w.description}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <Button
                onClick={goStep2}
                className="w-full h-12 rounded-xl bg-teal-600 hover:bg-teal-700 font-bold"
              >
                Continuar <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </>
          )}

          {/* STEP 2 */}
          {step === 2 && (
            <>
              <div className="rounded-2xl bg-slate-50 border border-slate-100 p-3.5 space-y-2">
                <div className="flex justify-between text-[12px]">
                  <span className="text-slate-500">Valor</span>
                  <span className="font-bold text-slate-900">{amountKz.toLocaleString("pt-PT")} Kz</span>
                </div>
                <div className="flex justify-between text-[12px] items-center gap-2">
                  <span className="text-slate-500">Número</span>
                  <button
                    type="button"
                    onClick={() => copyText(PAYMENT_NUMBER, "Número")}
                    className="font-bold text-teal-700 inline-flex items-center gap-1"
                  >
                    {PAYMENT_NUMBER} <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
                <p className="text-[11px] text-slate-400">
                  Transfira o valor exacto e guarde o comprovativo.
                </p>
              </div>

              {selectedMethod === "remitly" && (
                <div className="space-y-2">
                  <Label className="text-[12px] font-medium">País (Remitly)</Label>
                  <div className="flex gap-2">
                    {(["Angola", "Portugal"] as const).map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setRemitlyCountry(c)}
                        className={`flex-1 h-10 rounded-xl text-[12px] font-bold border ${
                          remitlyCountry === c
                            ? "bg-teal-600 text-white border-teal-600"
                            : "bg-white border-slate-200 text-slate-700"
                        }`}
                      >
                        {c}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="space-y-1.5">
                <Label className="text-[12px] font-medium text-slate-700">
                  Nome do titular do pagamento *
                </Label>
                <Input
                  value={payerName}
                  onChange={(e) => setPayerName(e.target.value.slice(0, 120))}
                  placeholder="Nome completo de quem pagou"
                  className="h-11 rounded-xl text-[13px]"
                  maxLength={120}
                  readOnly={!!defaultPayerName}
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-[12px] font-medium text-slate-700">
                  ID / referência da transferência *
                </Label>
                <Input
                  value={transactionId}
                  onChange={(e) => setTransactionId(e.target.value.slice(0, 64))}
                  placeholder="Ex.: nº da operação"
                  className="h-11 rounded-xl text-[13px]"
                  maxLength={64}
                />
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setStep(1)}
                  className="h-11 rounded-xl flex-1"
                >
                  <ArrowLeft className="w-4 h-4 mr-1" /> Voltar
                </Button>
                <Button
                  onClick={goStep3}
                  className="h-11 rounded-xl flex-1 bg-teal-600 hover:bg-teal-700 font-bold"
                >
                  Continuar <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            </>
          )}

          {/* STEP 3 */}
          {step === 3 && (
            <>
              <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-4">
                {!proofFile ? (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full flex flex-col items-center gap-2 py-4"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-white border border-slate-200 flex items-center justify-center">
                      <Upload className="w-5 h-5 text-teal-700" />
                    </div>
                    <p className="text-[13px] font-bold text-slate-800">Anexar comprovativo</p>
                    <p className="text-[11px] text-slate-400">JPG, PNG, WEBP ou PDF · máx. {MAX_FILE_MB} MB</p>
                  </button>
                ) : (
                  <div className="flex items-center gap-3">
                    {previewUrl ? (
                      <img src={previewUrl} alt="" className="w-14 h-14 rounded-xl object-cover" />
                    ) : (
                      <div className="w-14 h-14 rounded-xl bg-white border flex items-center justify-center">
                        <ImageIcon className="w-5 h-5 text-slate-400" />
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="text-[12px] font-semibold text-slate-800 truncate">
                        {proofFile.name}
                      </p>
                      <p className="text-[10px] text-slate-400">
                        {(proofFile.size / 1024).toFixed(0)} KB
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={clearProof}
                      className="w-8 h-8 rounded-lg bg-white border flex items-center justify-center text-slate-500"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept={ACCEPTED_TYPES.join(",")}
                  className="hidden"
                  onChange={(e) => handleFile(e.target.files?.[0] || null)}
                />
              </div>

              <p className="text-[11px] text-slate-400 text-center leading-relaxed">
                O valor só entra na carteira depois da equipa validar o comprovativo.
              </p>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setStep(2)}
                  disabled={submitting}
                  className="h-11 rounded-xl flex-1"
                >
                  <ArrowLeft className="w-4 h-4 mr-1" /> Voltar
                </Button>
                <Button
                  onClick={submitDeposit}
                  disabled={submitting || !proofFile}
                  className="h-11 rounded-xl flex-1 bg-teal-600 hover:bg-teal-700 font-bold"
                >
                  {submitting ? (
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  ) : null}
                  Enviar pedido
                </Button>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default DepositModal;
