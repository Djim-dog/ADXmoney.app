import React, { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";

const INTRO_SEEN_KEY = "adx_intro_seen";

/** Marca a intro como vista nesta sessão do browser/PWA (sessionStorage). */
export function markIntroSeen() {
  try {
    sessionStorage.setItem(INTRO_SEEN_KEY, "1");
  } catch {
    /* ignore */
  }
}

/** true se a intro já foi vista nesta sessão (ex.: logout no mesmo tab). */
export function wasIntroSeenThisSession(): boolean {
  try {
    return sessionStorage.getItem(INTRO_SEEN_KEY) === "1";
  } catch {
    return false;
  }
}

interface IntroPresentationProps {
  onFinished: () => void;
}

/**
 * Apresentação de entrada (vídeo).
 * Só deve ser montada quando NÃO há sessão activa e ainda não foi vista nesta sessão de browser.
 * Não misturar com SplashScreen de login/logout.
 */
export const IntroPresentation: React.FC<IntroPresentationProps> = ({ onFinished }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [canSkip, setCanSkip] = useState(false);
  const finishedRef = useRef(false);

  const finish = () => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    markIntroSeen();
    onFinished();
  };

  useEffect(() => {
    // Permitir saltar após um curto momento (evita toque acidental)
    const t = window.setTimeout(() => setCanSkip(true), 800);
    const v = videoRef.current;
    if (v) {
      v.play().catch(() => {
        // Autoplay bloqueado: utilizador pode tocar em Continuar
        setCanSkip(true);
      });
    }
    return () => window.clearTimeout(t);
  }, []);

  return (
    <div
      className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-[#0a0f0e]"
      role="dialog"
      aria-label="Apresentação ADXmoney"
    >
      <video
        ref={videoRef}
        className="absolute inset-0 w-full h-full object-contain bg-[#0a0f0e]"
        src="/intro.mp4"
        playsInline
        muted
        autoPlay
        // muted+playsInline favorece autoplay em iOS; o vídeo de marca é curto
        onEnded={finish}
        onError={() => {
          // Se o vídeo falhar, não bloquear entrada
          finish();
        }}
      />

      {/* Vinheta inferior + CTA */}
      <div className="absolute inset-x-0 bottom-0 pt-16 pb-[max(1.5rem,env(safe-area-inset-bottom))] px-6 bg-gradient-to-t from-black/70 via-black/35 to-transparent">
        <div className="max-w-sm mx-auto text-center space-y-3">
          <p className="text-white/90 text-[15px] font-bold tracking-tight">ADXmoney</p>
          <p className="text-white/55 text-[12px] font-medium">Monetização premium</p>
          <Button
            type="button"
            disabled={!canSkip}
            onClick={finish}
            className="w-full h-12 rounded-2xl bg-white text-slate-900 hover:bg-white/95 font-bold text-[14px] disabled:opacity-50"
          >
            Continuar
          </Button>
        </div>
      </div>
    </div>
  );
};

export default IntroPresentation;
