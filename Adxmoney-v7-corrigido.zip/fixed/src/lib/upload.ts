/** Validação segura de comprovativos antes do upload (mobile: poupa dados e evita ficheiros perigosos). */
export const MAX_PROOF_BYTES = 5 * 1024 * 1024; // 5 MB
const ALLOWED: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/jpg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "application/pdf": "pdf",
};

export interface ProofCheck {
  ok: boolean;
  error?: string;
  ext?: string;
}

export function checkProofFile(file: File): ProofCheck {
  const ext = ALLOWED[file.type];
  if (!ext) return { ok: false, error: "Formato inválido. Use JPG, PNG, WEBP ou PDF." };
  if (file.size > MAX_PROOF_BYTES) return { ok: false, error: "Ficheiro demasiado grande (máx. 5 MB)." };
  if (file.size === 0) return { ok: false, error: "Ficheiro vazio." };
  return { ok: true, ext };
}

/** Caminho único e seguro: extensão vem do MIME validado (nunca do nome do ficheiro). */
export function proofPath(prefix: string, ext: string): string {
  const rnd = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : String(Date.now());
  return `${prefix}/${Date.now()}_${rnd.slice(0, 8)}.${ext}`;
}
