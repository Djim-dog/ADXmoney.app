import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  Mail,
  User,
  Phone,
  Loader2,
  CheckCircle2,
  Copy,
  ArrowRight,
  HelpCircle,
  UserPlus,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

type Step = "form" | "success";

export default function Register() {
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>("form");
  const [submitting, setSubmitting] = useState(false);
  const [isFaqOpen, setIsFaqOpen] = useState(false);

  // Capturar ?r= / ?ref= no registo público
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const refCode = (params.get("r") || params.get("ref") || "").trim().toUpperCase();
      if (refCode) sessionStorage.setItem("adx_invite_code", refCode);
    } catch {
      /* ignore */
    }
  }, []);

  // Form
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");

  // Success data
  const [createdEmail, setCreatedEmail] = useState("");
  const [createdPassword, setCreatedPassword] = useState("");

  const handleCopy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Copiado!");
    } catch {
      toast.error("Não foi possível copiar.");
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = email.trim().toLowerCase();
    const cleanName = name.trim();
    const cleanPhone = phone.trim();

    if (!cleanName) {
      toast.error("Indique o seu nome completo.");
      return;
    }
    if (!cleanEmail) {
      toast.error("Indique o seu e-mail.");
      return;
    }
    if (!cleanPhone) {
      toast.error("Indique o seu WhatsApp.");
      return;
    }

    setSubmitting(true);

    try {
      const { data, error } = await supabase.functions.invoke("public-register", {
        body: {
          email: cleanEmail,
          name: cleanName,
          phone: cleanPhone,
          country: "Angola",
        },
      });

      if (error) {
        console.error("[Register] Edge error:", error);

        let msg = "Não foi possível criar a conta. Tente novamente.";

        // Extrair a mensagem real da Edge Function
        try {
          if (error.context) {
            const body = await error.context.json();
            if (body?.error) {
              msg = body.error;
            }
          }
        } catch {
          if ((data as any)?.error) {
            msg = (data as any).error;
          } else if (error.message) {
            msg = error.message;
          }
        }

        toast.error(msg);
        return;
      }

      if ((data as any)?.error) {
        toast.error((data as any).error);
        return;
      }

      const serverPassword = (data as any)?.password as string | undefined;
      if (!serverPassword) {
        toast.error("Conta criada, mas não foi possível mostrar a palavra-passe. Contacte o suporte.");
        return;
      }
      setCreatedEmail(cleanEmail);
      setCreatedPassword(serverPassword);
      setStep("success");
      toast.success("Conta criada com sucesso!");
    } catch (err: any) {
      console.error("[Register] Erro:", err);
      toast.error(err?.message || "Ocorreu um erro ao criar a conta.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleGoToLogin = () => {
    // Guarda e-mail para pré-preencher no login se quiseres (opcional)
    try {
      sessionStorage.setItem("adx_register_email", createdEmail);
    } catch {
      /* ignore */
    }
    navigate("/login", { state: { email: createdEmail } });
  };

  return (
    <div
      className="min-h-[100dvh] flex flex-col justify-center items-center px-5 py-10 select-none safe-x"
      style={{
        background:
          "radial-gradient(ellipse 120% 80% at 50% -20%, rgba(15, 118, 110, 0.08), transparent 50%), #f5f6f8",
      }}
    >
      <button
        type="button"
        onClick={() => setIsFaqOpen(true)}
        className="absolute top-4 right-4 text-[13px] text-slate-500 flex items-center gap-1.5 py-2 px-3 rounded-xl hover:bg-white/80 transition-colors"
        style={{ marginTop: "env(safe-area-inset-top, 0px)" }}
      >
        <HelpCircle className="w-4 h-4" />
        Ajuda
      </button>

      <div className="w-full max-w-[340px] animate-fade-up">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl gradient-adx shadow-lg shadow-teal-900/20 flex items-center justify-center mx-auto mb-5 overflow-hidden">
            <img src="/logo.png" alt="ADXmoney" className="w-full h-full object-cover" />
          </div>
          <h1 className="text-[24px] font-bold text-slate-900 tracking-tight">
            ADXmoney
          </h1>
          <p className="text-[13px] text-slate-500 mt-1.5 font-medium">
            {step === "form" ? "Crie a sua conta" : "Conta criada"}
          </p>
        </div>

        {step === "form" ? (
          <form
            onSubmit={handleRegister}
            className="card-premium p-6 space-y-4"
          >
            <div className="space-y-1.5">
              <Label htmlFor="name" className="text-[13px] font-medium text-slate-600">
                Nome completo
              </Label>
              <div className="relative">
                <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  id="name"
                  type="text"
                  placeholder="O seu nome"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  disabled={submitting}
                  className="pl-10 h-11 bg-slate-50 border-slate-200 rounded-xl text-[15px] focus:bg-white focus:border-slate-300"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="email" className="text-[13px] font-medium text-slate-600">
                E-mail
              </Label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  id="email"
                  type="email"
                  placeholder="seu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  disabled={submitting}
                  className="pl-10 h-11 bg-slate-50 border-slate-200 rounded-xl text-[15px] focus:bg-white focus:border-slate-300"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="phone" className="text-[13px] font-medium text-slate-600">
                WhatsApp
              </Label>
              <div className="relative">
                <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  id="phone"
                  type="tel"
                  inputMode="tel"
                  placeholder="+244 9..."
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/[^\d+\s]/g, "").slice(0, 16))}
                  maxLength={16}
                  required
                  disabled={submitting}
                  className="pl-10 h-11 bg-slate-50 border-slate-200 rounded-xl text-[15px] font-mono focus:bg-white focus:border-slate-300"
                />
              </div>
            </div>

            <Button
              type="submit"
              disabled={submitting}
              className="w-full h-11 bg-[#0f766e] hover:bg-[#0d9488] text-white rounded-xl text-[14px] font-semibold gap-2 mt-2"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  A criar conta...
                </>
              ) : (
                <>
                  <UserPlus className="w-4 h-4" />
                  Criar conta ADX
                </>
              )}
            </Button>

            <p className="text-center text-[13px] text-slate-500 pt-1">
              Já tem conta?{" "}
              <Link
                to="/login"
                className="text-[#0f766e] font-medium hover:underline"
              >
                Entrar
              </Link>
            </p>
          </form>
        ) : (
          <div className="bg-white border border-slate-200/80 rounded-2xl p-6 space-y-5">
            <div className="flex flex-col items-center text-center gap-2">
              <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h2 className="text-[16px] font-semibold text-slate-900">
                Conta criada com sucesso
              </h2>
              <p className="text-[13px] text-slate-500 leading-relaxed">
                Guarde a senha temporária. No primeiro acesso irá definir a sua
                própria palavra-passe e completar o perfil.
              </p>
            </div>

            <div className="bg-slate-50 rounded-xl border border-slate-100 p-4 space-y-3 text-left">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                  E-mail
                </p>
                <p className="text-[13px] font-medium text-slate-900 font-mono break-all">
                  {createdEmail}
                </p>
              </div>
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                  Senha temporária
                </p>
                <div className="flex items-center justify-between gap-2 bg-white p-2.5 rounded-lg border border-slate-200 mt-1">
                  <span className="text-[13px] font-semibold text-emerald-600 font-mono">
                    {createdPassword}
                  </span>
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={() => handleCopy(createdPassword)}
                    className="h-8 text-[11px] font-medium text-slate-600 hover:text-emerald-600 gap-1 shrink-0"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    Copiar
                  </Button>
                </div>
              </div>
            </div>

            <Button
              type="button"
              onClick={handleGoToLogin}
              className="w-full h-11 bg-[#0f766e] hover:bg-[#0d9488] text-white rounded-xl text-[14px] font-semibold gap-2"
            >
              Entrar com e-mail
              <ArrowRight className="w-4 h-4" />
            </Button>

            <p className="text-center text-[12px] text-slate-400 leading-relaxed">
              Após entrar, complete o primeiro acesso e a assinatura para
              desbloquear o app.
            </p>
          </div>
        )}
      </div>

      <Dialog open={isFaqOpen} onOpenChange={setIsFaqOpen}>
        <DialogContent className="sm:max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">Ajuda e suporte</DialogTitle>
            <DialogDescription className="text-[13px] text-slate-500 leading-relaxed">
              Crie a conta com o seu e-mail e WhatsApp. Recebe uma senha
              temporária nesta página. No primeiro login define a sua palavra-passe
              e completa o perfil. Depois pode activar a assinatura e usar o app.
              Se tiver problemas, contacte o suporte ADXmoney.
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    </div>
  );
}
