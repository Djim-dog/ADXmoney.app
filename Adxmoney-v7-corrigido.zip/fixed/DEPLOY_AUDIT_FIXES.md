# ADXmoney v7 — Deploy (auditoria 5 etapas)

## SQL obrigatório no Supabase (correr antes ou logo após o deploy)

1. `database/009_campaign_requests_admin_update.sql`
2. `database/010_debit_wallet.sql`

## Vercel

- Framework: Vite
- Build: `npm run build`
- Output: `dist`
- Install: `npm ci --legacy-peer-deps`
- SPA rewrites já em `vercel.json`

## Correções incluídas

1. First login — sem loop (RPC → password → await refreshProfile + flag sessionStorage)
2. Admin campanhas — policy UPDATE + parse de additional_information
3. Pagamento campanha — RPC debit_wallet + sem hard navigation (saldo insuficiente)
4. Voltar — histórico `?tab=` para botão físico
5. Splash só no boot + scroll isolado tipo app

## Fluxo saldo insuficiente (testado em código)

1. Utilizador abre Solicitar Campanha → passo 3 Pagamento
2. Sem saldo: "Pagar com saldo" → toast erro, sem splash
3. Comprar tokens → fecha modal → `goToTab(engagement)` + SubscriptionModal → sem reload
4. Com saldo: debit_wallet RPC → insert campaign_requests
