import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

/** Base de conhecimento oficial do ADXmoney — a IA só pode usar isto */
const KNOWLEDGE_BASE = `
REGRAS OFICIAIS DO ADXMONEY (Angola):

1. PRIMEIRO ACESSO E BÓNUS
- Ao completar o primeiro acesso, o utilizador recebe 250 Kz de bónus de entrada.
- Se usar um código de afiliado válido no primeiro acesso, o afiliado que indicou recebe 500 Kz de comissão.
- Cada utilizador só pode ser convertido uma vez (proteção contra abuso).

2. ASSINATURA
- Algumas funcionalidades (Tarefas, Campanhas, Afiliado) exigem assinatura ativa.
- Sem assinatura ativa, o utilizador vê o pedido de ativação ao tentar aceder a essas áreas.
- A ativação/estado da assinatura é gerida pelo administrador.

3. TAREFAS E CAMPANHAS
- O administrador atribui campanhas aos utilizadores.
- Cada campanha tem plataforma (TikTok, Instagram, YouTube), instruções e valor de recompensa.
- O utilizador executa a tarefa e marca como concluída.
- A recompensa só é creditada após conclusão válida (via sistema).

4. CARTEIRA E SALDO
- O saldo disponível pode ser sacado.
- Existe saldo reservado (bloqueado) quando há pedido de saque pendente.
- Tipos de movimento: bónus de entrada, comissão de afiliado, recompensa de campanha, bloqueio de saque, pagamento de saque, estorno.

5. SAQUES (LEVANTAMENTOS)
- O utilizador solicita saque com valor, método e dados de pagamento.
- Métodos comuns: Multicaixa Express, Transferência Bancária (IBAN), outros indicados no app.
- Ao pedir saque, o valor passa de disponível para reservado.
- O administrador aprova, paga ou rejeita.
- Se rejeitado, o valor volta para o saldo disponível.
- Processamento típico: até 24 horas úteis (conforme indicação no app).

6. AFILIADOS
- Cada afiliado ativo tem um código único.
- Comissão por indicação válida: 500 Kz (no primeiro acesso do indicado).
- O estado de afiliado (ativo/inativo) é controlado pelo administrador.
- Não é permitido criar contas falsas ou usar bots.

7. REGRAS GERAIS E SEGURANÇA
- É proibido o uso de contas falsas ou bots.
- Operações financeiras críticas só acontecem no servidor (não no telemóvel).
- A IA NÃO pode aprovar saques, alterar saldos nem inventar valores ou prazos diferentes dos acima.
- Se a pergunta não estiver coberta por estas regras, a resposta deve ser: indicar que não tem essa informação e sugerir contactar o suporte humano (WhatsApp).

8. IDIOMA
- Responder no mesmo idioma da pergunta do utilizador (português de Angola/Portugal, inglês ou francês).
`;

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const groqKey = Deno.env.get("GROQ_API_KEY");
    if (!groqKey) {
      return new Response(
        JSON.stringify({ error: "GROQ_API_KEY not configured" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ??
        Deno.env.get("SUPABASE_PUBLISHABLE_KEY") ??
        "",
      { global: { headers: { Authorization: authHeader } } }
    );

    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const question = (body.question || "").toString().trim().slice(0, 500);

    if (!question) {
      return new Response(
        JSON.stringify({ error: "Pergunta em falta" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Dados leves da conta para personalizar a resposta
    const [profileRes, walletRes] = await Promise.all([
      supabase
        .from("profiles")
        .select("name, preferred_language, subscription_status")
        .eq("id", user.id)
        .maybeSingle(),
      supabase
        .from("wallets")
        .select("balance, reserved_balance")
        .eq("user_id", user.id)
        .maybeSingle(),
    ]);

    const profile = profileRes.data;
    const wallet = walletRes.data;
    const language = profile?.preferred_language || "pt";
    const firstName = profile?.name?.split(" ")[0] || "";

    const systemPrompt = `You are the official ADXmoney support assistant (IA ADX).
You answer ONLY using the knowledge base below. Never invent rules, amounts, deadlines or policies.
If the answer is not in the knowledge base, say you don't have that information and suggest contacting human support via WhatsApp in the app.
Be short, clear and helpful. Use natural language.

KNOWLEDGE BASE:
${KNOWLEDGE_BASE}

User context (for personalization only, do not invent extra facts):
- Name: ${firstName || "Utilizador"}
- Language preference: ${language}
- Subscription: ${profile?.subscription_status || "unknown"}
- Available balance: ${wallet?.balance ?? "unknown"} Kz
- Reserved balance: ${wallet?.reserved_balance ?? "unknown"} Kz

Output ONLY valid JSON:
{
  "answer": "string - clear answer to the user",
  "suggested_actions": ["optional short action 1", "optional short action 2"]
}`;

    const groqRes = await fetch(
      "https://api.groq.com/openai/v1/chat/completions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${groqKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "openai/gpt-oss-20b",
          temperature: 0.3,
          max_tokens: 600,
          response_format: { type: "json_object" },
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: question },
          ],
        }),
      }
    );

    if (!groqRes.ok) {
      const errText = await groqRes.text();
      console.error("Groq error:", errText);
      return new Response(
        JSON.stringify({
          error: "AI provider error",
          detail: errText.slice(0, 250),
        }),
        {
          status: 502,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const groqJson = await groqRes.json();
    const raw = groqJson.choices?.[0]?.message?.content || "{}";
    let parsed: { answer?: string; suggested_actions?: string[] } = {};
    try {
      parsed = JSON.parse(raw);
    } catch {
      parsed = {
        answer:
          "Não consegui processar a resposta agora. Tenta de novo ou contacta o suporte no WhatsApp.",
        suggested_actions: [],
      };
    }

    return new Response(
      JSON.stringify({
        success: true,
        answer: parsed.answer || "",
        suggested_actions: Array.isArray(parsed.suggested_actions)
          ? parsed.suggested_actions.slice(0, 3)
          : [],
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Unknown error";
    console.error(msg);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
