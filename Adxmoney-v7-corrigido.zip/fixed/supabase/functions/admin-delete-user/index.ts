import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";

    if (!supabaseUrl || !serviceKey) {
      throw new Error("Configuração do servidor incompleta.");
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Não autorizado" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Cliente com JWT do caller — para validar identidade e role
    const supabaseUser = createClient(supabaseUrl, anonKey || serviceKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const {
      data: { user: caller },
      error: callerErr,
    } = await supabaseUser.auth.getUser();

    if (callerErr || !caller) {
      return new Response(JSON.stringify({ error: "Sessão inválida" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseAdmin = createClient(supabaseUrl, serviceKey);

    const { data: callerProfile, error: profileErr } = await supabaseAdmin
      .from("profiles")
      .select("id, role, email")
      .eq("id", caller.id)
      .maybeSingle();

    if (profileErr || !callerProfile || callerProfile.role !== "admin") {
      return new Response(
        JSON.stringify({ error: "Apenas administradores podem eliminar utilizadores." }),
        {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const body = await req.json().catch(() => ({}));
    const userId = body?.userId as string | undefined;
    if (!userId) throw new Error("ID do utilizador necessário");

    if (userId === caller.id) {
      return new Response(
        JSON.stringify({ error: "Não pode eliminar a sua própria conta de administrador." }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { data: target, error: targetErr } = await supabaseAdmin
      .from("profiles")
      .select("id, role, email")
      .eq("id", userId)
      .maybeSingle();

    if (targetErr) throw targetErr;
    if (!target) throw new Error("Utilizador não encontrado.");

    // Evitar apagar outro admin sem confirmação explícita no body
    if (target.role === "admin" && body?.confirmAdminDelete !== true) {
      return new Response(
        JSON.stringify({
          error:
            "Para eliminar outro administrador, confirme explicitamente (confirmAdminDelete).",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Melhor esforço: limpar comprovativos no storage
    try {
      const { data: files } = await supabaseAdmin.storage
        .from("subscription-proofs")
        .list(userId, { limit: 100 });
      if (files && files.length > 0) {
        await supabaseAdmin.storage
          .from("subscription-proofs")
          .remove(files.map((f) => `${userId}/${f.name}`));
      }
      const { data: depFiles } = await supabaseAdmin.storage
        .from("subscription-proofs")
        .list(`deposits/${userId}`, { limit: 100 });
      if (depFiles && depFiles.length > 0) {
        await supabaseAdmin.storage
          .from("subscription-proofs")
          .remove(depFiles.map((f) => `deposits/${userId}/${f.name}`));
      }
    } catch (storageErr) {
      console.warn("Storage cleanup (não bloqueante):", storageErr);
    }

    // Log de auditoria antes de apagar
    try {
      await supabaseAdmin.from("activity_logs").insert({
        user_id: caller.id,
        action_type: "ADMIN_DELETE_USER",
        title: "Utilizador eliminado",
        details: `Admin eliminou conta ${target.email || userId} (${userId})`,
      });
    } catch {
      /* não bloquear */
    }

    const { error: delErr } = await supabaseAdmin.auth.admin.deleteUser(userId);
    if (delErr) throw delErr;

    return new Response(
      JSON.stringify({ message: "Utilizador eliminado com sucesso", userId }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error: any) {
    console.error("admin-delete-user:", error);
    return new Response(JSON.stringify({ error: error.message || "Erro" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
