import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

// Palavra-passe temporária criptograficamente segura (o utilizador troca-a no primeiro acesso)
function generatePassword(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
  const bytes = new Uint8Array(12);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("") + "!7";
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    if (!supabaseUrl || !serviceKey) throw new Error("Configuração do servidor incompleta.");

    const body = await req.json().catch(() => ({}));
    const email = String(body?.email ?? "").trim().toLowerCase();
    const name = String(body?.name ?? "").trim();
    const phone = String(body?.phone ?? "").trim();
    const country = String(body?.country ?? "Angola").trim().slice(0, 60) || "Angola";

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || email.length > 160) {
      return json({ error: "E-mail inválido." }, 400);
    }
    if (name.length < 2 || name.length > 120) return json({ error: "Indique o seu nome completo." }, 400);
    if (phone.length < 6 || phone.length > 32) return json({ error: "Indique um WhatsApp válido." }, 400);

    const admin = createClient(supabaseUrl, serviceKey);

    const { data: byPhone } = await admin.from("profiles").select("id").eq("phone", phone).maybeSingle();
    if (byPhone) return json({ error: "Este número de telefone já está associado a outra conta." }, 400);

    const password = generatePassword();

    // role NUNCA vem do cliente; o trigger handle_new_user cria o perfil com role 'user'
    const { data: created, error: createErr } = await admin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { name, phone, country },
    });

    if (createErr) {
      const m = createErr.message || "";
      if (m.includes("already") || m.includes("registered")) {
        return json({ error: "Este e-mail já está associado a uma conta." }, 400);
      }
      throw createErr;
    }

    // Completa dados do perfil (o trigger já o criou)
    await admin
      .from("profiles")
      .update({ name, phone, country, updated_at: new Date().toISOString() })
      .eq("id", created.user.id);

    // A palavra-passe só é devolvida aqui, uma vez
    return json({ message: "Conta criada com sucesso", email, password });
  } catch (error: any) {
    console.error("[public-register] erro:", error?.message);
    return json({ error: "Não foi possível criar a conta. Tente novamente." }, 400);
  }
});
