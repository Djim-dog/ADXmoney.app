import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";

    if (!supabaseUrl || !serviceKey) {
      throw new Error("Configuração do servidor incompleta.");
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Não autorizado" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUser = createClient(supabaseUrl, anonKey || serviceKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const {
      data: { user: caller },
      error: callerErr,
    } = await supabaseUser.auth.getUser();

    if (callerErr || !caller) {
      return new Response(JSON.stringify({ error: "Sessão inválida" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseAdmin = createClient(supabaseUrl, serviceKey);

    const { data: callerProfile } = await supabaseAdmin
      .from("profiles")
      .select("id, role")
      .eq("id", caller.id)
      .maybeSingle();

    if (!callerProfile || callerProfile.role !== "admin") {
      return new Response(
        JSON.stringify({ error: "Apenas administradores podem criar utilizadores." }),
        {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const {
      email,
      password,
      name,
      phone,
      role,
      first_login,
      primary_link,
      tiktok,
      instagram,
      youtube,
      facebook,
      country,
    } = await req.json();

    const cleanEmail = email ? String(email).trim().toLowerCase() : "";
    const cleanPhone = phone ? String(phone).trim() : "";

    if (!cleanEmail) {
      return new Response(JSON.stringify({ error: "O e-mail é obrigatório." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!password || String(password).length < 6) {
      return new Response(
        JSON.stringify({ error: "A senha deve ter pelo menos 6 caracteres." }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    if (!name || !String(name).trim()) {
      return new Response(JSON.stringify({ error: "O nome é obrigatório." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Não permitir criar admin sem flag explícita (default: user)
    const safeRole = role === "admin" ? "admin" : "user";

    const { data: existingProfileByEmail } = await supabaseAdmin
      .from("profiles")
      .select("id, email")
      .ilike("email", cleanEmail)
      .maybeSingle();

    if (existingProfileByEmail) {
      return new Response(
        JSON.stringify({ error: "Este e-mail já está associado a outra conta no sistema." }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    if (cleanPhone) {
      const { data: existingProfileByPhone } = await supabaseAdmin
        .from("profiles")
        .select("id, phone")
        .eq("phone", cleanPhone)
        .maybeSingle();

      if (existingProfileByPhone) {
        return new Response(
          JSON.stringify({
            error: "Este número de telefone já está associado a outra conta no sistema.",
          }),
          {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
      }
    }

    const { data: createdData, error: userError } =
      await supabaseAdmin.auth.admin.createUser({
        email: cleanEmail,
        password: password,
        email_confirm: true,
        user_metadata: {
          name,
          role: safeRole,
          phone: cleanPhone,
          first_login: first_login ?? true,
        },
      });

    if (userError) {
      console.error("[admin-create-user] Erro auth:", userError.message);
      if (
        userError.message.includes("already registered") ||
        userError.message.includes("already exists")
      ) {
        return new Response(
          JSON.stringify({
            error: "Este e-mail já está associado a outra conta no sistema.",
          }),
          {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
      }
      throw userError;
    }

    const userId = createdData.user.id;

    // O trigger handle_new_user já criou o perfil (role 'user'): completar com UPSERT, nunca INSERT
    const { error: profileError } = await supabaseAdmin.from("profiles").upsert({
      id: userId,
      email: cleanEmail,
      name: String(name).trim(),
      phone: cleanPhone || null,
      role: safeRole,
      first_login: first_login ?? true,
      primary_link: primary_link ? String(primary_link).trim() : null,
      tiktok: tiktok ? String(tiktok).trim() : null,
      instagram: instagram ? String(instagram).trim() : null,
      youtube: youtube ? String(youtube).trim() : null,
      facebook: facebook ? String(facebook).trim() : null,
      country: country || "Angola",
      is_active: true,
      updated_at: new Date().toISOString(),
    }, { onConflict: "id" });

    if (profileError) {
      console.error("[admin-create-user] Erro perfil:", profileError.message);
      await supabaseAdmin.auth.admin.deleteUser(userId);
      throw new Error("Erro ao criar perfil do usuário: " + profileError.message);
    }

    const { error: walletError } = await supabaseAdmin
      .from("wallets")
      .insert({ user_id: userId, balance: 0, reserved_balance: 0 });

    if (walletError && !walletError.message.includes("duplicate key")) {
      console.error("[admin-create-user] Erro carteira:", walletError.message);
    }

    try {
      await supabaseAdmin.from("activity_logs").insert({
        user_id: caller.id,
        action_type: "ADMIN_CREATE_USER",
        title: "Utilizador criado",
        details: `Admin criou conta ${cleanEmail} (${safeRole})`,
      });
    } catch {
      /* ignore */
    }

    return new Response(
      JSON.stringify({
        message: "Usuário criado com sucesso",
        user: createdData.user,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error: any) {
    console.error("[admin-create-user] Erro crítico:", error.message);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
