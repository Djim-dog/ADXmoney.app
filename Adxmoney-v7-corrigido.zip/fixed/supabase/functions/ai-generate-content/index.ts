import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

type Lang = "pt" | "en" | "fr";
type Platform = "TikTok" | "Instagram" | "YouTube";
type Objective = "followers" | "engagement" | "affiliate" | "campaign";

const LANG_NAMES: Record<Lang, string> = {
  pt: "Portuguese (Angola/Portugal style, natural)",
  en: "English",
  fr: "French",
};

const OBJECTIVE_HINT: Record<Objective, string> = {
  followers: "grow followers / audience",
  engagement: "likes, comments, views, shares",
  affiliate: "invite people to join via referral code",
  campaign: "promote a product or campaign link",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const groqKey = Deno.env.get("GROQ_API_KEY");
    if (!groqKey) {
      return new Response(
        JSON.stringify({ error: "GROQ_API_KEY not configured on server" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError || !userData?.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const platform = (body.platform || "TikTok") as Platform;
    const objective = (body.objective || "engagement") as Objective;
    const language = (body.language || "pt") as Lang;
    const context = (body.context || "").toString().slice(0, 500);
    const referralCode = (body.referral_code || "").toString().slice(0, 32);

    const langLabel = LANG_NAMES[language] || LANG_NAMES.pt;
    const objHint = OBJECTIVE_HINT[objective] || OBJECTIVE_HINT.engagement;

    const systemPrompt = `You are IA ADX, a monetization content assistant for the ADXmoney platform (social tasks, campaigns, affiliates in Angola/Africa).
Write practical social media content. Output ONLY valid JSON, no markdown fences.
JSON shape:
{
  "caption": "string - post caption ready to publish",
  "hashtags": ["tag1", "tag2", "... up to 8 without # symbol"],
  "video_idea": "string - short video idea, 1-2 sentences"
}
Rules:
- Language of all text: ${langLabel}
- Platform: ${platform}
- Goal: ${objHint}
- Tone: natural, short, not spammy, not fake promises of riches
- If referral code is provided and objective is affiliate, weave it naturally into caption
- Hashtags without the # character in the array`;

    const userPrompt = `Generate content for ${platform}, goal: ${objHint}.
Extra context: ${context || "none"}
Referral code: ${referralCode || "none"}`;

    const groqRes = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${groqKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "openai/gpt-oss-20b",
        temperature: 0.7,
        max_tokens: 800,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
      }),
    });

    if (!groqRes.ok) {
      const errText = await groqRes.text();
      console.error("Groq error:", errText);
      return new Response(
        JSON.stringify({ error: "AI provider error", detail: errText.slice(0, 200) }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const groqJson = await groqRes.json();
    const raw = groqJson.choices?.[0]?.message?.content || "{}";
    let parsed: { caption?: string; hashtags?: string[]; video_idea?: string };
    try {
      parsed = JSON.parse(raw);
    } catch {
      parsed = { caption: raw, hashtags: [], video_idea: "" };
    }

    return new Response(
      JSON.stringify({
        success: true,
        caption: parsed.caption || "",
        hashtags: Array.isArray(parsed.hashtags) ? parsed.hashtags : [],
        video_idea: parsed.video_idea || "",
        language,
        platform,
        objective,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : "Unknown error";
    console.error(msg);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
