import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const groqKey = Deno.env.get("GROQ_API_KEY");
    if (!groqKey) {
      return new Response(
        JSON.stringify({ error: "GROQ_API_KEY not configured" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ??
        Deno.env.get("SUPABASE_PUBLISHABLE_KEY") ??
        "",
      { global: { headers: { Authorization: authHeader } } }
    );

    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // === Buscar dados reais do utilizador ===
    const [profileRes, walletRes, assignmentsRes, affiliateRes] =
      await Promise.all([
        supabase
          .from("profiles")
          .select("name, preferred_language, subscription_status, is_active")
          .eq("id", user.id)
          .maybeSingle(),
        supabase
          .from("wallets")
          .select("balance, reserved_balance")
          .eq("user_id", user.id)
          .maybeSingle(),
        supabase
          .from("campaign_assignments")
          .select("id, status, campaigns(title, platform, reward_amount)")
          .eq("user_id", user.id)
          .in("status", ["ASSIGNED", "IN_PROGRESS"]),
        supabase
          .from("affiliate_profiles")
          .select("affiliate_code, total_referrals, total_earned, is_active")
          .eq("user_id", user.id)
          .maybeSingle(),
      ]);

    const profile = profileRes.data;
    const wallet = walletRes.data;
    const pendingTasks = assignmentsRes.data || [];
    const affiliate = affiliateRes.data;

    const language = (profile?.preferred_language || "pt") as "pt" | "en" | "fr";
    const balance = Number(wallet?.balance || 0);
    const reserved = Number(wallet?.reserved_balance || 0);
    const pendingCount = pendingTasks.length;
    const hasAffiliate = !!affiliate?.affiliate_code;
    const totalReferrals = affiliate?.total_referrals || 0;
    const affiliateEarned = Number(affiliate?.total_earned || 0);
    const isSubscriber = profile?.subscription_status === "active";

    const contextForAI = {
      name: profile?.name?.split(" ")[0] || "Utilizador",
      language,
      balance,
      reserved,
      pending_tasks: pendingCount,
      tasks_preview: pendingTasks.slice(0, 3).map((t: any) => ({
        title: t.campaigns?.title,
        platform: t.campaigns?.platform,
        reward: t.campaigns?.reward_amount,
      })),
      has_affiliate_code: hasAffiliate,
      affiliate_code: affiliate?.affiliate_code || null,
      total_referrals: totalReferrals,
      affiliate_earned: affiliateEarned,
      is_subscriber: isSubscriber,
    };

    const systemPrompt = `You are IA ADX Coach, a practical monetization assistant for the ADXmoney app (Angola/Africa).
Your job is to help the user earn more by giving clear, honest, actionable advice based on real account data.
Never invent balances, never promise riches, never suggest illegal actions.
Output ONLY valid JSON, no markdown.

JSON shape:
{
  "greeting": "string - short personal greeting",
  "summary": "string - 1-2 sentences about current situation",
  "actions": [
    {
      "title": "string - short action title",
      "description": "string - why and how",
      "priority": "high" | "medium" | "low",
      "type": "task" | "affiliate" | "subscription" | "withdraw" | "content" | "general"
    }
  ],
  "motivation": "string - one short realistic encouragement"
}

Rules:
- Language: ${language === "en" ? "English" : language === "fr" ? "French" : "Portuguese (natural Angola/Portugal style)"}
- Maximum 3 actions
- Be direct and useful
- Prioritize pending tasks first, then affiliate growth, then subscription if needed`;

    const userPrompt = `User data:
${JSON.stringify(contextForAI, null, 2)}

Generate the daily coach response.`;

    const groqRes = await fetch(
      "https://api.groq.com/openai/v1/chat/completions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${groqKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "openai/gpt-oss-20b",
          temperature: 0.6,
          max_tokens: 900,
          response_format: { type: "json_object" },
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt },
          ],
        }),
      }
    );

    if (!groqRes.ok) {
      const errText = await groqRes.text();
      console.error("Groq error:", errText);
      return new Response(
        JSON.stringify({
          error: "AI provider error",
          detail: errText.slice(0, 250),
        }),
        {
          status: 502,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const groqJson = await groqRes.json();
    const raw = groqJson.choices?.[0]?.message?.content || "{}";
    let parsed: any = {};
    try {
      parsed = JSON.parse(raw);
    } catch {
      parsed = {
        greeting: "Olá!",
        summary: "Não foi possível gerar o resumo agora.",
        actions: [],
        motivation: "Continua a trabalhar nas tuas tarefas.",
      };
    }

    return new Response(
      JSON.stringify({
        success: true,
        greeting: parsed.greeting || "",
        summary: parsed.summary || "",
        actions: Array.isArray(parsed.actions) ? parsed.actions.slice(0, 3) : [],
        motivation: parsed.motivation || "",
        meta: {
          balance,
          pending_tasks: pendingCount,
          total_referrals: totalReferrals,
          is_subscriber: isSubscriber,
        },
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Unknown error";
    console.error(msg);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
