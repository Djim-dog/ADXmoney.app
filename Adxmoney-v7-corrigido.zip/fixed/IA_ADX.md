# IA ADX — Assistente de Monetização

## O que está feito

### 1. Gerador de Conteúdo
- Edge Function: `ai-generate-content`
- Modelo: `openai/gpt-oss-20b` (Groq)
- UI: menu **Gerar Conteúdo**
- Output: legenda + hashtags + ideia de vídeo

### 2. Coach de Ganhos
- Edge Function: `ai-coach`
- UI: menu **Coach de Ganhos**
- Cartões de resumo (saldo, tarefas, afiliados)
- 3 ações prioritárias com botões de navegação

### 3. Suporte Inteligente
- Edge Function: `ai-support`
- UI: menu **Apoio / Suporte** (abre o assistente)
- Responde com base nas regras oficiais do ADXmoney
- Perguntas rápidas + campo livre
- Link para WhatsApp (suporte humano)

## Configuração no Supabase

### Secret
- `GROQ_API_KEY` = chave `gsk_...`

### Functions a fazer deploy
1. `ai-generate-content`
2. `ai-coach`
3. `ai-support`  ← **nova**

Em todas: Verify JWT **ativado**.

## Segurança
- A IA nunca altera saldos nem aprova saques
- O Suporte só usa a base de conhecimento oficial
- Se não souber, indica contacto humano
