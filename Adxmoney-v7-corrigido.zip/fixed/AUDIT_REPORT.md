# Auditoria ADXmoney v7 — correções aplicadas

NADA foi compilado nem executado (sem npm install / Postgres no ambiente da auditoria). Testar em staging.

## Ordem de aplicação
1. Supabase SQL Editor: `database/014_audit_surgical_fixes.sql` (depois de 013).
2. Deploy functions:
   - `supabase functions deploy public-register --no-verify-jwt`
   - `supabase functions deploy admin-create-user admin-delete-user`
3. Vercel: definir `VITE_PUBLIC_URL=https://<teu-dominio>` e fazer deploy do front.
4. Storage: bucket `subscription-proofs` privado (as policies vêm no 014).

## Segurança / dinheiro (014 + functions)
- handle_new_user ignora role do metadata (escalada para admin).
- public-register criado; password gerada com crypto no servidor.
- admin-create-user: upsert em vez de insert; coluna facebook criada.
- INSERT directo revogado em subscription_payments, engagement_orders, campaign_requests, wallet_deposits.
- Campanha: preço fixo 9500 no servidor; rejeição reembolsa (admin_process_campaign_request).
- Assinatura: RPC única, preço por moeda (CONFIRMAR taxas), não rebaixa assinante activo.
- Saque: RPC única com lock, mínimo 1000, conta activa/sem suspensão; admin via is_admin().
- Depósito: comprovativo tem de estar em deposits/{uid}/.
- Tarefas: exige assinatura, limite max/diário, tempo mínimo 15s, denúncia única.
- Criadas admin_assign_campaign e admin_toggle_affiliate (rever se já existirem em produção).

## Front
- AuthContext sem upsert em erro, sem await no onAuthStateChange, sem refetch em TOKEN_REFRESHED.
- ProtectedRoute não decide papel por metadata.
- AccountSetup: hooks ok; palavra-passe trocada antes do RPC.
- UserApp: 7 queries em paralelo, deps por user.id, link de convite via VITE_PUBLIC_URL.
- Admin: reembolso, colunas de community_tasks, denúncias, signed URL, password segura.
- Uploads validados (5 MB, JPG/PNG/WEBP/PDF).
- Code-splitting (Admin/User lazy), manualChunks, logo 857 KB → 40 KB, headers Vercel, SW v3.

## Android
- WebView: file chooser, links externos, sem mixed content, allowBackup=false, erro PostgREST→Postgrest.
- Ainda faltam: libs.versions.toml, res/, proguard-rules.pro, gradle wrapper. Recomendado migrar para Capacitor.

## Decisões pendentes
Recompensas sem prova; taxas de câmbio; apagar comprovativos após aprovar; ON DELETE CASCADE no ledger;
não voltar a correr FIX_community_settings.sql; 3 variantes de 007_parts.
